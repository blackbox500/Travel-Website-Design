import { useEffect, type ReactNode } from "react";
import { ToastProvider } from "@/components/ui/Toast";
import { PromoStrip, TopBar } from "@/components/TopBar";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { FloatingChat } from "@/components/FloatingChat";
import { matchPath, useLocation } from "@/lib/router";
import { HomePage } from "@/pages/HomePage";
import { DestinationsPage } from "@/pages/DestinationsPage";
import { DestinationPage } from "@/pages/DestinationPage";
import { ToursPage } from "@/pages/ToursPage";
import { TourPage } from "@/pages/TourPage";
import { VisaPage } from "@/pages/VisaPage";
import { GalleryPage } from "@/pages/GalleryPage";
import { BlogPage } from "@/pages/BlogPage";
import { BlogPostPage } from "@/pages/BlogPostPage";
import { AboutPage } from "@/pages/AboutPage";
import { ContactPage } from "@/pages/ContactPage";
import { NotFoundPage } from "@/pages/NotFoundPage";

const ROUTES: { path: string; render: (params: Record<string, string>) => ReactNode }[] = [
  { path: "/", render: () => <HomePage /> },
  { path: "/destinations", render: () => <DestinationsPage /> },
  { path: "/destinations/:id", render: (p) => <DestinationPage id={p.id} /> },
  { path: "/tours", render: () => <ToursPage /> },
  { path: "/tours/:slug", render: (p) => <TourPage slug={p.slug} /> },
  { path: "/visa", render: () => <VisaPage /> },
  { path: "/gallery", render: () => <GalleryPage /> },
  { path: "/blog", render: () => <BlogPage /> },
  { path: "/blog/:slug", render: (p) => <BlogPostPage slug={p.slug} /> },
  { path: "/about", render: () => <AboutPage /> },
  { path: "/contact", render: () => <ContactPage /> },
];

function RouteView() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: "instant" });
  }, [pathname]);

  for (const route of ROUTES) {
    const params = matchPath(route.path, pathname);
    if (params) {
      return (
        <div key={pathname} className="animate-page-in">
          {route.render(params)}
        </div>
      );
    }
  }
  return <NotFoundPage />;
}

export default function App() {
  return (
    <ToastProvider>
      <button
        type="button"
        onClick={() => document.getElementById("main")?.focus()}
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-full focus:bg-navy-900 focus:px-5 focus:py-2.5 focus:text-sm focus:font-bold focus:text-white"
      >
        Skip to content
      </button>
      <div className="print:hidden">
        <PromoStrip />
        <TopBar />
      </div>
      <Header />
      <main id="main" tabIndex={-1} className="outline-none">
        <RouteView />
      </main>
      <Footer />
      <div className="print:hidden">
        <FloatingChat />
      </div>
    </ToastProvider>
  );
}
