import { useCallback, useEffect, useMemo, useState } from "react";
import { ChevronDown, Heart, Mail, Menu, Phone, Send, X } from "lucide-react";
import { CONTACT, DESTINATIONS, NAV, SETTINGS } from "@/config";
import { TOURS } from "@/data/tours";
import { cn } from "@/utils/cn";
import { useScrolled } from "@/lib/hooks";
import { openEnquiry } from "@/lib/enquiryBus";
import { isActive, Link, useLocation } from "@/lib/router";
import { useWishlist } from "@/lib/wishlist";
import { flagUrl, formatBDT, mailLink, pexels, telLink, waLink } from "@/lib/utils";
import { Logo } from "./ui/primitives";
import { WhatsAppIcon } from "./ui/BrandIcons";
import { WishlistDrawer } from "./WishlistDrawer";

export function Header() {
  const scrolled = useScrolled(24);
  const { pathname, search } = useLocation();
  const [open, setOpen] = useState(false);
  const [toursOpen, setToursOpen] = useState(false);
  const [wishOpen, setWishOpen] = useState(false);
  const { list } = useWishlist();
  const closeWish = useCallback(() => setWishOpen(false), []);

  const counts = useMemo(
    () => Object.fromEntries(DESTINATIONS.map((d) => [d.id, TOURS.filter((t) => t.destinations.includes(d.id)).length])),
    [],
  );
  const featured = TOURS.find((t) => t.featured) ?? TOURS[0];

  // Close menus after navigating
  useEffect(() => {
    setOpen(false);
    const el = document.activeElement;
    if (el instanceof HTMLElement && el.closest("[data-sticky-header]")) el.blur();
  }, [pathname, search]);

  useEffect(() => {
    if (!open) return;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const quote = () => {
    setOpen(false);
    openEnquiry({ mode: "plan" });
  };

  const navClass = (to: string) =>
    cn(
      "flex items-center gap-1 rounded-full px-3.5 py-2 text-sm font-semibold transition",
      isActive(pathname, to) ? "bg-navy-900 text-white shadow-md shadow-navy-900/20" : "text-slate-600 hover:bg-navy-50 hover:text-navy-900",
    );

  return (
    <>
      <header
        data-sticky-header
        className={cn(
          "sticky top-0 z-50 border-b transition-all duration-300 print:hidden",
          scrolled ? "border-slate-200/70 bg-white/90 shadow-lg shadow-navy-900/5 backdrop-blur-xl" : "border-transparent bg-white",
        )}
      >
        <div
          className={cn(
            "mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 transition-all duration-300 sm:px-6 lg:px-8",
            scrolled ? "h-16" : "h-20",
          )}
        >
          <Link to="/" className="shrink-0" aria-label="SAARC Holiday – home">
            <Logo className={cn("w-auto transition-all duration-300", scrolled ? "h-9" : "h-11")} />
          </Link>

          <nav className="hidden xl:block" aria-label="Main navigation">
            <ul className="flex items-center gap-0.5">
              {NAV.map((item) =>
                item.mega ? (
                  <li key={item.label} className="group relative">
                    <Link to={item.to} className={navClass(item.to)} aria-haspopup="true">
                      {item.label}
                      <ChevronDown className="h-4 w-4 transition group-hover:rotate-180" />
                    </Link>
                    <div className="invisible absolute left-1/2 top-full z-20 w-[600px] -translate-x-1/2 translate-y-2 pt-3 opacity-0 transition-all duration-200 group-focus-within:visible group-focus-within:translate-y-0 group-focus-within:opacity-100 group-hover:visible group-hover:translate-y-0 group-hover:opacity-100">
                      <div className="grid grid-cols-5 gap-2 rounded-3xl border border-slate-100 bg-white p-3 shadow-2xl shadow-navy-900/15">
                        <div className="col-span-3 p-2">
                          <p className="px-2 text-[11px] font-bold uppercase tracking-[0.18em] text-slate-400">Tours by destination</p>
                          <ul className="mt-2 grid grid-cols-2 gap-1">
                            {DESTINATIONS.map((d) => (
                              <li key={d.id}>
                                <Link
                                  to={`/tours?destination=${d.id}`}
                                  className="flex items-center gap-2.5 rounded-xl px-2 py-2 text-sm font-semibold text-slate-600 transition hover:bg-sunset-50 hover:text-sunset-700"
                                >
                                  <img src={flagUrl(d.flag)} alt="" className="h-4 w-6 rounded-sm object-cover" />
                                  {d.name}
                                  <span className="ml-auto text-[11px] font-medium text-slate-400">{counts[d.id]}</span>
                                </Link>
                              </li>
                            ))}
                          </ul>
                          <Link
                            to="/tours"
                            className="mt-2 flex items-center justify-between rounded-xl bg-navy-50 px-3 py-2.5 text-sm font-bold text-navy-900 transition hover:bg-navy-100"
                          >
                            All {TOURS.length} tour packages <span aria-hidden>→</span>
                          </Link>
                        </div>
                        <Link to={`/tours/${featured.slug}`} className="group/f relative col-span-2 min-h-64 overflow-hidden rounded-2xl">
                          <img
                            src={pexels(featured.images[0], 420, 520)}
                            alt=""
                            className="absolute inset-0 h-full w-full object-cover transition duration-700 group-hover/f:scale-110"
                          />
                          <div className="absolute inset-0 bg-linear-to-t from-navy-950/90 via-navy-950/30 to-transparent" />
                          <div className="absolute inset-x-4 bottom-4 text-white">
                            <span className="rounded-full bg-sunset-500 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider">
                              Featured
                            </span>
                            <p className="mt-2 font-bold leading-snug">{featured.title}</p>
                            <p className="mt-0.5 text-xs text-white/75">
                              {featured.nights}N / {featured.nights + 1}D
                              {SETTINGS.showPrices && ` · from ${formatBDT(featured.price)}`}
                            </p>
                          </div>
                        </Link>
                      </div>
                    </div>
                  </li>
                ) : (
                  <li key={item.label}>
                    <Link to={item.to} aria-current={isActive(pathname, item.to) ? "page" : undefined} className={navClass(item.to)}>
                      {item.label}
                    </Link>
                  </li>
                ),
              )}
            </ul>
          </nav>

          <div className="flex items-center gap-2">
            <a
              href={telLink(CONTACT.phones[0].value)}
              className="hidden items-center gap-2.5 rounded-full py-1.5 pl-1.5 pr-4 text-sm font-bold text-navy-900 transition hover:bg-navy-50 2xl:flex"
            >
              <span className="grid h-9 w-9 place-items-center rounded-full bg-sunset-100 text-sunset-600">
                <Phone className="h-4 w-4" />
              </span>
              <span className="leading-tight">
                <span className="block text-[11px] font-medium text-slate-400">Call us now</span>
                {CONTACT.phones[0].display}
              </span>
            </a>
            <button
              type="button"
              onClick={() => setWishOpen(true)}
              aria-label={`Open wishlist (${list.length} saved)`}
              className="relative grid h-11 w-11 place-items-center rounded-full border border-slate-200 text-navy-900 transition hover:bg-navy-50"
            >
              <Heart className={cn("h-5 w-5 transition", list.length > 0 && "fill-rose-500 text-rose-500")} />
              {list.length > 0 && (
                <span
                  key={list.length}
                  className="absolute -right-1 -top-1 grid h-5 min-w-5 animate-pop place-items-center rounded-full bg-sunset-500 px-1 text-[10px] font-bold text-white"
                >
                  {list.length}
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={quote}
              className="hidden items-center gap-2 rounded-full bg-sunset-500 px-5 py-2.5 text-sm font-bold text-white shadow-lg shadow-sunset-500/30 transition hover:-translate-y-0.5 hover:bg-sunset-600 sm:inline-flex"
            >
              <Send className="h-4 w-4" />
              Get a Quote
            </button>
            <button
              type="button"
              onClick={() => setOpen(true)}
              className="grid h-11 w-11 place-items-center rounded-full border border-slate-200 text-navy-900 transition hover:bg-navy-50 xl:hidden"
              aria-label="Open menu"
              aria-expanded={open}
            >
              <Menu className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Mobile drawer (outside header so backdrop-filter doesn't trap fixed positioning) */}
      <div className={cn("fixed inset-0 z-[60] xl:hidden print:hidden", open ? "pointer-events-auto" : "pointer-events-none")} inert={!open}>
        <div
          onClick={() => setOpen(false)}
          className={cn("absolute inset-0 bg-navy-950/50 backdrop-blur-sm transition-opacity duration-300", open ? "opacity-100" : "opacity-0")}
        />
        <aside
          className={cn(
            "absolute right-0 top-0 flex h-full w-[86%] max-w-sm flex-col bg-white shadow-2xl transition-transform duration-300",
            open ? "translate-x-0" : "translate-x-full",
          )}
          aria-label="Mobile navigation"
        >
          <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
            <Logo className="h-9 w-auto" />
            <button
              type="button"
              onClick={() => setOpen(false)}
              aria-label="Close menu"
              className="grid h-10 w-10 place-items-center rounded-full bg-slate-100 text-navy-900"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          <nav className="flex-1 overflow-y-auto px-3 py-4">
            <ul className="space-y-1">
              {NAV.map((item) =>
                item.mega ? (
                  <li key={item.label}>
                    <button
                      type="button"
                      onClick={() => setToursOpen((v) => !v)}
                      aria-expanded={toursOpen}
                      className={cn(
                        "flex w-full items-center justify-between rounded-xl px-4 py-3 text-base font-semibold",
                        isActive(pathname, item.to) ? "bg-navy-50 text-navy-900" : "text-slate-700 hover:bg-slate-50",
                      )}
                    >
                      {item.label}
                      <ChevronDown className={cn("h-5 w-5 transition", toursOpen && "rotate-180")} />
                    </button>
                    <div className={cn("grid transition-[grid-template-rows] duration-300", toursOpen ? "grid-rows-[1fr]" : "grid-rows-[0fr]")}>
                      <ul className="overflow-hidden pl-3">
                        <li>
                          <Link
                            to="/tours"
                            onClick={() => setOpen(false)}
                            className="block rounded-xl px-4 py-2.5 text-sm font-bold text-navy-900 hover:bg-sunset-50"
                          >
                            All tour packages
                          </Link>
                        </li>
                        {DESTINATIONS.map((d) => (
                          <li key={d.id}>
                            <Link
                              to={`/tours?destination=${d.id}`}
                              onClick={() => setOpen(false)}
                              className="flex items-center gap-2.5 rounded-xl px-4 py-2.5 text-sm font-medium text-slate-600 hover:bg-sunset-50 hover:text-sunset-700"
                            >
                              <img src={flagUrl(d.flag)} alt="" className="h-3.5 w-5 rounded-[2px] object-cover" />
                              {d.name} tours
                            </Link>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </li>
                ) : (
                  <li key={item.label}>
                    <Link
                      to={item.to}
                      onClick={() => setOpen(false)}
                      aria-current={isActive(pathname, item.to) ? "page" : undefined}
                      className={cn(
                        "block rounded-xl px-4 py-3 text-base font-semibold",
                        isActive(pathname, item.to) ? "bg-navy-900 text-white" : "text-slate-700 hover:bg-slate-50",
                      )}
                    >
                      {item.label}
                    </Link>
                  </li>
                ),
              )}
            </ul>
          </nav>
          <div className="space-y-2 border-t border-slate-100 p-4">
            <button
              type="button"
              onClick={quote}
              className="flex w-full items-center justify-center gap-2 rounded-full bg-sunset-500 py-3 text-sm font-bold text-white"
            >
              <Send className="h-4 w-4" /> Get a free quote
            </button>
            <div className="grid grid-cols-3 gap-2">
              <a
                href={telLink(CONTACT.phones[0].value)}
                className="flex flex-col items-center gap-1 rounded-2xl bg-navy-50 py-3 text-xs font-semibold text-navy-900"
              >
                <Phone className="h-5 w-5" /> Call
              </a>
              <a
                href={waLink("Hello SAARC Holiday! I need some travel help.")}
                target="_blank"
                rel="noopener noreferrer"
                className="flex flex-col items-center gap-1 rounded-2xl bg-emerald-50 py-3 text-xs font-semibold text-emerald-700"
              >
                <WhatsAppIcon className="h-5 w-5" /> WhatsApp
              </a>
              <a
                href={mailLink(CONTACT.emails[0].value)}
                className="flex flex-col items-center gap-1 rounded-2xl bg-lagoon-50 py-3 text-xs font-semibold text-lagoon-700"
              >
                <Mail className="h-5 w-5" /> Email
              </a>
            </div>
          </div>
        </aside>
      </div>

      <WishlistDrawer open={wishOpen} onClose={closeWish} />
    </>
  );
}
