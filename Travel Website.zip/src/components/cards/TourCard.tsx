import { ArrowRight, Clock, Heart, MapPin } from "lucide-react";
import { DESTINATIONS, SETTINGS } from "@/config";
import type { Tour } from "@/data/tours";
import { Link } from "@/lib/router";
import { useWishlist } from "@/lib/wishlist";
import { flagUrl, formatBDT, pexels } from "@/lib/utils";
import { cn } from "@/utils/cn";
import { useToast } from "../ui/Toast";

export function WishlistButton({ slug, title, className }: { slug: string; title: string; className?: string }) {
  const { has, toggle } = useWishlist();
  const toast = useToast();
  const saved = has(slug);
  return (
    <button
      type="button"
      onClick={() => {
        const added = toggle(slug);
        toast(added ? "Saved to your wishlist" : "Removed from your wishlist", added ? "success" : "info");
      }}
      aria-pressed={saved}
      aria-label={saved ? `Remove ${title} from wishlist` : `Save ${title} to wishlist`}
      className={cn(
        "grid h-10 w-10 place-items-center rounded-full bg-white/90 shadow-lg backdrop-blur transition hover:scale-110 active:scale-90",
        className,
      )}
    >
      <Heart className={cn("h-5 w-5 transition", saved ? "fill-rose-500 text-rose-500" : "text-navy-900")} />
    </button>
  );
}

export function TourCard({ tour, className }: { tour: Tour; className?: string }) {
  const flags = DESTINATIONS.filter((d) => tour.destinations.includes(d.id));
  return (
    <article
      className={cn(
        "group relative flex flex-col overflow-hidden rounded-3xl bg-white shadow-lg shadow-navy-900/5 ring-1 ring-slate-200/70 transition duration-300 hover:-translate-y-1.5 hover:shadow-2xl hover:shadow-navy-900/10",
        className,
      )}
    >
      <div className="relative aspect-[4/3] overflow-hidden">
        <img
          src={pexels(tour.images[0], 640, 480)}
          alt={tour.title}
          loading="lazy"
          className="h-full w-full object-cover transition duration-700 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-linear-to-t from-navy-950/70 via-transparent to-transparent" />
        {tour.badge && (
          <span className="absolute left-4 top-4 rounded-full bg-sunset-500 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-white shadow-lg">
            {tour.badge}
          </span>
        )}
        <WishlistButton slug={tour.slug} title={tour.title} className="absolute right-4 top-4 z-10" />
        <div className="absolute bottom-4 left-4 flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-white/95 px-3 py-1 text-xs font-bold text-navy-900">
            <Clock className="h-3.5 w-3.5 text-sunset-500" />
            {tour.nights}N / {tour.nights + 1}D
          </span>
          <span className="flex -space-x-1.5">
            {flags.map((f) => (
              <img key={f.id} src={flagUrl(f.flag)} alt={f.name} className="h-5 w-7 rounded-sm object-cover ring-2 ring-white" />
            ))}
          </span>
        </div>
      </div>

      <div className="flex flex-1 flex-col p-5">
        <p className="flex items-center gap-1.5 text-xs font-semibold text-lagoon-700">
          <MapPin className="h-3.5 w-3.5 shrink-0" />
          <span className="truncate">{tour.route.join(" · ")}</span>
        </p>
        <h3 className="mt-2 text-lg font-bold leading-snug text-navy-900 transition group-hover:text-sunset-600">
          <Link to={`/tours/${tour.slug}`} className="after:absolute after:inset-0">
            {tour.title}
          </Link>
        </h3>
        <div className="mb-5 mt-3 flex flex-wrap gap-1.5">
          {tour.styles.slice(0, 3).map((s) => (
            <span key={s} className="rounded-full bg-slate-100 px-2.5 py-0.5 text-[11px] font-semibold text-slate-600">
              {s}
            </span>
          ))}
        </div>
        <div className="mt-auto flex items-end justify-between gap-3 border-t border-slate-100 pt-4">
          {SETTINGS.showPrices ? (
            <div>
              <p className="text-[11px] font-medium text-slate-400">
                From {tour.oldPrice && <span className="ml-1 line-through">{formatBDT(tour.oldPrice)}</span>}
              </p>
              <p className="text-xl font-extrabold text-navy-900">
                {formatBDT(tour.price)} <span className="text-xs font-medium text-slate-400">/ person</span>
              </p>
            </div>
          ) : (
            <p className="text-sm font-bold text-navy-900">Price on request</p>
          )}
          <span className="inline-flex shrink-0 items-center gap-1 text-sm font-bold text-sunset-600">
            Details <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
          </span>
        </div>
      </div>
    </article>
  );
}
