import { ArrowUpRight } from "lucide-react";
import type { DestinationInfo } from "@/data/destinations";
import { TOURS } from "@/data/tours";
import { Link } from "@/lib/router";
import { flagUrl, pexels } from "@/lib/utils";
import { cn } from "@/utils/cn";

export function DestinationCard({
  d,
  large,
  className,
  badge,
}: {
  d: DestinationInfo;
  large?: boolean;
  className?: string;
  badge?: string;
}) {
  const count = TOURS.filter((t) => t.destinations.includes(d.id)).length;
  return (
    <Link
      to={`/destinations/${d.id}`}
      className={cn("group relative block overflow-hidden rounded-3xl bg-navy-900 shadow-lg shadow-navy-900/10", className)}
    >
      <img
        src={pexels(d.image, large ? 900 : 600, large ? 900 : 700)}
        alt={d.name}
        loading="lazy"
        className="absolute inset-0 h-full w-full object-cover transition duration-700 group-hover:scale-110"
      />
      <div className="absolute inset-0 bg-linear-to-t from-navy-950/95 via-navy-950/45 to-navy-950/5 transition duration-500 group-hover:via-navy-950/55" />
      <div className="absolute left-4 top-4 flex items-center gap-2 rounded-full bg-white/90 py-1 pl-1 pr-3 text-[11px] font-bold text-navy-900 backdrop-blur">
        <img src={flagUrl(d.flag)} alt="" className="h-4 w-6 rounded-full object-cover" />
        {d.region}
      </div>
      {badge && (
        <span className="absolute right-4 top-4 animate-pop rounded-full bg-sunset-500 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-white shadow-lg">
          {badge}
        </span>
      )}
      <div className="absolute inset-x-5 bottom-5">
        <h3 className={cn("font-extrabold tracking-tight text-white", large ? "text-3xl sm:text-4xl" : "text-xl")}>{d.name}</h3>
        <p className={cn("mt-1 text-white/80", large ? "max-w-sm text-base" : "text-sm")}>{large ? d.summary : d.tagline}</p>
        <div className="mt-3 flex items-center justify-between">
          <span className="text-xs font-semibold text-sunset-300">
            {count} tour package{count === 1 ? "" : "s"}
          </span>
          <span className="grid h-9 w-9 translate-x-2 place-items-center rounded-full bg-sunset-500 text-white opacity-0 transition duration-300 group-hover:translate-x-0 group-hover:opacity-100">
            <ArrowUpRight className="h-4 w-4" />
          </span>
        </div>
      </div>
    </Link>
  );
}
