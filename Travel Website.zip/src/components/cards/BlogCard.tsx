import { ArrowRight, CalendarDays, Clock } from "lucide-react";
import { readingTime, type Post } from "@/data/blog";
import { Link } from "@/lib/router";
import { formatDate, pexels } from "@/lib/utils";
import { cn } from "@/utils/cn";

export function BlogCard({ post, className }: { post: Post; className?: string }) {
  return (
    <article
      className={cn(
        "group relative flex flex-col overflow-hidden rounded-3xl bg-white shadow-lg shadow-navy-900/5 ring-1 ring-slate-200/70 transition duration-300 hover:-translate-y-1.5 hover:shadow-2xl hover:shadow-navy-900/10",
        className,
      )}
    >
      <div className="relative aspect-[16/10] overflow-hidden">
        <img
          src={pexels(post.cover, 640, 400)}
          alt=""
          loading="lazy"
          className="h-full w-full object-cover transition duration-700 group-hover:scale-110"
        />
        <span className="absolute left-4 top-4 rounded-full bg-white/95 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-navy-900">
          {post.category}
        </span>
      </div>
      <div className="flex flex-1 flex-col p-6">
        <p className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs font-medium text-slate-400">
          <span className="inline-flex items-center gap-1">
            <CalendarDays className="h-3.5 w-3.5" />
            {formatDate(post.date)}
          </span>
          <span className="inline-flex items-center gap-1">
            <Clock className="h-3.5 w-3.5" />
            {readingTime(post)} min read
          </span>
        </p>
        <h3 className="mt-3 text-lg font-bold leading-snug text-navy-900 transition group-hover:text-sunset-600">
          <Link to={`/blog/${post.slug}`} className="after:absolute after:inset-0">
            {post.title}
          </Link>
        </h3>
        <p className="mt-2 line-clamp-3 text-sm leading-relaxed text-slate-500">{post.excerpt}</p>
        <span className="mt-auto inline-flex items-center gap-1 pt-5 text-sm font-bold text-sunset-600">
          Read article <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
        </span>
      </div>
    </article>
  );
}
