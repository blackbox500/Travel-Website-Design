import { useMemo, useState } from "react";
import { Plus, Search, SearchX } from "lucide-react";
import { FAQS } from "@/config";
import { cn } from "@/utils/cn";
import { openEnquiry } from "@/lib/enquiryBus";
import { waLink } from "@/lib/utils";
import { Reveal } from "./ui/Reveal";
import { SectionHeading } from "./ui/primitives";
import { WhatsAppIcon } from "./ui/BrandIcons";

function Highlight({ text, query }: { text: string; query: string }) {
  const q = query.trim();
  if (!q) return <>{text}</>;
  const parts = text.split(new RegExp(`(${q.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")})`, "gi"));
  return (
    <>
      {parts.map((p, i) =>
        p.toLowerCase() === q.toLowerCase() ? (
          <mark key={i} className="rounded bg-sunset-100 px-0.5 text-inherit">
            {p}
          </mark>
        ) : (
          <span key={i}>{p}</span>
        ),
      )}
    </>
  );
}

export function FAQ() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");
  const [open, setOpen] = useState<number | null>(0);

  const categories = useMemo(() => ["All", ...Array.from(new Set(FAQS.map((f) => f.category)))], []);
  const q = query.trim().toLowerCase();
  const items = FAQS.map((f, i) => ({ ...f, i })).filter(
    (f) => (category === "All" || f.category === category) && (!q || `${f.q} ${f.a}`.toLowerCase().includes(q)),
  );

  return (
    <section id="faq" className="py-20 sm:py-24">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        <Reveal>
          <SectionHeading eyebrow="FAQ" title="Questions? We've got answers" subtitle="Quick answers to the things travellers ask us most." />
        </Reveal>

        <Reveal className="mt-10">
          <div className="relative">
            <Search className="pointer-events-none absolute left-5 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search questions… e.g. visa, payment, Bhutan"
              aria-label="Search frequently asked questions"
              className="w-full rounded-full border border-slate-200 bg-white py-4 pl-14 pr-5 text-sm shadow-sm transition placeholder:text-slate-400 focus:border-lagoon-400 focus:outline-none focus:ring-4 focus:ring-lagoon-100"
            />
          </div>
          <div className="mt-4 flex flex-wrap justify-center gap-2">
            {categories.map((c) => (
              <button
                key={c}
                type="button"
                aria-pressed={category === c}
                onClick={() => setCategory(c)}
                className={cn(
                  "rounded-full px-4 py-1.5 text-sm font-semibold transition",
                  category === c ? "bg-navy-900 text-white shadow-md shadow-navy-900/20" : "bg-white text-slate-600 ring-1 ring-slate-200 hover:bg-slate-50",
                )}
              >
                {c}
              </button>
            ))}
          </div>
        </Reveal>

        <ul className="mt-8 space-y-3">
          {items.map((f) => {
            const isOpen = open === f.i || (!!q && items.length <= 2);
            return (
              <li
                key={f.i}
                className={cn(
                  "overflow-hidden rounded-2xl border bg-white transition-all duration-300",
                  isOpen ? "border-lagoon-200 shadow-lg shadow-lagoon-500/5" : "border-slate-200 hover:border-slate-300",
                )}
              >
                <h3>
                  <button
                    type="button"
                    id={`faq-q-${f.i}`}
                    aria-expanded={isOpen}
                    aria-controls={`faq-a-${f.i}`}
                    onClick={() => setOpen(open === f.i ? null : f.i)}
                    className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left sm:px-6 sm:py-5"
                  >
                    <span className="flex items-center gap-3">
                      <span className="hidden rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-slate-500 sm:inline">
                        {f.category}
                      </span>
                      <span className="font-semibold text-navy-900">
                        <Highlight text={f.q} query={query} />
                      </span>
                    </span>
                    <span
                      className={cn(
                        "grid h-8 w-8 shrink-0 place-items-center rounded-full transition duration-300",
                        isOpen ? "rotate-45 bg-sunset-500 text-white" : "bg-slate-100 text-navy-900",
                      )}
                    >
                      <Plus className="h-4 w-4" />
                    </span>
                  </button>
                </h3>
                <div
                  id={`faq-a-${f.i}`}
                  role="region"
                  aria-labelledby={`faq-q-${f.i}`}
                  className={cn("grid transition-[grid-template-rows] duration-300 ease-out", isOpen ? "grid-rows-[1fr]" : "grid-rows-[0fr]")}
                >
                  <div className="overflow-hidden">
                    <p className="px-5 pb-5 text-sm leading-relaxed text-slate-600 sm:px-6">
                      <Highlight text={f.a} query={query} />
                    </p>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>

        {items.length === 0 && (
          <div className="mt-8 rounded-2xl border border-dashed border-slate-300 bg-white p-8 text-center">
            <SearchX className="mx-auto h-8 w-8 text-slate-300" />
            <p className="mt-3 font-semibold text-navy-900">No answers found for “{query}”</p>
            <p className="mt-1 text-sm text-slate-500">Ask us directly — we&apos;re happy to help.</p>
            <button
              type="button"
              onClick={() => openEnquiry({ mode: "quick", message: query ? `Question: ${query}` : undefined })}
              className="mt-4 rounded-full bg-navy-900 px-5 py-2.5 text-sm font-bold text-white transition hover:bg-navy-800"
            >
              Ask your question
            </button>
          </div>
        )}

        <Reveal className="mt-10">
          <div className="flex flex-col items-center justify-between gap-4 rounded-3xl bg-linear-to-r from-lagoon-50 via-white to-sunset-50 p-6 text-center ring-1 ring-slate-200/70 sm:flex-row sm:text-left">
            <div>
              <p className="font-bold text-navy-900">Still have questions?</p>
              <p className="text-sm text-slate-500">Our team is happy to help with anything travel-related.</p>
            </div>
            <div className="flex flex-wrap justify-center gap-2">
              <button
                type="button"
                onClick={() => openEnquiry({ mode: "quick" })}
                className="rounded-full bg-navy-900 px-5 py-2.5 text-sm font-bold text-white transition hover:bg-navy-800"
              >
                Send a message
              </button>
              <a
                href={waLink("Hello SAARC Holiday! I have a question.")}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-full bg-[#25D366] px-5 py-2.5 text-sm font-bold text-white transition hover:bg-[#1ebe5a]"
              >
                <WhatsAppIcon className="h-4 w-4" /> WhatsApp
              </a>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
