import { useState } from "react";
import { Check, Clock, Copy, CreditCard, ExternalLink, MapPin, Minus, Navigation, Phone, Plus, Stamp } from "lucide-react";
import { CONTACT } from "@/config";
import { cn } from "@/utils/cn";
import { useOfficeStatus } from "@/lib/hooks";
import { formatDuration, weekSchedule } from "@/lib/office";
import { copyText, directionsUrl, mapEmbedUrl } from "@/lib/utils";
import { Reveal } from "./ui/Reveal";
import { SectionHeading, StatusDot } from "./ui/primitives";
import { useToast } from "./ui/Toast";

const TIPS = [
  { icon: Phone, text: "Call ahead so the right travel consultant is available for you." },
  { icon: Stamp, text: "For visa processing, bring your passport and recent photographs." },
  { icon: CreditCard, text: "Pay with bKash, Nagad, Rocket, Visa card or Bangla QR." },
];

export function VisitUs() {
  const [type, setType] = useState<"m" | "k">("m");
  const [zoom, setZoom] = useState(17);
  const [copied, setCopied] = useState(false);
  const { now, status } = useOfficeStatus();
  const week = weekSchedule(now);
  const toast = useToast();

  const copyAddress = async () => {
    const ok = await copyText(CONTACT.address.full);
    toast(ok ? "Address copied" : "Couldn't copy", ok ? "success" : "error");
    if (ok) {
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    }
  };

  return (
    <section id="visit" className="bg-white py-20 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal>
          <SectionHeading
            eyebrow="Where to find us"
            title="Visit our office in Dhaka"
            subtitle="Drop by for a cup of tea and a chat about your next adventure — we'd love to meet you in person."
          />
        </Reveal>

        <div className="mt-12 grid gap-6 lg:grid-cols-5">
          <Reveal className="lg:col-span-3">
            <div className="relative h-[460px] overflow-hidden rounded-[2rem] bg-slate-100 ring-1 ring-slate-200 sm:h-[520px] lg:h-full lg:min-h-[560px]">
              <iframe
                title="SAARC Holiday office location on Google Maps"
                src={mapEmbedUrl(type, zoom)}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                allowFullScreen
                className="absolute inset-0 h-full w-full border-0"
              />

              <div className="absolute left-4 top-4 flex rounded-full bg-white p-1 shadow-lg" role="group" aria-label="Map type">
                {(
                  [
                    ["m", "Map"],
                    ["k", "Satellite"],
                  ] as const
                ).map(([value, label]) => (
                  <button
                    key={value}
                    type="button"
                    aria-pressed={type === value}
                    onClick={() => setType(value)}
                    className={cn(
                      "rounded-full px-4 py-1.5 text-xs font-bold transition",
                      type === value ? "bg-navy-900 text-white" : "text-slate-600 hover:text-navy-900",
                    )}
                  >
                    {label}
                  </button>
                ))}
              </div>

              <div className="absolute right-4 top-4 flex flex-col overflow-hidden rounded-xl bg-white shadow-lg">
                <button
                  type="button"
                  onClick={() => setZoom((z) => Math.min(20, z + 1))}
                  aria-label="Zoom in"
                  className="grid h-10 w-10 place-items-center text-navy-900 transition hover:bg-slate-100"
                >
                  <Plus className="h-4 w-4" />
                </button>
                <span className="h-px bg-slate-200" />
                <button
                  type="button"
                  onClick={() => setZoom((z) => Math.max(11, z - 1))}
                  aria-label="Zoom out"
                  className="grid h-10 w-10 place-items-center text-navy-900 transition hover:bg-slate-100"
                >
                  <Minus className="h-4 w-4" />
                </button>
              </div>

              <div className="absolute inset-x-4 bottom-4 rounded-2xl bg-white/95 p-4 shadow-2xl backdrop-blur sm:right-auto sm:max-w-sm">
                <div className="flex gap-3">
                  <span className="grid h-11 w-11 shrink-0 animate-float place-items-center rounded-xl bg-sunset-500 text-white shadow-lg shadow-sunset-500/30">
                    <MapPin className="h-5 w-5" />
                  </span>
                  <div>
                    <p className="font-bold text-navy-900">SAARC Holiday</p>
                    <p className="text-sm leading-snug text-slate-500">
                      {CONTACT.address.line1}
                      <br />
                      {CONTACT.address.line2}
                    </p>
                  </div>
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  <a
                    href={directionsUrl()}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 rounded-full bg-navy-900 px-3.5 py-2 text-xs font-bold text-white transition hover:bg-navy-800"
                  >
                    <Navigation className="h-3.5 w-3.5" /> Directions
                  </a>
                  <button
                    type="button"
                    onClick={copyAddress}
                    className={cn(
                      "inline-flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-bold ring-1 transition",
                      copied ? "bg-emerald-50 text-emerald-700 ring-emerald-200" : "text-navy-900 ring-slate-200 hover:bg-slate-50",
                    )}
                  >
                    {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                    {copied ? "Copied" : "Copy address"}
                  </button>
                  <a
                    href={CONTACT.map.placeUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-bold text-navy-900 ring-1 ring-slate-200 transition hover:bg-slate-50"
                  >
                    <ExternalLink className="h-3.5 w-3.5" /> Google Maps
                  </a>
                </div>
              </div>
            </div>
          </Reveal>

          <Reveal className="lg:col-span-2" delay={120}>
            <div className="relative h-full overflow-hidden rounded-[2rem] bg-navy-900 p-6 text-white sm:p-8">
              <div className="pointer-events-none absolute -right-16 -top-16 h-56 w-56 rounded-full bg-sunset-500/20 blur-3xl" />
              <div className="relative flex flex-wrap items-center justify-between gap-3">
                <h3 className="flex items-center gap-2 text-lg font-bold">
                  <Clock className="h-5 w-5 text-sunset-400" />
                  Office hours
                </h3>
                <span
                  className={cn(
                    "inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-bold",
                    status.open ? (status.closingSoon ? "bg-amber-400/15 text-amber-200" : "bg-emerald-400/15 text-emerald-200") : "bg-rose-400/15 text-rose-200",
                  )}
                >
                  <StatusDot open={status.open} soon={status.closingSoon} />
                  {status.title}
                </span>
              </div>
              <p className="relative mt-1.5 text-sm text-navy-200">
                {status.detail}
                {status.open && status.minutesLeft ? ` · ${formatDuration(status.minutesLeft)} left today` : ""}
              </p>

              <ul className="relative mt-6 space-y-1">
                {week.map((d) => (
                  <li
                    key={d.index}
                    className={cn(
                      "flex items-center justify-between rounded-xl px-4 py-2.5 text-sm",
                      d.isToday ? "bg-white/10 font-bold text-white ring-1 ring-white/15" : "text-navy-100",
                    )}
                  >
                    <span className="flex items-center gap-2">
                      {d.name}
                      {d.isToday && <span className="rounded-full bg-sunset-500 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider">Today</span>}
                    </span>
                    <span className={cn("tabular-nums", d.closed && "text-rose-300")}>{d.hours}</span>
                  </li>
                ))}
              </ul>
              <p className="relative mt-3 text-xs text-navy-300">All times are Bangladesh Standard Time (GMT+6).</p>

              <div className="relative mt-6 space-y-3 border-t border-white/10 pt-6">
                <p className="text-xs font-bold uppercase tracking-[0.2em] text-navy-200">Before you visit</p>
                {TIPS.map(({ icon: Icon, text }) => (
                  <p key={text} className="flex items-start gap-3 text-sm text-navy-100">
                    <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-white/10">
                      <Icon className="h-3.5 w-3.5 text-sunset-300" />
                    </span>
                    {text}
                  </p>
                ))}
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
