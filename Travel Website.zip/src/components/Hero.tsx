import { useEffect, useState } from "react";
import { ArrowRight, BadgeCheck, ChevronRight, Clock, CreditCard, Headphones, Phone, ShieldCheck, Stamp } from "lucide-react";
import { CONTACT, HERO_IMAGE, SITE } from "@/config";
import { cn } from "@/utils/cn";
import { openEnquiry } from "@/lib/enquiryBus";
import { Link } from "@/lib/router";
import { useOfficeStatus, useReducedMotion } from "@/lib/hooks";
import { pexels, telLink, waLink } from "@/lib/utils";
import { StatusDot } from "./ui/primitives";
import { WhatsAppIcon } from "./ui/BrandIcons";

const WORDS = ["Bhutan", "Nepal", "Thailand", "Singapore", "Malaysia", "India", "China", "Mongolia"];

function RotatingWord() {
  const [i, setI] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => setI((v) => (v + 1) % WORDS.length), 2300);
    return () => window.clearInterval(id);
  }, []);
  return (
    <>
      <span className="sr-only">your dream destination</span>
      <span aria-hidden className="relative inline-block [perspective:600px]">
        <span
          key={WORDS[i]}
          className="inline-block animate-word bg-linear-to-r from-sunset-300 via-sunset-400 to-amber-300 bg-clip-text pb-2 text-transparent"
        >
          {WORDS[i]}
        </span>
      </span>
    </>
  );
}

const PLANE = "M18 0c0-1.6-1.5-2.2-3-2.2H5L-2-12h-4l5 9.8h-8l-3.5-3.8H-15l2 5v2l-2 5h2.5L-9 2.2h8L-6 12h4l7-9.8h10c1.5 0 3-.6 3-2.2z";
const FLIGHT = "M-60 560 C 260 420, 480 640, 800 430 S 1260 170, 1520 110";

function FlightPath() {
  return (
    <svg className="pointer-events-none absolute inset-0 -z-10 h-full w-full" viewBox="0 0 1440 700" preserveAspectRatio="xMidYMid slice" aria-hidden>
      <path d={FLIGHT} fill="none" stroke="rgba(255,255,255,0.28)" strokeWidth="2" strokeDasharray="3 11" strokeLinecap="round" className="animate-dash" />
      <g>
        <circle r="22" fill="rgba(245,132,31,0.18)" />
        <path d={PLANE} fill="#fff" />
        <animateMotion dur="16s" repeatCount="indefinite" rotate="auto" path={FLIGHT} />
      </g>
    </svg>
  );
}

const TRUST = [
  { icon: BadgeCheck, label: SITE.membership },
  { icon: Stamp, label: "Visa assistance" },
  { icon: ShieldCheck, label: "Trusted & reliable" },
  { icon: CreditCard, label: "bKash · Nagad · Card" },
];

export function Hero() {
  const { status, time } = useOfficeStatus();
  const reduced = useReducedMotion();

  return (
    <section className="relative isolate overflow-hidden bg-navy-950 pb-40 pt-12 sm:pt-16 lg:pb-48 lg:pt-20">
      <img
        src={pexels(HERO_IMAGE, 1920, 1100)}
        alt=""
        fetchPriority="high"
        className="absolute inset-0 -z-20 h-full w-full object-cover object-center"
      />
      <div className="absolute inset-0 -z-10 bg-linear-to-r from-navy-950/95 via-navy-900/80 to-navy-900/35" />
      <div className="absolute inset-0 -z-10 bg-linear-to-t from-navy-950/80 via-transparent to-navy-950/30" />
      {!reduced && <FlightPath />}

      <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 sm:px-6 lg:grid-cols-12 lg:px-8">
        <div className="lg:col-span-7">
          <nav aria-label="Breadcrumb" className="animate-fade-up">
            <ol className="flex items-center gap-1.5 text-sm text-navy-200">
              <li>
                <Link to="/" className="transition hover:text-white">
                  Home
                </Link>
              </li>
              <li aria-hidden>
                <ChevronRight className="h-3.5 w-3.5" />
              </li>
              <li className="font-semibold text-white" aria-current="page">
                Contact
              </li>
            </ol>
          </nav>

          <p className="mt-6 animate-fade-up font-script text-3xl text-sunset-300 [animation-delay:80ms]">Let&apos;s talk travel!</p>
          <h1 className="mt-1 animate-fade-up text-4xl font-extrabold leading-[1.08] tracking-tight text-white [animation-delay:140ms] sm:text-5xl lg:text-6xl">
            Plan your next trip to <br className="hidden sm:block" />
            <RotatingWord />
          </h1>
          <p className="mt-5 max-w-xl animate-fade-up text-base leading-relaxed text-navy-100 [animation-delay:220ms] sm:text-lg">
            Tour packages, visa processing, hotel bookings and air tickets — tell us where you&apos;d like to go and our
            Dhaka-based travel experts will craft the perfect plan for you.
          </p>

          <div className="mt-8 flex animate-fade-up flex-wrap gap-3 [animation-delay:300ms]">
            <button
              type="button"
              onClick={() => openEnquiry({ mode: "plan" })}
              className="group inline-flex items-center gap-2 rounded-full bg-sunset-500 px-6 py-3.5 text-sm font-bold text-white shadow-xl shadow-sunset-500/30 transition hover:-translate-y-0.5 hover:bg-sunset-600"
            >
              Plan my trip
              <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
            </button>
            <a
              href={waLink("Hello SAARC Holiday! I'd like some help planning a trip.")}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full bg-[#25D366] px-6 py-3.5 text-sm font-bold text-white shadow-xl shadow-emerald-500/20 transition hover:-translate-y-0.5 hover:bg-[#1ebe5a]"
            >
              <WhatsAppIcon className="h-5 w-5" />
              WhatsApp us
            </a>
            <a
              href={telLink(CONTACT.phones[0].value)}
              className="inline-flex items-center gap-2 rounded-full border border-white/25 bg-white/10 px-6 py-3.5 text-sm font-bold text-white backdrop-blur transition hover:bg-white/20"
            >
              <Phone className="h-4 w-4" />
              Call now
            </a>
          </div>

          <ul className="mt-10 flex animate-fade-up flex-wrap gap-x-6 gap-y-3 text-sm font-medium text-navy-100 [animation-delay:380ms]">
            {TRUST.map(({ icon: Icon, label }) => (
              <li key={label} className="inline-flex items-center gap-2">
                <Icon className="h-4 w-4 text-sunset-400" />
                {label}
              </li>
            ))}
          </ul>
        </div>

        {/* Live status card */}
        <div className="lg:col-span-5">
          <div className="relative mx-auto max-w-md animate-fade-up [animation-delay:260ms] lg:ml-auto lg:mr-0">
            <div className="absolute -inset-2 rounded-[2rem] bg-linear-to-br from-sunset-400/40 via-lagoon-400/25 to-transparent blur-2xl" />
            <div className="relative rounded-[1.75rem] border border-white/15 bg-white/10 p-6 text-white shadow-2xl backdrop-blur-xl sm:p-7">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-navy-200">Local time in Dhaka</p>
                  <p className="mt-1 text-4xl font-extrabold tabular-nums">{time}</p>
                </div>
                <span
                  className={cn(
                    "inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-bold",
                    status.open ? (status.closingSoon ? "bg-amber-400/15 text-amber-200" : "bg-emerald-400/15 text-emerald-200") : "bg-rose-400/15 text-rose-200",
                  )}
                >
                  <StatusDot open={status.open} soon={status.closingSoon} />
                  {status.title}
                </span>
              </div>
              <p className="mt-2 flex items-center gap-2 text-sm text-navy-100">
                <Clock className="h-4 w-4" />
                {status.detail}
              </p>

              <div className="my-5 h-px bg-white/15" />

              <p className="text-sm font-semibold">Talk to a travel expert</p>
              <div className="mt-3 space-y-2.5">
                {CONTACT.phones.map((p) => (
                  <a
                    key={p.value}
                    href={telLink(p.value)}
                    className="group flex items-center justify-between rounded-2xl bg-white/10 px-4 py-3 transition hover:bg-white/20"
                  >
                    <span className="flex items-center gap-3">
                      <span className="grid h-9 w-9 place-items-center rounded-full bg-sunset-500 text-white">
                        <Phone className="h-4 w-4" />
                      </span>
                      <span>
                        <span className="block text-[11px] uppercase tracking-wider text-navy-200">{p.label}</span>
                        <span className="font-bold tabular-nums">{p.display}</span>
                      </span>
                    </span>
                    <ArrowRight className="h-4 w-4 opacity-60 transition group-hover:translate-x-1 group-hover:opacity-100" />
                  </a>
                ))}
              </div>
              <p className="mt-5 flex items-start gap-2 text-xs leading-relaxed text-navy-200">
                <Headphones className="mt-0.5 h-4 w-4 shrink-0" />
                {CONTACT.responseTime} WhatsApp messages are welcome any time.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Wave divider */}
      <svg className="absolute -bottom-px left-0 h-16 w-full text-slate-50 sm:h-20" viewBox="0 0 1440 80" preserveAspectRatio="none" aria-hidden>
        <path fill="currentColor" d="M0 80V44c120 22 240 33 360 33S600 62 720 46s240-40 360-40 240 18 360 34v40z" />
      </svg>
    </section>
  );
}
