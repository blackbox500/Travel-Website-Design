import { useState } from "react";
import { BadgeCheck, Mail, MapPin, Phone, Sparkles, X } from "lucide-react";
import { CONTACT, OFFERS, SITE } from "@/config";
import { useOfficeStatus } from "@/lib/hooks";
import { openEnquiry } from "@/lib/enquiryBus";
import { mailLink, telLink } from "@/lib/utils";
import { StatusDot } from "./ui/primitives";
import { FacebookIcon } from "./ui/BrandIcons";

const PROMO_KEY = "saarc-promo-hidden";

export function PromoStrip() {
  const [hidden, setHidden] = useState(() => {
    try {
      return sessionStorage.getItem(PROMO_KEY) === "1";
    } catch {
      return false;
    }
  });
  if (hidden || !OFFERS.length) return null;
  const offer = OFFERS[0];

  const dismiss = () => {
    setHidden(true);
    try {
      sessionStorage.setItem(PROMO_KEY, "1");
    } catch {
      /* ignore */
    }
  };

  return (
    <div className="relative bg-linear-to-r from-sunset-600 via-sunset-500 to-amber-500 text-white">
      <div className="mx-auto flex max-w-7xl items-center justify-center gap-2.5 px-10 py-2 text-center text-xs font-medium sm:text-sm">
        <Sparkles className="hidden h-4 w-4 shrink-0 sm:block" />
        <p>
          <span className="font-bold">{offer.title}</span>
          <span className="hidden sm:inline"> — {offer.subtitle}</span> for just{" "}
          <span className="font-extrabold">{offer.price}</span>
        </p>
        <button
          type="button"
          onClick={() => openEnquiry(offer.preset)}
          className="shrink-0 rounded-full bg-white/20 px-3 py-0.5 font-bold transition hover:bg-white hover:text-sunset-600"
        >
          Ask now →
        </button>
      </div>
      <button
        type="button"
        onClick={dismiss}
        aria-label="Dismiss offer"
        className="absolute right-2 top-1/2 grid h-7 w-7 -translate-y-1/2 place-items-center rounded-full transition hover:bg-white/20"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}

export function TopBar() {
  const { status, time } = useOfficeStatus();
  return (
    <div className="hidden bg-navy-950 text-[13px] text-navy-100 md:block">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-2 sm:px-6 lg:px-8">
        <div className="flex items-center gap-5">
          <a href={mailLink(CONTACT.emails[0].value)} className="inline-flex items-center gap-1.5 transition hover:text-white">
            <Mail className="h-3.5 w-3.5 text-sunset-400" />
            {CONTACT.emails[0].value}
          </a>
          <a href={telLink(CONTACT.phones[0].value)} className="inline-flex items-center gap-1.5 transition hover:text-white">
            <Phone className="h-3.5 w-3.5 text-sunset-400" />
            {CONTACT.phones[0].display}
          </a>
          <span className="hidden items-center gap-1.5 lg:inline-flex">
            <MapPin className="h-3.5 w-3.5 text-sunset-400" />
            {CONTACT.address.short}
          </span>
        </div>
        <div className="flex items-center gap-4">
          <span className="inline-flex items-center gap-2" title={status.detail}>
            <StatusDot open={status.open} soon={status.closingSoon} />
            <span>
              Dhaka <span className="font-semibold tabular-nums text-white">{time}</span> · {status.title}
            </span>
          </span>
          <span className="h-4 w-px bg-white/15" />
          <span className="hidden items-center gap-1.5 font-semibold text-sunset-300 lg:inline-flex">
            <BadgeCheck className="h-4 w-4" />
            {SITE.membership}
          </span>
          <a
            href={CONTACT.facebook}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="SAARC Holiday on Facebook"
            className="grid h-7 w-7 place-items-center rounded-full bg-white/10 transition hover:bg-[#1877F2] hover:text-white"
          >
            <FacebookIcon className="h-3.5 w-3.5" />
          </a>
        </div>
      </div>
    </div>
  );
}
