import { useEffect } from "react";
import { Heart, Send, Trash2, X } from "lucide-react";
import { SETTINGS } from "@/config";
import { TOURS } from "@/data/tours";
import { openEnquiry } from "@/lib/enquiryBus";
import { Link } from "@/lib/router";
import { useWishlist } from "@/lib/wishlist";
import { formatBDT, pexels } from "@/lib/utils";
import { cn } from "@/utils/cn";

export function WishlistDrawer({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { list, remove, clear } = useWishlist();
  const tours = TOURS.filter((t) => list.includes(t.slug));

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  const enquire = () => {
    onClose();
    openEnquiry({
      mode: "plan",
      service: "tour",
      destinations: Array.from(new Set(tours.flatMap((t) => t.destinations))),
      message: `I'm interested in these tours from my wishlist:\n${tours
        .map((t) => `• ${t.title} (${t.nights}N/${t.nights + 1}D)`)
        .join("\n")}`,
    });
  };

  return (
    <div className={cn("fixed inset-0 z-[65] print:hidden", open ? "pointer-events-auto" : "pointer-events-none")} inert={!open}>
      <div
        onClick={onClose}
        className={cn("absolute inset-0 bg-navy-950/50 backdrop-blur-sm transition-opacity duration-300", open ? "opacity-100" : "opacity-0")}
      />
      <aside
        aria-label="Your wishlist"
        className={cn(
          "absolute right-0 top-0 flex h-full w-[92%] max-w-md flex-col bg-white shadow-2xl transition-transform duration-300",
          open ? "translate-x-0" : "translate-x-full",
        )}
      >
        <div className="flex items-center justify-between border-b border-slate-100 px-6 py-5">
          <div>
            <p className="flex items-center gap-2 text-lg font-bold text-navy-900">
              <Heart className="h-5 w-5 fill-rose-500 text-rose-500" /> Your wishlist
            </p>
            <p className="text-xs text-slate-500">
              {tours.length} saved tour{tours.length === 1 ? "" : "s"}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close wishlist"
            className="grid h-10 w-10 place-items-center rounded-full bg-slate-100 text-navy-900 transition hover:bg-slate-200"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-5">
          {tours.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center text-center">
              <span className="grid h-20 w-20 place-items-center rounded-full bg-rose-50">
                <Heart className="h-9 w-9 text-rose-400" />
              </span>
              <p className="mt-5 font-bold text-navy-900">No saved tours yet</p>
              <p className="mt-1 max-w-xs text-sm text-slate-500">
                Tap the heart on any tour to save it here, then send us one enquiry for all your favourites.
              </p>
              <Link
                to="/tours"
                onClick={onClose}
                className="mt-6 rounded-full bg-navy-900 px-5 py-2.5 text-sm font-bold text-white transition hover:bg-navy-800"
              >
                Browse tours
              </Link>
            </div>
          ) : (
            <ul className="space-y-3">
              {tours.map((t) => (
                <li key={t.slug} className="flex gap-3 rounded-2xl p-2 ring-1 ring-slate-100 transition hover:ring-slate-200">
                  <img src={pexels(t.images[0], 160, 160)} alt="" className="h-20 w-20 shrink-0 rounded-xl object-cover" />
                  <div className="min-w-0 flex-1 py-0.5">
                    <Link
                      to={`/tours/${t.slug}`}
                      onClick={onClose}
                      className="line-clamp-2 text-sm font-bold leading-snug text-navy-900 hover:text-sunset-600"
                    >
                      {t.title}
                    </Link>
                    <p className="mt-1 text-xs text-slate-500">
                      {t.nights}N / {t.nights + 1}D{SETTINGS.showPrices && ` · from ${formatBDT(t.price)}`}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => remove(t.slug)}
                    aria-label={`Remove ${t.title}`}
                    className="grid h-9 w-9 shrink-0 place-items-center self-center rounded-full text-slate-400 transition hover:bg-rose-50 hover:text-rose-500"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        {tours.length > 0 && (
          <div className="space-y-2 border-t border-slate-100 p-5">
            <button
              type="button"
              onClick={enquire}
              className="flex w-full items-center justify-center gap-2 rounded-full bg-sunset-500 py-3.5 text-sm font-bold text-white shadow-lg shadow-sunset-500/30 transition hover:bg-sunset-600"
            >
              <Send className="h-4 w-4" /> Enquire about {tours.length === 1 ? "this tour" : `all ${tours.length} tours`}
            </button>
            <button
              type="button"
              onClick={clear}
              className="w-full rounded-full py-2 text-xs font-semibold text-slate-500 transition hover:text-rose-600"
            >
              Clear wishlist
            </button>
          </div>
        )}
      </aside>
    </div>
  );
}
