import { BadgeCheck, Mail, MapPin, Phone } from "lucide-react";
import { CONTACT, DESTINATIONS, NAV, PAYMENT_METHODS, SITE } from "@/config";
import { Link } from "@/lib/router";
import { mailLink, telLink, waLink } from "@/lib/utils";
import { cn } from "@/utils/cn";
import { Logo } from "./ui/primitives";
import { FacebookIcon, WhatsAppIcon } from "./ui/BrandIcons";
import { Newsletter } from "./ui/Newsletter";

export function Footer() {
  return (
    <footer className="bg-navy-950 text-navy-200 print:hidden">
      <div className="border-b border-white/10">
        <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-6 px-4 py-10 sm:px-6 lg:flex-row lg:items-center lg:px-8">
          <div>
            <p className="text-xl font-bold text-white">Get exclusive travel deals</p>
            <p className="mt-1 text-sm">Offers, visa updates and new tour packages — straight to your inbox.</p>
          </div>
          <Newsletter dark className="w-full max-w-md" />
        </div>
      </div>

      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-2 lg:grid-cols-12 lg:px-8">
        <div className="lg:col-span-4">
          <div className="inline-flex rounded-2xl bg-white px-4 py-2.5">
            <Logo className="h-10 w-auto" />
          </div>
          <p className="mt-5 text-sm leading-relaxed">{SITE.about}</p>
          <p className="mt-4 font-script text-2xl text-sunset-300">{SITE.tagline}</p>
          <div className="mt-5 flex gap-2">
            <a
              href={CONTACT.facebook}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="SAARC Holiday on Facebook"
              className="grid h-10 w-10 place-items-center rounded-full bg-white/10 text-white transition hover:bg-[#1877F2]"
            >
              <FacebookIcon className="h-4 w-4" />
            </a>
            <a
              href={waLink()}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="WhatsApp"
              className="grid h-10 w-10 place-items-center rounded-full bg-white/10 text-white transition hover:bg-[#25D366]"
            >
              <WhatsAppIcon className="h-4 w-4" />
            </a>
            <a
              href={mailLink(CONTACT.emails[0].value)}
              aria-label="Email"
              className="grid h-10 w-10 place-items-center rounded-full bg-white/10 text-white transition hover:bg-lagoon-500"
            >
              <Mail className="h-4 w-4" />
            </a>
          </div>
        </div>

        <div className="lg:col-span-2">
          <h3 className="text-sm font-bold uppercase tracking-[0.18em] text-white">Explore</h3>
          <ul className="mt-5 space-y-2.5 text-sm">
            {NAV.map((n) => (
              <li key={n.label}>
                <Link to={n.to} className="transition hover:text-sunset-300">
                  {n.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div className="lg:col-span-2">
          <h3 className="text-sm font-bold uppercase tracking-[0.18em] text-white">Destinations</h3>
          <ul className="mt-5 space-y-2.5 text-sm">
            {DESTINATIONS.map((d) => (
              <li key={d.id}>
                <Link to={`/destinations/${d.id}`} className="transition hover:text-sunset-300">
                  {d.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div className="lg:col-span-4">
          <h3 className="text-sm font-bold uppercase tracking-[0.18em] text-white">Contact info</h3>
          <ul className="mt-5 space-y-4 text-sm">
            <li className="flex gap-3">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-sunset-400" />
              <a href={CONTACT.map.placeUrl} target="_blank" rel="noopener noreferrer" className="transition hover:text-white">
                {CONTACT.address.full}
              </a>
            </li>
            <li className="flex gap-3">
              <Phone className="mt-0.5 h-4 w-4 shrink-0 text-sunset-400" />
              <span className="flex flex-col gap-1">
                {CONTACT.phones.map((p) => (
                  <a key={p.value} href={telLink(p.value)} className="transition hover:text-white">
                    {p.display}
                  </a>
                ))}
              </span>
            </li>
            <li className="flex gap-3">
              <Mail className="mt-0.5 h-4 w-4 shrink-0 text-sunset-400" />
              <span className="flex flex-col gap-1">
                {CONTACT.emails.map((e) => (
                  <a key={e.value} href={mailLink(e.value)} className="break-all transition hover:text-white">
                    {e.value}
                  </a>
                ))}
              </span>
            </li>
          </ul>
          <p className="mt-6 text-xs font-bold uppercase tracking-[0.18em] text-white">We accept</p>
          <ul className="mt-3 flex flex-wrap gap-2">
            {PAYMENT_METHODS.map((p) => (
              <li
                key={p.name}
                className={cn("rounded-lg bg-white px-3 py-1.5 text-xs font-extrabold", p.name === "VISA" && "italic tracking-wider")}
                style={{ color: p.color }}
              >
                {p.name}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-3 px-4 py-6 text-xs sm:flex-row sm:px-6 lg:px-8">
          <p>© {new Date().getFullYear()} SAARC Holiday. All rights reserved.</p>
          <p className="flex items-center gap-1.5">
            <BadgeCheck className="h-4 w-4 text-sunset-400" />
            {SITE.membership} — Tour Operators Association of Bangladesh
          </p>
        </div>
      </div>
    </footer>
  );
}
