import type { ComponentType, InputHTMLAttributes, ReactNode } from "react";
import { Check, CircleAlert, Minus, Plus } from "lucide-react";
import { cn } from "@/utils/cn";

export type IconType = ComponentType<{ className?: string }>;

export function Label({
  htmlFor,
  children,
  optional,
  className,
}: {
  htmlFor?: string;
  children: ReactNode;
  optional?: boolean;
  className?: string;
}) {
  const cls = cn("flex items-center gap-2 text-sm font-semibold text-navy-900", className);
  const badge = optional && (
    <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-slate-400">Optional</span>
  );
  return htmlFor ? (
    <label htmlFor={htmlFor} className={cls}>
      {children}
      {badge}
    </label>
  ) : (
    <p className={cls}>
      {children}
      {badge}
    </p>
  );
}

export function FieldError({ id, message }: { id?: string; message?: string }) {
  if (!message) return null;
  return (
    <p id={id} role="alert" className="mt-1.5 flex animate-fade-up items-center gap-1.5 text-xs font-medium text-rose-600">
      <CircleAlert className="h-3.5 w-3.5 shrink-0" />
      {message}
    </p>
  );
}

export function inputClass(invalid?: boolean, withIcon?: boolean) {
  return cn(
    "block min-h-[48px] w-full rounded-xl border bg-white py-3 pr-4 text-sm text-slate-800 shadow-sm transition placeholder:text-slate-400 focus:outline-none focus:ring-4",
    withIcon ? "pl-11" : "pl-4",
    invalid
      ? "border-rose-300 bg-rose-50/40 focus:border-rose-400 focus:ring-rose-100"
      : "border-slate-200 hover:border-slate-300 focus:border-lagoon-400 focus:ring-lagoon-100",
  );
}

interface TextFieldProps extends Omit<InputHTMLAttributes<HTMLInputElement>, "onChange" | "value"> {
  id: string;
  label: string;
  value: string;
  onChange: (v: string) => void;
  error?: string;
  icon?: IconType;
  optional?: boolean;
  hint?: string;
  trailing?: ReactNode;
}

export function TextField({ id, label, value, onChange, error, icon: Icon, optional, hint, trailing, className, ...rest }: TextFieldProps) {
  return (
    <div className={className}>
      <Label htmlFor={id} optional={optional}>
        {label}
      </Label>
      <div className="relative mt-2">
        {Icon && <Icon className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />}
        <input
          id={id}
          name={id}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          aria-invalid={!!error}
          aria-describedby={error ? `${id}-error` : hint ? `${id}-hint` : undefined}
          className={inputClass(!!error, !!Icon)}
          {...rest}
        />
        {trailing && <div className="absolute right-3 top-1/2 -translate-y-1/2">{trailing}</div>}
      </div>
      {hint && !error && (
        <p id={`${id}-hint`} className="mt-1.5 text-xs text-slate-400">
          {hint}
        </p>
      )}
      <FieldError id={`${id}-error`} message={error} />
    </div>
  );
}

export function Chips({
  options,
  value,
  onChange,
  className,
  size = "md",
  ariaLabel,
  allowDeselect = true,
}: {
  options: readonly string[];
  value: string;
  onChange: (v: string) => void;
  className?: string;
  size?: "sm" | "md";
  ariaLabel?: string;
  allowDeselect?: boolean;
}) {
  return (
    <div role="radiogroup" aria-label={ariaLabel} className={cn("flex flex-wrap gap-2", className)}>
      {options.map((o) => {
        const active = value === o;
        return (
          <button
            key={o}
            type="button"
            role="radio"
            aria-checked={active}
            onClick={() => onChange(active && allowDeselect ? "" : o)}
            className={cn(
              "inline-flex items-center rounded-full border font-semibold transition-all duration-200 active:scale-95",
              size === "sm" ? "px-3 py-1.5 text-xs" : "px-4 py-2 text-sm",
              active
                ? "border-navy-900 bg-navy-900 text-white shadow-md shadow-navy-900/20"
                : "border-slate-200 bg-white text-slate-600 hover:border-slate-300 hover:bg-slate-50",
            )}
          >
            {active && <Check className="-ml-0.5 mr-1 h-3.5 w-3.5" strokeWidth={3} />}
            {o}
          </button>
        );
      })}
    </div>
  );
}

export function Stepper({
  label,
  hint,
  value,
  min,
  max,
  onChange,
}: {
  label: string;
  hint?: string;
  value: number;
  min: number;
  max: number;
  onChange: (v: number) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white px-4 py-3">
      <div>
        <p className="text-sm font-semibold text-navy-900">{label}</p>
        {hint && <p className="text-xs text-slate-400">{hint}</p>}
      </div>
      <div className="flex items-center gap-2.5">
        <button
          type="button"
          onClick={() => onChange(Math.max(min, value - 1))}
          disabled={value <= min}
          aria-label={`Fewer ${label.toLowerCase()}`}
          className="grid h-9 w-9 place-items-center rounded-full border border-slate-200 text-navy-900 transition hover:border-navy-900 hover:bg-navy-900 hover:text-white active:scale-90 disabled:pointer-events-none disabled:opacity-30"
        >
          <Minus className="h-4 w-4" />
        </button>
        <span key={value} aria-live="polite" className="w-7 animate-pop text-center text-lg font-bold tabular-nums text-navy-900">
          {value}
        </span>
        <button
          type="button"
          onClick={() => onChange(Math.min(max, value + 1))}
          disabled={value >= max}
          aria-label={`More ${label.toLowerCase()}`}
          className="grid h-9 w-9 place-items-center rounded-full border border-slate-200 text-navy-900 transition hover:border-navy-900 hover:bg-navy-900 hover:text-white active:scale-90 disabled:pointer-events-none disabled:opacity-30"
        >
          <Plus className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className="inline-flex items-center gap-2.5 text-sm font-medium text-slate-600"
    >
      <span className={cn("relative inline-flex h-6 w-11 shrink-0 rounded-full transition-colors duration-200", checked ? "bg-lagoon-500" : "bg-slate-200")}>
        <span
          className={cn(
            "absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform duration-200",
            checked ? "translate-x-[22px]" : "translate-x-0.5",
          )}
        />
      </span>
      {label}
    </button>
  );
}
