import { useMemo, type CSSProperties } from "react";
import { Copy, Mail, MessageCircle, Phone, PlaneTakeoff, RotateCcw, Search } from "lucide-react";
import { CONTACT } from "@/config";
import { copyText, mailLink, telLink, waLink } from "@/lib/utils";
import { useToast } from "../ui/Toast";
import { WhatsAppIcon } from "../ui/BrandIcons";
import { PREF_LABEL, type EnquiryController } from "./useEnquiry";

const COLORS = ["#f5841f", "#12b0e6", "#0b1f5c", "#34d399", "#fbbf24", "#fb7185"];

function Confetti() {
  const pieces = useMemo(
    () =>
      Array.from({ length: 34 }, (_, i) => ({
        id: i,
        x: Math.round((Math.random() - 0.5) * 560),
        y: Math.round(Math.random() * 320 - 120),
        r: Math.round(Math.random() * 720 - 360),
        w: 6 + Math.round(Math.random() * 6),
        d: Math.random() * 0.25,
        c: COLORS[i % COLORS.length],
      })),
    [],
  );
  return (
    <div aria-hidden className="pointer-events-none absolute left-1/2 top-24">
      {pieces.map((p) => (
        <span
          key={p.id}
          className="absolute block rounded-[2px]"
          style={
            {
              width: p.w,
              height: Math.max(3, p.w * 0.45),
              background: p.c,
              animation: `confetti 1.5s ${p.d}s cubic-bezier(.15,.8,.3,1) forwards`,
              "--x": `${p.x}px`,
              "--y": `${p.y}px`,
              "--r": `${p.r}deg`,
            } as CSSProperties
          }
        />
      ))}
    </div>
  );
}

export function SuccessPanel({ ctl }: { ctl: EnquiryController }) {
  const { result, data, reset } = ctl;
  const toast = useToast();
  if (!result) return null;

  const first = data.name.trim().split(/\s+/)[0] || "traveller";
  const pref = PREF_LABEL[data.contactPref];

  const copy = { title: "", desc: "" };
  if (result.channel === "web") {
    copy.title = `Thank you, ${first}! 🎉`;
    copy.desc = `Your enquiry has been sent to our travel team. We'll contact you by ${pref.toLowerCase()} shortly.`;
  } else if (result.channel === "whatsapp") {
    copy.title = `Almost done, ${first}!`;
    copy.desc = "We've opened WhatsApp with your enquiry ready to go — just tap Send so it reaches our team.";
  } else {
    copy.title = `Almost done, ${first}!`;
    copy.desc = "Your email app should open with your enquiry pre-filled — just hit Send so it reaches our team.";
  }

  const steps = [
    { icon: Search, title: "We review", text: "A travel expert checks your request & availability." },
    { icon: MessageCircle, title: `We reach out`, text: `You'll hear from us via ${pref}.` },
    { icon: PlaneTakeoff, title: "You travel", text: "Get your tailored quote and start packing!" },
  ];

  const copyRef = async () => {
    const ok = await copyText(result.ref);
    toast(ok ? "Reference number copied" : "Couldn't copy", ok ? "success" : "error");
  };

  return (
    <div className="relative overflow-hidden px-6 py-12 text-center sm:px-12 sm:py-14" role="status">
      <Confetti />
      <div className="mx-auto grid h-20 w-20 animate-pop place-items-center rounded-full bg-emerald-50 ring-8 ring-emerald-50/50">
        <svg viewBox="0 0 52 52" className="h-12 w-12" aria-hidden>
          <circle cx="26" cy="26" r="23" fill="none" stroke="#10b981" strokeWidth="3" strokeDasharray="145" strokeDashoffset="145" className="animate-draw" />
          <path
            d="M15 27l7 7 15-15"
            fill="none"
            stroke="#10b981"
            strokeWidth="4"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeDasharray="40"
            strokeDashoffset="40"
            className="animate-draw"
            style={{ animationDelay: "0.6s" }}
          />
        </svg>
      </div>

      <h3 className="mt-6 text-2xl font-extrabold text-navy-900 sm:text-3xl">{copy.title}</h3>
      <p className="mx-auto mt-3 max-w-md text-slate-500">{copy.desc}</p>

      <div className="mx-auto mt-6 inline-flex items-center gap-3 rounded-2xl border border-dashed border-slate-300 bg-slate-50 py-2 pl-5 pr-2">
        <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Reference</span>
        <span className="font-mono text-lg font-bold text-navy-900">{result.ref}</span>
        <button
          type="button"
          onClick={copyRef}
          aria-label="Copy reference number"
          className="grid h-9 w-9 place-items-center rounded-xl bg-white text-slate-500 shadow-sm transition hover:bg-navy-900 hover:text-white"
        >
          <Copy className="h-4 w-4" />
        </button>
      </div>

      {result.channel !== "web" && (
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          {result.channel === "whatsapp" ? (
            <a
              href={waLink(result.text)}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full bg-[#25D366] px-5 py-3 text-sm font-bold text-white shadow-lg shadow-emerald-500/30 transition hover:bg-[#1ebe5a]"
            >
              <WhatsAppIcon className="h-4 w-4" /> WhatsApp didn&apos;t open? Tap here
            </a>
          ) : (
            <a
              href={mailLink(CONTACT.emails[0].value, result.subject, result.text)}
              className="inline-flex items-center gap-2 rounded-full bg-lagoon-500 px-5 py-3 text-sm font-bold text-white shadow-lg shadow-lagoon-500/30 transition hover:bg-lagoon-600"
            >
              <Mail className="h-4 w-4" /> Open email again
            </a>
          )}
        </div>
      )}

      <ol className="mx-auto mt-10 grid max-w-2xl gap-3 text-left sm:grid-cols-3">
        {steps.map(({ icon: Icon, title, text }, i) => (
          <li key={title} className="animate-fade-up rounded-2xl border border-slate-100 bg-white p-4 shadow-sm" style={{ animationDelay: `${0.5 + i * 0.12}s` }}>
            <span className="flex items-center gap-2">
              <span className="grid h-8 w-8 place-items-center rounded-lg bg-sunset-100 text-sunset-600">
                <Icon className="h-4 w-4" />
              </span>
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Step {i + 1}</span>
            </span>
            <p className="mt-3 text-sm font-bold text-navy-900">{title}</p>
            <p className="mt-0.5 text-xs leading-relaxed text-slate-500">{text}</p>
          </li>
        ))}
      </ol>

      <div className="mt-10 flex flex-wrap justify-center gap-3">
        <a
          href={telLink(CONTACT.phones[0].value)}
          className="inline-flex items-center gap-2 rounded-full bg-navy-900 px-5 py-3 text-sm font-bold text-white transition hover:bg-navy-800"
        >
          <Phone className="h-4 w-4" /> Need it urgently? Call us
        </a>
        <button
          type="button"
          onClick={reset}
          className="inline-flex items-center gap-2 rounded-full border border-slate-200 px-5 py-3 text-sm font-bold text-navy-900 transition hover:bg-slate-50"
        >
          <RotateCcw className="h-4 w-4" /> Send another enquiry
        </button>
      </div>
    </div>
  );
}
