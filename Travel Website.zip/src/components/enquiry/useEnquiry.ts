import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { CONTACT, DESTINATIONS, FORM, SERVICES, SITE, type ServiceId } from "@/config";
import { consumePendingEnquiry, ENQUIRY_EVENT, type EnquiryPreset } from "@/lib/enquiryBus";
import { formatDate, mailLink, makeRef, nightsBetween, scrollToEl, waLink } from "@/lib/utils";

export type Mode = "plan" | "quick";
export type ContactPref = "whatsapp" | "call" | "email";
export type Channel = "web" | "whatsapp" | "email-client";
export type Status = "idle" | "sending" | "success" | "error";

export interface EnquiryData {
  service: ServiceId | "";
  destinations: string[];
  otherDestination: string;
  departDate: string;
  returnDate: string;
  flexible: boolean;
  preferredMonth: string;
  duration: string;
  adults: number;
  children: number;
  rooms: number;
  budget: string;
  hotelClass: string;
  fromCity: string;
  toCity: string;
  tripType: "round" | "oneway";
  cabin: string;
  passport: string;
  topic: string;
  name: string;
  countryCode: string;
  phone: string;
  email: string;
  contactPref: ContactPref;
  message: string;
  newsletter: boolean;
  /** honeypot – must stay empty */
  website: string;
}

export type Errors = Partial<Record<keyof EnquiryData, string>>;

export const INITIAL_DATA: EnquiryData = {
  service: "",
  destinations: [],
  otherDestination: "",
  departDate: "",
  returnDate: "",
  flexible: false,
  preferredMonth: "",
  duration: "",
  adults: 2,
  children: 0,
  rooms: 1,
  budget: "",
  hotelClass: "",
  fromCity: "Dhaka (DAC)",
  toCity: "",
  tripType: "round",
  cabin: "Economy",
  passport: "",
  topic: "General question",
  name: "",
  countryCode: "+880",
  phone: "",
  email: "",
  contactPref: "whatsapp",
  message: "",
  newsletter: false,
  website: "",
};

export const PLAN_STEPS = [
  { id: "service", label: "Service" },
  { id: "trip", label: "Trip details" },
  { id: "contact", label: "Your details" },
  { id: "review", label: "Review & send" },
] as const;
export const LAST_STEP = PLAN_STEPS.length - 1;

export const PREF_LABEL: Record<ContactPref, string> = { whatsapp: "WhatsApp", call: "Phone call", email: "Email" };

const DRAFT_KEY = "saarc-enquiry-draft-v1";
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

/* ----------------------------- helpers ----------------------------- */

export function phoneInfo(countryCode: string, raw: string) {
  const digits = raw.replace(/\D/g, "");
  if (!digits) return { valid: false, e164: "" };
  if (countryCode === "+880") {
    let d = digits;
    if (d.startsWith("880")) d = d.slice(3);
    if (d.startsWith("0")) d = d.slice(1);
    return { valid: /^1[3-9]\d{8}$/.test(d), e164: `+880${d}` };
  }
  const d = digits.replace(/^0+/, "");
  return { valid: d.length >= 6 && d.length <= 14, e164: `${countryCode}${d}` };
}

export function validate(d: EnquiryData, mode: Mode, step: number): Errors {
  const e: Errors = {};
  const contact = () => {
    if (d.name.trim().length < 2) e.name = "Please enter your full name.";
    if (!d.phone.trim()) e.phone = "We need a phone number to reach you.";
    else if (!phoneInfo(d.countryCode, d.phone).valid)
      e.phone = d.countryCode === "+880" ? "Enter a valid Bangladeshi mobile number, e.g. 01712-345678." : "Please enter a valid phone number.";
    if (d.email.trim() && !EMAIL_RE.test(d.email.trim())) e.email = "This email address doesn't look right.";
    else if (!d.email.trim() && d.contactPref === "email") e.email = "Add your email so we can reply by email.";
  };

  if (mode === "quick") {
    contact();
    if (d.message.trim().length < 10) e.message = "Please write a short message (at least 10 characters).";
    return e;
  }

  if (step === 0 && !d.service) e.service = "Please choose what you need help with.";

  if (step === 1) {
    const s = d.service;
    if (s === "air") {
      if (!d.fromCity.trim()) e.fromCity = "Where are you flying from?";
      if (!d.toCity.trim()) e.toCity = "Where would you like to fly to?";
      if (!d.departDate) e.departDate = "Choose a departure date.";
      if (d.tripType === "round" && d.departDate && d.returnDate && d.returnDate < d.departDate)
        e.returnDate = "Return date must be after departure.";
    } else {
      if (s !== "other" && d.destinations.length === 0 && !d.otherDestination.trim())
        e.destinations = "Pick at least one destination — or type your own below.";
      if (!d.flexible) {
        if (s === "hotel") {
          if (!d.departDate) e.departDate = "Choose a check-in date.";
          if (!d.returnDate) e.returnDate = "Choose a check-out date.";
          else if (d.departDate && d.returnDate <= d.departDate) e.returnDate = "Check-out must be after check-in.";
        } else {
          if ((s === "tour" || s === "group") && !d.departDate) e.departDate = "Choose a travel date — or mark your dates as flexible.";
          if (d.departDate && d.returnDate && d.returnDate < d.departDate) e.returnDate = "Return date must be after your travel date.";
        }
      }
    }
  }

  if (step === 2) contact();
  return e;
}

function validateAll(d: EnquiryData, mode: Mode): { errors: Errors; step: number } {
  if (mode === "quick") return { errors: validate(d, "quick", 0), step: 0 };
  for (let s = 0; s < LAST_STEP; s++) {
    const errors = validate(d, "plan", s);
    if (Object.keys(errors).length) return { errors, step: s };
  }
  return { errors: {}, step: LAST_STEP };
}

export function destinationText(d: EnquiryData) {
  const names = DESTINATIONS.filter((x) => d.destinations.includes(x.id)).map((x) => x.name);
  if (d.otherDestination.trim()) names.push(d.otherDestination.trim());
  return names.join(", ");
}

export function datesText(d: EnquiryData) {
  if (d.flexible && d.service !== "air") return d.preferredMonth ? `Flexible · ${d.preferredMonth}` : "Flexible dates";
  if (!d.departDate) return "";
  const oneWay = d.service === "visa" || (d.service === "air" && d.tripType === "oneway");
  if (!oneWay && d.returnDate) {
    const n = nightsBetween(d.departDate, d.returnDate);
    return `${formatDate(d.departDate)} → ${formatDate(d.returnDate)}${n > 0 ? ` (${n} night${n > 1 ? "s" : ""})` : ""}`;
  }
  return formatDate(d.departDate);
}

export function travellersText(d: EnquiryData) {
  const parts = [`${d.adults} adult${d.adults > 1 ? "s" : ""}`];
  if (d.children) parts.push(`${d.children} child${d.children > 1 ? "ren" : ""}`);
  return parts.join(", ");
}

export interface Row {
  label: string;
  value: string;
}

export function tripRows(d: EnquiryData): Row[] {
  const rows: Row[] = [];
  const svc = SERVICES.find((s) => s.id === d.service);
  if (svc) rows.push({ label: "Service", value: svc.label });
  if (d.service === "air") {
    rows.push({ label: "Route", value: `${d.fromCity.trim() || "—"} → ${d.toCity.trim() || "—"}` });
    rows.push({ label: "Trip type", value: d.tripType === "round" ? "Round trip" : "One way" });
    rows.push({ label: "Cabin", value: d.cabin });
  } else {
    const dest = destinationText(d);
    if (dest) rows.push({ label: "Destination", value: dest });
  }
  const dates = datesText(d);
  if (dates) rows.push({ label: d.service === "hotel" ? "Stay" : "Dates", value: dates });
  if (d.flexible && d.duration && d.service !== "air") rows.push({ label: "Trip length", value: d.duration });
  rows.push({
    label: d.service === "air" ? "Passengers" : d.service === "visa" ? "Applicants" : d.service === "hotel" ? "Guests" : "Travellers",
    value: travellersText(d),
  });
  if (d.service === "hotel") rows.push({ label: "Rooms", value: String(d.rooms) });
  if (d.budget) rows.push({ label: "Budget / person", value: d.budget });
  if (d.hotelClass) rows.push({ label: "Hotel", value: d.hotelClass });
  if (d.passport) rows.push({ label: "Passport valid 6+ months", value: d.passport });
  return rows;
}

export function contactRows(d: EnquiryData): Row[] {
  const rows: Row[] = [
    { label: "Name", value: d.name.trim() },
    { label: "Phone", value: phoneInfo(d.countryCode, d.phone).e164 || d.phone },
  ];
  if (d.email.trim()) rows.push({ label: "Email", value: d.email.trim() });
  rows.push({ label: "Preferred contact", value: PREF_LABEL[d.contactPref] });
  return rows;
}

function subjectFor(d: EnquiryData, mode: Mode, ref: string) {
  const what = mode === "quick" ? d.topic : SERVICES.find((s) => s.id === d.service)?.label ?? "Travel";
  return `${what} enquiry – ${d.name.trim()} (${ref})`;
}

export function buildMessage(d: EnquiryData, mode: Mode, ref: string) {
  const lines = [`*New enquiry – ${SITE.name} website*`, `Ref: ${ref}`, ""];
  if (mode === "quick") lines.push(`Topic: ${d.topic}`);
  else tripRows(d).forEach((r) => lines.push(`${r.label}: ${r.value}`));
  lines.push("");
  contactRows(d).forEach((r) => lines.push(`${r.label}: ${r.value}`));
  if (d.message.trim()) lines.push("", "Message:", d.message.trim());
  return lines.join("\n");
}

function loadDraft(): { data: EnquiryData; mode: Mode } | null {
  try {
    const raw = localStorage.getItem(DRAFT_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return { data: { ...INITIAL_DATA, ...parsed.data, website: "" }, mode: parsed.mode === "quick" ? "quick" : "plan" };
  } catch {
    return null;
  }
}

const isDirty = (d: EnquiryData) => JSON.stringify({ ...d, website: "" }) !== JSON.stringify(INITIAL_DATA);

/* ------------------------------- hook ------------------------------- */

export function useEnquiry() {
  const [draft] = useState(loadDraft);
  const [data, setData] = useState<EnquiryData>(() => draft?.data ?? INITIAL_DATA);
  const [mode, setModeState] = useState<Mode>(() => draft?.mode ?? "plan");
  const [step, setStep] = useState(0);
  const [showErrors, setShowErrors] = useState(false);
  const [status, setStatus] = useState<Status>("idle");
  const [errorMsg, setErrorMsg] = useState("");
  const [result, setResult] = useState<{ ref: string; channel: Channel; text: string; subject: string } | null>(null);
  const [savedAt, setSavedAt] = useState<Date | null>(null);
  const [restored, setRestored] = useState(() => !!draft && isDirty(draft.data));
  const [flash, setFlash] = useState(false);
  const formRef = useRef<HTMLDivElement>(null);

  const errors = useMemo(() => (showErrors ? validate(data, mode, step) : {}), [showErrors, data, mode, step]);

  const set = useCallback(<K extends keyof EnquiryData>(key: K, value: EnquiryData[K]) => {
    setData((d) => ({ ...d, [key]: value }));
  }, []);

  const scrollToForm = useCallback(() => {
    const el = formRef.current;
    if (el && el.getBoundingClientRect().top < 70) scrollToEl(el);
  }, []);

  const focusFirstInvalid = useCallback(() => {
    window.setTimeout(() => {
      const el = formRef.current?.querySelector<HTMLElement>('[aria-invalid="true"], [data-invalid="true"]');
      if (!el) return;
      el.scrollIntoView({ behavior: "smooth", block: "center" });
      el.focus({ preventScroll: true });
    }, 60);
  }, []);

  const setMode = useCallback((m: Mode) => {
    setModeState(m);
    setShowErrors(false);
    setStatus((s) => (s === "error" ? "idle" : s));
  }, []);

  const chooseService = useCallback((id: ServiceId) => {
    setData((d) => ({ ...d, service: id }));
    setShowErrors(false);
    window.setTimeout(() => setStep((s) => (s === 0 ? 1 : s)), 280);
  }, []);

  const toggleDestination = useCallback((id: string) => {
    setData((d) => ({
      ...d,
      destinations: d.destinations.includes(id) ? d.destinations.filter((x) => x !== id) : [...d.destinations, id],
    }));
  }, []);

  const next = useCallback(() => {
    const e = validate(data, mode, step);
    if (Object.keys(e).length) {
      setShowErrors(true);
      focusFirstInvalid();
      return;
    }
    setShowErrors(false);
    setStep((s) => Math.min(s + 1, LAST_STEP));
    scrollToForm();
  }, [data, mode, step, focusFirstInvalid, scrollToForm]);

  const back = useCallback(() => {
    setShowErrors(false);
    setStep((s) => Math.max(0, s - 1));
    scrollToForm();
  }, [scrollToForm]);

  const goTo = useCallback((i: number) => {
    setShowErrors(false);
    setStep((s) => (i <= s ? i : s));
  }, []);

  const finish = useCallback(
    (ref: string, channel: Channel, text: string, subject: string) => {
      setResult({ ref, channel, text, subject });
      setStatus("success");
      setShowErrors(false);
      setSavedAt(null);
      setRestored(false);
      try {
        localStorage.removeItem(DRAFT_KEY);
      } catch {
        /* ignore */
      }
      scrollToForm();
    },
    [scrollToForm],
  );

  const submit = useCallback(
    (preferred: "auto" | "whatsapp" | "email-client" = "auto") => {
      const { errors: e, step: badStep } = validateAll(data, mode);
      if (Object.keys(e).length) {
        if (mode === "plan") setStep(badStep);
        setShowErrors(true);
        focusFirstInvalid();
        return;
      }

      const ref = makeRef();
      const text = buildMessage(data, mode, ref);
      const subject = subjectFor(data, mode, ref);

      // Bots fill the hidden field – pretend everything went fine.
      if (data.website) return finish(ref, "web", text, subject);

      const channel: Channel = preferred === "auto" ? (FORM.web3formsAccessKey ? "web" : "whatsapp") : preferred;

      if (channel === "whatsapp") {
        window.open(waLink(text), "_blank", "noopener,noreferrer");
        return finish(ref, "whatsapp", text, subject);
      }
      if (channel === "email-client") {
        window.location.href = mailLink(CONTACT.emails[0].value, subject, text);
        return finish(ref, "email-client", text, subject);
      }

      setStatus("sending");
      setErrorMsg("");
      const fd = new FormData();
      fd.append("access_key", FORM.web3formsAccessKey);
      fd.append("subject", `New ${subject}`);
      fd.append("from_name", `${SITE.name} Website`);
      fd.append("name", data.name.trim());
      if (data.email.trim()) fd.append("email", data.email.trim());
      fd.append("phone", phoneInfo(data.countryCode, data.phone).e164);
      fd.append("reference", ref);
      if (mode === "quick") fd.append("topic", data.topic);
      else tripRows(data).forEach((r) => fd.append(r.label, r.value));
      fd.append("preferred_contact", PREF_LABEL[data.contactPref]);
      fd.append("message", data.message.trim() || "—");
      if (data.newsletter) fd.append("newsletter", "Yes – send me offers");
      fd.append("page", window.location.href);

      fetch("https://api.web3forms.com/submit", { method: "POST", headers: { Accept: "application/json" }, body: fd })
        .then((r) => r.json())
        .then((res: { success?: boolean; message?: string }) => {
          if (res.success) finish(ref, "web", text, subject);
          else {
            setStatus("error");
            setErrorMsg(res.message || "We couldn't send your enquiry right now.");
          }
        })
        .catch(() => {
          setStatus("error");
          setErrorMsg("Network error — please check your internet connection and try again.");
        });
    },
    [data, mode, finish, focusFirstInvalid],
  );

  const reset = useCallback(() => {
    setData(INITIAL_DATA);
    setStep(0);
    setShowErrors(false);
    setStatus("idle");
    setResult(null);
    setErrorMsg("");
    setSavedAt(null);
    setRestored(false);
    try {
      localStorage.removeItem(DRAFT_KEY);
    } catch {
      /* ignore */
    }
  }, []);

  /* Autosave draft */
  useEffect(() => {
    if (status === "success") return;
    if (restored && draft && JSON.stringify(data) !== JSON.stringify(draft.data)) setRestored(false);
    const t = window.setTimeout(() => {
      try {
        if (isDirty(data)) {
          localStorage.setItem(DRAFT_KEY, JSON.stringify({ data: { ...data, website: "" }, mode }));
          setSavedAt(new Date());
        } else {
          localStorage.removeItem(DRAFT_KEY);
          setSavedAt(null);
        }
      } catch {
        /* storage unavailable */
      }
    }, 700);
    return () => window.clearTimeout(t);
  }, [data, mode, status, restored, draft]);

  /* Presets from anywhere on the site */
  const applyPreset = useCallback((p: EnquiryPreset) => {
    setStatus((s) => (s === "success" || s === "error" ? "idle" : s));
    setResult(null);
    setModeState(p.mode ?? "plan");
    setData((d) => ({
      ...d,
      ...(p.service ? { service: p.service } : {}),
      ...(p.destinations ? { destinations: p.destinations } : {}),
      ...(p.message ? { message: p.message } : {}),
      ...(p.topic ? { topic: p.topic } : {}),
      ...(p.departDate ? { departDate: p.departDate, flexible: false } : {}),
      ...(p.adults ? { adults: p.adults } : {}),
      ...(p.children !== undefined ? { children: p.children } : {}),
      ...(p.fromCity ? { fromCity: p.fromCity } : {}),
      ...(p.toCity ? { toCity: p.toCity } : {}),
    }));
    setStep(p.service ? 1 : 0);
    setShowErrors(false);
    setFlash(true);
    window.setTimeout(() => setFlash(false), 1500);
  }, []);

  useEffect(() => {
    const onPreset = (ev: Event) => applyPreset((ev as CustomEvent<EnquiryPreset>).detail ?? {});
    window.addEventListener(ENQUIRY_EVENT, onPreset);
    // Arrived from another page via openEnquiry()
    const pendingPreset = consumePendingEnquiry();
    if (pendingPreset) {
      applyPreset(pendingPreset);
      window.setTimeout(() => scrollToEl(formRef.current), 450);
    }
    return () => window.removeEventListener(ENQUIRY_EVENT, onPreset);
  }, [applyPreset]);

  return {
    data,
    set,
    mode,
    setMode,
    step,
    next,
    back,
    goTo,
    chooseService,
    toggleDestination,
    errors,
    status,
    errorMsg,
    result,
    submit,
    reset,
    savedAt,
    restored,
    flash,
    formRef,
    dirty: isDirty(data),
  };
}

export type EnquiryController = ReturnType<typeof useEnquiry>;
