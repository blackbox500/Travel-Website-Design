import { Plane } from "lucide-react";
import { DESTINATIONS, SERVICES } from "@/config";
import { cn } from "@/utils/cn";
import { cityCode, formatDate, pexels } from "@/lib/utils";
import { phoneInfo, type EnquiryController } from "./useEnquiry";

function Item({ label, value, muted }: { label: string; value: string; muted?: boolean }) {
  return (
    <div className="min-w-0">
      <dt className="text-[10px] font-bold uppercase tracking-[0.15em] text-slate-400">{label}</dt>
      <dd className={cn("mt-0.5 truncate text-sm font-bold", muted ? "text-slate-300" : "text-navy-900")}>{value}</dd>
    </div>
  );
}

/** A boarding pass that fills itself in as the visitor completes the form */
export function TripSummary({ ctl }: { ctl: EnquiryController }) {
  const { data } = ctl;
  const isAir = data.service === "air";
  const dests = DESTINATIONS.filter((d) => data.destinations.includes(d.id));
  const svc = SERVICES.find((s) => s.id === data.service);

  const fromCode = isAir ? cityCode(data.fromCity || "Dhaka") : "DAC";
  const fromName = isAir ? data.fromCity || "Origin" : "Dhaka";
  const toCode = isAir
    ? data.toCity
      ? cityCode(data.toCity)
      : "???"
    : dests[0]?.code ?? (data.otherDestination.trim() ? cityCode(data.otherDestination) : "???");
  const toName = isAir
    ? data.toCity || "Destination"
    : dests.length
      ? dests.map((d) => d.name).join(", ")
      : data.otherDestination.trim() || "Pick a destination";
  const extra = !isAir && dests.length > 1 ? `+${dests.length - 1}` : "";

  const date = data.flexible && !isAir ? data.preferredMonth || "Flexible" : data.departDate ? formatDate(data.departDate, false) : "—";
  const people = `${data.adults} Adult${data.adults > 1 ? "s" : ""}${data.children ? ` · ${data.children} Child` : ""}`;
  const klass = isAir ? data.cabin : data.hotelClass || (data.service === "visa" ? "Visa" : "—");

  const checks = [
    !!data.service,
    isAir ? !!data.toCity.trim() : dests.length > 0 || !!data.otherDestination.trim() || data.service === "other",
    (data.flexible && !isAir) || !!data.departDate,
    data.name.trim().length > 1,
    phoneInfo(data.countryCode, data.phone).valid,
  ];
  const pct = Math.round((checks.filter(Boolean).length / checks.length) * 100);

  return (
    <div className="overflow-hidden rounded-[1.75rem] bg-white shadow-xl shadow-navy-900/[0.06] ring-1 ring-slate-200/70">
      <div className="relative overflow-hidden bg-navy-900 px-6 pb-6 pt-5 text-white">
        <div className="pointer-events-none absolute -right-12 -top-12 h-40 w-40 rounded-full bg-lagoon-500/20 blur-2xl" />
        <div className="relative flex items-center justify-between">
          <span className="text-[11px] font-bold uppercase tracking-[0.22em] text-navy-200">Your boarding pass</span>
          <span key={svc?.id ?? "none"} className="animate-pop rounded-full bg-white/10 px-2.5 py-1 text-[11px] font-semibold">
            {svc?.label ?? "Start planning"}
          </span>
        </div>
        <div className="relative mt-5 flex items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="text-3xl font-extrabold tracking-tight">{fromCode}</p>
            <p className="max-w-[6.5rem] truncate text-xs text-navy-200">{fromName}</p>
          </div>
          <div className="flex flex-1 items-center">
            <span className="h-px flex-1 border-t border-dashed border-white/30" />
            <span className="mx-2 grid h-8 w-8 place-items-center rounded-full bg-sunset-500">
              <Plane className="h-4 w-4 rotate-45" />
            </span>
            <span className="h-px flex-1 border-t border-dashed border-white/30" />
          </div>
          <div className="min-w-0 text-right">
            <p key={toCode} className={cn("animate-pop text-3xl font-extrabold tracking-tight", toCode === "???" && "text-white/30")}>
              {toCode}
              {extra && <span className="ml-1 align-top text-xs font-bold text-sunset-300">{extra}</span>}
            </p>
            <p className="ml-auto max-w-[7.5rem] truncate text-xs text-navy-200">{toName}</p>
          </div>
        </div>
      </div>

      {dests.length > 0 && (
        <div className="flex items-center gap-3 border-b border-slate-100 px-6 py-3">
          <div className="flex -space-x-2">
            {dests.slice(0, 4).map((d) => (
              <img
                key={d.id}
                src={pexels(d.image, 80, 80)}
                alt={d.name}
                className="h-8 w-8 animate-pop rounded-full object-cover ring-2 ring-white"
              />
            ))}
          </div>
          <p className="truncate text-xs font-semibold text-slate-500">{dests.map((d) => d.name).join(" · ")}</p>
        </div>
      )}

      {/* perforation */}
      <div className="relative h-6" aria-hidden>
        <span className="absolute -left-3 top-1/2 h-6 w-6 -translate-y-1/2 rounded-full bg-slate-50 ring-1 ring-slate-200/70" />
        <span className="absolute -right-3 top-1/2 h-6 w-6 -translate-y-1/2 rounded-full bg-slate-50 ring-1 ring-slate-200/70" />
        <span className="absolute inset-x-6 top-1/2 border-t-2 border-dashed border-slate-200" />
      </div>

      <dl className="grid grid-cols-2 gap-x-4 gap-y-4 px-6">
        <Item label="Passenger" value={data.name.trim() || "Your name"} muted={!data.name.trim()} />
        <Item label="Date" value={date} muted={date === "—"} />
        <Item label={isAir ? "Passengers" : "Travellers"} value={people} />
        <Item label="Class" value={klass} muted={klass === "—"} />
      </dl>

      <div className="px-6 pb-6 pt-5">
        <div className="flex items-center justify-between text-xs font-semibold">
          <span className="text-slate-500">Enquiry completeness</span>
          <span className={cn("tabular-nums", pct === 100 ? "text-emerald-600" : "text-navy-900")}>{pct}%</span>
        </div>
        <div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-100">
          <div
            className={cn("h-full rounded-full transition-all duration-700 ease-out", pct === 100 ? "bg-emerald-500" : "bg-linear-to-r from-lagoon-500 to-sunset-500")}
            style={{ width: `${pct}%` }}
          />
        </div>
        <div
          aria-hidden
          className="mt-5 h-10 rounded-sm opacity-80"
          style={{
            background:
              "repeating-linear-gradient(90deg, #0b1f5c 0 2px, transparent 2px 4px, #0b1f5c 4px 5px, transparent 5px 8px, #0b1f5c 8px 11px, transparent 11px 12px, #0b1f5c 12px 13px, transparent 13px 16px)",
          }}
        />
        <p className="mt-2 text-center font-mono text-[10px] tracking-[0.35em] text-slate-400">SAARC · HOLIDAY · {new Date().getFullYear()}</p>
      </div>
    </div>
  );
}
