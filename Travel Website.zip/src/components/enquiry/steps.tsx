import type { ComponentType } from "react";
import {
  ArrowLeftRight,
  BedDouble,
  CalendarDays,
  Check,
  CheckCircle2,
  Lock,
  Luggage,
  Mail,
  MapPin,
  MessageCircle,
  Moon,
  Palmtree,
  Pencil,
  Phone,
  PlaneLanding,
  PlaneTakeoff,
  Stamp,
  User,
  Users,
} from "lucide-react";
import { DESTINATIONS, SERVICES, type ServiceId } from "@/config";
import { cn } from "@/utils/cn";
import { flagUrl, nextMonths, nightsBetween, pexels, todayISO } from "@/lib/utils";
import { WhatsAppIcon } from "../ui/BrandIcons";
import { BUDGETS, CABINS, COUNTRY_CODES, DURATIONS, HOTEL_CLASSES, PASSPORT, SUGGESTIONS, TOPICS } from "./options";
import { Chips, FieldError, Label, Stepper, TextField, Toggle } from "./fields";
import { contactRows, phoneInfo, tripRows, type ContactPref, type EnquiryController, type Row } from "./useEnquiry";

type C = { ctl: EnquiryController };

export const SERVICE_ICONS: Record<ServiceId, ComponentType<{ className?: string }>> = {
  tour: Palmtree,
  visa: Stamp,
  hotel: BedDouble,
  air: PlaneTakeoff,
  group: Users,
  other: MessageCircle,
};

function StepTitle({ title, subtitle }: { title: string; subtitle: string }) {
  return (
    <div>
      <h3 className="text-xl font-bold text-navy-900 sm:text-2xl">{title}</h3>
      <p className="mt-1 text-sm text-slate-500">{subtitle}</p>
    </div>
  );
}

/* ------------------------------ Step 1 ------------------------------ */

export function StepService({ ctl }: C) {
  const { data, chooseService, errors } = ctl;
  return (
    <div>
      <StepTitle title="What can we help you with?" subtitle="Choose one — you'll add the details in the next step." />
      <div
        role="radiogroup"
        aria-label="Service"
        tabIndex={-1}
        data-invalid={!!errors.service}
        className="mt-6 grid grid-cols-2 gap-3 outline-none sm:grid-cols-3"
      >
        {SERVICES.map((s) => {
          const Icon = SERVICE_ICONS[s.id];
          const active = data.service === s.id;
          return (
            <button
              key={s.id}
              type="button"
              role="radio"
              aria-checked={active}
              onClick={() => chooseService(s.id)}
              className={cn(
                "group relative flex flex-col items-start rounded-2xl border-2 p-4 text-left transition-all duration-200 hover:-translate-y-0.5 active:scale-[0.98] sm:p-5",
                active
                  ? "border-lagoon-500 bg-lagoon-50/70 shadow-lg shadow-lagoon-500/10"
                  : "border-slate-100 bg-white hover:border-slate-200 hover:shadow-md",
              )}
            >
              <span
                className={cn(
                  "grid h-11 w-11 place-items-center rounded-xl transition",
                  active ? "bg-lagoon-500 text-white" : "bg-slate-100 text-navy-800 group-hover:bg-sunset-100 group-hover:text-sunset-600",
                )}
              >
                <Icon className="h-5 w-5" />
              </span>
              <span className="mt-4 text-sm font-bold text-navy-900 sm:text-base">{s.label}</span>
              <span className="mt-1 text-xs leading-relaxed text-slate-500">{s.description}</span>
              <span
                className={cn(
                  "absolute right-3 top-3 grid h-6 w-6 place-items-center rounded-full bg-lagoon-500 text-white transition-transform duration-200",
                  active ? "scale-100" : "scale-0",
                )}
              >
                <Check className="h-3.5 w-3.5" strokeWidth={3} />
              </span>
            </button>
          );
        })}
      </div>
      <FieldError message={errors.service} />
    </div>
  );
}

/* ------------------------------ Step 2 ------------------------------ */

function DestinationPicker({ ctl }: C) {
  const { data, toggleDestination, set, errors } = ctl;
  const optional = data.service === "other";
  return (
    <div>
      <div className="flex items-end justify-between gap-4">
        <Label optional={optional}>Where would you like to go?</Label>
        <span className="text-xs font-medium text-slate-400">
          {data.destinations.length ? `${data.destinations.length} selected` : "Select one or more"}
        </span>
      </div>
      <div tabIndex={-1} data-invalid={!!errors.destinations} className="mt-3 grid grid-cols-2 gap-3 outline-none sm:grid-cols-4">
        {DESTINATIONS.map((d) => {
          const active = data.destinations.includes(d.id);
          return (
            <button
              key={d.id}
              type="button"
              aria-pressed={active}
              onClick={() => toggleDestination(d.id)}
              className={cn(
                "group relative aspect-[4/3] overflow-hidden rounded-2xl text-left transition-all duration-300 active:scale-[0.97]",
                active ? "shadow-xl shadow-sunset-500/25 ring-[3px] ring-sunset-500 ring-offset-2" : "ring-1 ring-slate-200 hover:shadow-lg",
              )}
            >
              <img
                src={pexels(d.image, 400, 300)}
                alt=""
                loading="lazy"
                className="absolute inset-0 h-full w-full object-cover transition duration-700 group-hover:scale-110"
              />
              <span
                className={cn(
                  "absolute inset-0 bg-linear-to-t transition",
                  active ? "from-navy-950/90 via-navy-900/45 to-sunset-500/25" : "from-navy-950/85 via-navy-950/20 to-transparent",
                )}
              />
              <span className="absolute left-2.5 top-2.5 rounded-md bg-white/90 p-0.5 shadow">
                <img src={flagUrl(d.flag)} alt="" loading="lazy" className="h-3 w-[18px] rounded-[2px] object-cover" />
              </span>
              <span
                className={cn(
                  "absolute right-2.5 top-2.5 grid h-6 w-6 place-items-center rounded-full border-2 transition",
                  active ? "scale-110 border-sunset-500 bg-sunset-500 text-white" : "border-white/80 bg-black/20 text-transparent",
                )}
              >
                <Check className="h-3.5 w-3.5" strokeWidth={3} />
              </span>
              <span className="absolute inset-x-3 bottom-2.5">
                <span className="block text-sm font-bold text-white">{d.name}</span>
                <span className="block truncate text-[11px] text-white/75">{d.tagline}</span>
              </span>
            </button>
          );
        })}
      </div>
      <div className="relative mt-3">
        <MapPin className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
        <input
          aria-label="Other destination"
          value={data.otherDestination}
          onChange={(e) => set("otherDestination", e.target.value)}
          placeholder="Somewhere else? e.g. Maldives, Dubai, Sri Lanka, Vietnam…"
          className="block min-h-[48px] w-full rounded-xl border border-dashed border-slate-300 bg-white py-3 pl-11 pr-4 text-sm shadow-sm transition placeholder:text-slate-400 hover:border-slate-400 focus:border-lagoon-400 focus:outline-none focus:ring-4 focus:ring-lagoon-100"
        />
      </div>
      <FieldError message={errors.destinations} />
    </div>
  );
}

function RouteBlock({ ctl }: C) {
  const { data, set, errors } = ctl;
  const swap = () => {
    set("fromCity", data.toCity);
    set("toCity", data.fromCity);
  };
  return (
    <div className="space-y-5">
      <Chips
        ariaLabel="Trip type"
        options={["Round trip", "One way"]}
        value={data.tripType === "round" ? "Round trip" : "One way"}
        onChange={(v) => set("tripType", v === "One way" ? "oneway" : "round")}
        allowDeselect={false}
      />
      <div className="relative grid gap-4 sm:grid-cols-2">
        <TextField id="fromCity" label="Flying from" icon={PlaneTakeoff} value={data.fromCity} onChange={(v) => set("fromCity", v)} error={errors.fromCity} placeholder="e.g. Dhaka (DAC)" />
        <button
          type="button"
          onClick={swap}
          aria-label="Swap origin and destination"
          className="absolute left-1/2 top-[38px] z-10 hidden h-9 w-9 -translate-x-1/2 place-items-center rounded-full border border-slate-200 bg-white text-navy-900 shadow-md transition hover:rotate-180 hover:bg-navy-900 hover:text-white sm:grid"
        >
          <ArrowLeftRight className="h-4 w-4" />
        </button>
        <TextField id="toCity" label="Flying to" icon={PlaneLanding} value={data.toCity} onChange={(v) => set("toCity", v)} error={errors.toCity} placeholder="e.g. Bangkok, Kathmandu, Dubai" />
      </div>
      <div>
        <Label>Cabin class</Label>
        <Chips className="mt-2" ariaLabel="Cabin class" options={CABINS} value={data.cabin} onChange={(v) => set("cabin", v)} allowDeselect={false} />
      </div>
    </div>
  );
}

function DatesBlock({ ctl }: C) {
  const { data, set, errors } = ctl;
  const s = data.service;
  const isHotel = s === "hotel";
  const isAir = s === "air";
  const isVisa = s === "visa";
  const departLabel = isHotel ? "Check-in" : isAir ? "Departure" : isVisa ? "Planned travel date" : "Travel date";
  const returnLabel = isHotel ? "Check-out" : "Return date";
  const showReturn = !isVisa && !(isAir && data.tripType === "oneway");
  const canFlex = !isAir;
  const flexible = canFlex && data.flexible;
  const nights = data.departDate && data.returnDate ? nightsBetween(data.departDate, data.returnDate) : 0;
  const today = todayISO();

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Label optional={isVisa}>{isHotel ? "When is your stay?" : "When are you travelling?"}</Label>
        {canFlex && <Toggle checked={data.flexible} onChange={(v) => set("flexible", v)} label="My dates are flexible" />}
      </div>

      {flexible ? (
        <div className="mt-4 space-y-4 rounded-2xl bg-slate-50 p-4">
          <div>
            <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-400">Preferred month</p>
            <Chips size="sm" ariaLabel="Preferred month" options={nextMonths(8)} value={data.preferredMonth} onChange={(v) => set("preferredMonth", v)} />
          </div>
          {!isHotel && !isVisa && (
            <div>
              <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-400">Trip length</p>
              <Chips size="sm" ariaLabel="Trip length" options={DURATIONS} value={data.duration} onChange={(v) => set("duration", v)} />
            </div>
          )}
        </div>
      ) : (
        <div className={cn("mt-3 grid gap-4", showReturn && "sm:grid-cols-2")}>
          <TextField
            id="departDate"
            type="date"
            label={departLabel}
            icon={CalendarDays}
            min={today}
            value={data.departDate}
            onChange={(v) => set("departDate", v)}
            error={errors.departDate}
          />
          {showReturn && (
            <TextField
              id="returnDate"
              type="date"
              label={returnLabel}
              icon={CalendarDays}
              optional={!isHotel}
              min={data.departDate || today}
              value={data.returnDate}
              onChange={(v) => set("returnDate", v)}
              error={errors.returnDate}
            />
          )}
        </div>
      )}

      {!flexible && showReturn && nights > 0 && (
        <p className="mt-3 inline-flex animate-pop items-center gap-1.5 rounded-full bg-lagoon-50 px-3 py-1 text-xs font-semibold text-lagoon-700">
          <Moon className="h-3.5 w-3.5" />
          {nights} night{nights > 1 ? "s" : ""} · {nights + 1} days
        </p>
      )}
    </div>
  );
}

export function StepTrip({ ctl }: C) {
  const { data, set } = ctl;
  const s = data.service;
  const svc = SERVICES.find((x) => x.id === s);
  const peopleLabel = s === "air" ? "Passengers" : s === "visa" ? "Applicants" : s === "hotel" ? "Guests" : "Travellers";
  const showBudget = s === "tour" || s === "group" || s === "other";
  const showHotel = s === "tour" || s === "group" || s === "hotel";

  return (
    <div className="space-y-8">
      <StepTitle
        title={s === "air" ? "Where are you flying?" : "Tell us about your trip"}
        subtitle={`${svc?.label ?? "Your trip"} · the more you share, the more accurate your quote.`}
      />

      {s === "air" ? <RouteBlock ctl={ctl} /> : <DestinationPicker ctl={ctl} />}

      <DatesBlock ctl={ctl} />

      <div>
        <Label>{peopleLabel}</Label>
        <div className={cn("mt-3 grid gap-3", s === "hotel" ? "sm:grid-cols-3" : "sm:grid-cols-2")}>
          <Stepper label="Adults" hint="12+ years" value={data.adults} min={1} max={40} onChange={(v) => set("adults", v)} />
          <Stepper label="Children" hint="2–11 years" value={data.children} min={0} max={20} onChange={(v) => set("children", v)} />
          {s === "hotel" && <Stepper label="Rooms" value={data.rooms} min={1} max={20} onChange={(v) => set("rooms", v)} />}
        </div>
      </div>

      {s === "visa" && (
        <div>
          <Label>Is your passport valid for at least 6 more months?</Label>
          <Chips className="mt-3" ariaLabel="Passport validity" options={PASSPORT} value={data.passport} onChange={(v) => set("passport", v)} />
        </div>
      )}

      {(showBudget || showHotel) && (
        <div className="grid gap-8 lg:grid-cols-2">
          {showBudget && (
            <div>
              <Label optional>Budget per person</Label>
              <Chips className="mt-3" size="sm" ariaLabel="Budget per person" options={BUDGETS} value={data.budget} onChange={(v) => set("budget", v)} />
            </div>
          )}
          {showHotel && (
            <div>
              <Label optional>Hotel preference</Label>
              <Chips className="mt-3" size="sm" ariaLabel="Hotel preference" options={HOTEL_CLASSES} value={data.hotelClass} onChange={(v) => set("hotelClass", v)} />
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/* ------------------------------ Step 3 ------------------------------ */

const PREFS: { id: ContactPref; label: string; icon: ComponentType<{ className?: string }> }[] = [
  { id: "whatsapp", label: "WhatsApp", icon: WhatsAppIcon },
  { id: "call", label: "Phone call", icon: Phone },
  { id: "email", label: "Email", icon: Mail },
];

function PhoneField({ ctl }: C) {
  const { data, set, errors } = ctl;
  const valid = phoneInfo(data.countryCode, data.phone).valid;
  return (
    <div>
      <Label htmlFor="phone">Phone / WhatsApp number</Label>
      <div
        className={cn(
          "mt-2 flex min-h-[48px] rounded-xl border bg-white shadow-sm transition focus-within:ring-4",
          errors.phone
            ? "border-rose-300 bg-rose-50/40 focus-within:border-rose-400 focus-within:ring-rose-100"
            : "border-slate-200 hover:border-slate-300 focus-within:border-lagoon-400 focus-within:ring-lagoon-100",
        )}
      >
        <select
          aria-label="Country code"
          value={data.countryCode}
          onChange={(e) => set("countryCode", e.target.value)}
          className="cursor-pointer rounded-l-xl border-r border-slate-200 bg-slate-50 pl-3 pr-1 text-sm font-semibold text-navy-900 focus:outline-none"
        >
          {COUNTRY_CODES.map((c) => (
            <option key={c.iso} value={c.code}>
              {c.iso} {c.code}
            </option>
          ))}
        </select>
        <input
          id="phone"
          name="phone"
          type="tel"
          inputMode="tel"
          autoComplete="tel-national"
          placeholder={data.countryCode === "+880" ? "01XXX-XXXXXX" : "Phone number"}
          value={data.phone}
          onChange={(e) => set("phone", e.target.value.replace(/[^\d\s\-+()]/g, ""))}
          aria-invalid={!!errors.phone}
          aria-describedby={errors.phone ? "phone-error" : undefined}
          className="w-full min-w-0 rounded-r-xl bg-transparent px-4 py-3 text-sm text-slate-800 placeholder:text-slate-400 focus:outline-none"
        />
        {valid && <CheckCircle2 className="mr-3 h-5 w-5 shrink-0 animate-pop self-center text-emerald-500" />}
      </div>
      <FieldError id="phone-error" message={errors.phone} />
    </div>
  );
}

export function ContactFields({ ctl, requireMessage }: C & { requireMessage?: boolean }) {
  const { data, set, errors } = ctl;
  const max = 1000;
  const addSuggestion = (s: string) => {
    if (data.message.toLowerCase().includes(s.toLowerCase())) return;
    set("message", data.message.trim() ? `${data.message.trim()}${/[.!?]$/.test(data.message.trim()) ? "" : "."} ${s}.` : `${s}.`);
  };

  return (
    <div className="space-y-6">
      <TextField
        id="name"
        label="Full name"
        icon={User}
        autoComplete="name"
        placeholder="e.g. Rahim Uddin"
        value={data.name}
        onChange={(v) => set("name", v)}
        error={errors.name}
      />
      <div className="grid gap-6 sm:grid-cols-2">
        <PhoneField ctl={ctl} />
        <TextField
          id="email"
          type="email"
          label="Email address"
          icon={Mail}
          optional={data.contactPref !== "email"}
          autoComplete="email"
          inputMode="email"
          placeholder="you@example.com"
          value={data.email}
          onChange={(v) => set("email", v)}
          error={errors.email}
        />
      </div>

      <div>
        <Label>How should we contact you?</Label>
        <div role="radiogroup" aria-label="Preferred contact method" className="mt-3 grid grid-cols-3 gap-2 sm:gap-3">
          {PREFS.map(({ id, label, icon: Icon }) => {
            const active = data.contactPref === id;
            return (
              <button
                key={id}
                type="button"
                role="radio"
                aria-checked={active}
                onClick={() => set("contactPref", id)}
                className={cn(
                  "flex flex-col items-center gap-1.5 rounded-2xl border-2 px-2 py-3 text-xs font-semibold transition active:scale-95 sm:flex-row sm:justify-center sm:gap-2 sm:text-sm",
                  active ? "border-lagoon-500 bg-lagoon-50 text-navy-900" : "border-slate-100 bg-white text-slate-500 hover:border-slate-200",
                )}
              >
                <Icon className={cn("h-5 w-5", active && (id === "whatsapp" ? "text-[#25D366]" : "text-lagoon-600"))} />
                {label}
              </button>
            );
          })}
        </div>
      </div>

      <div>
        <div className="flex items-center justify-between">
          <Label htmlFor="message" optional={!requireMessage}>
            {requireMessage ? "Your message" : "Anything else we should know?"}
          </Label>
          <span className={cn("text-xs tabular-nums", data.message.length > max * 0.9 ? "text-rose-500" : "text-slate-400")}>
            {data.message.length}/{max}
          </span>
        </div>
        <textarea
          id="message"
          name="message"
          rows={4}
          maxLength={max}
          value={data.message}
          onChange={(e) => set("message", e.target.value)}
          aria-invalid={!!errors.message}
          aria-describedby={errors.message ? "message-error" : undefined}
          placeholder={requireMessage ? "How can we help you?" : "Special requests, occasions, dietary needs, places you'd love to see…"}
          className={cn(
            "mt-2 block w-full resize-y rounded-xl border bg-white px-4 py-3 text-sm text-slate-800 shadow-sm transition placeholder:text-slate-400 focus:outline-none focus:ring-4",
            errors.message
              ? "border-rose-300 bg-rose-50/40 focus:border-rose-400 focus:ring-rose-100"
              : "border-slate-200 hover:border-slate-300 focus:border-lagoon-400 focus:ring-lagoon-100",
          )}
        />
        <FieldError id="message-error" message={errors.message} />
        <div className="mt-3 flex flex-wrap gap-1.5">
          {SUGGESTIONS.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => addSuggestion(s)}
              className="rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-600 transition hover:bg-sunset-100 hover:text-sunset-700 active:scale-95"
            >
              + {s}
            </button>
          ))}
        </div>
      </div>

      <label className="flex cursor-pointer items-start gap-3 text-sm text-slate-600">
        <input
          type="checkbox"
          checked={data.newsletter}
          onChange={(e) => set("newsletter", e.target.checked)}
          className="mt-0.5 h-4 w-4 cursor-pointer rounded border-slate-300 accent-lagoon-500"
        />
        Send me exclusive offers and travel deals (no spam, unsubscribe anytime).
      </label>
    </div>
  );
}

export function StepContact({ ctl }: C) {
  return (
    <div className="space-y-6">
      <StepTitle title="How can we reach you?" subtitle="We'll use these details only to send your personalised quote." />
      <ContactFields ctl={ctl} />
    </div>
  );
}

/* ------------------------------ Step 4 ------------------------------ */

function ReviewCard({ title, icon: Icon, rows, onEdit }: { title: string; icon: ComponentType<{ className?: string }>; rows: Row[]; onEdit: () => void }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5">
      <div className="flex items-center justify-between">
        <p className="flex items-center gap-2 text-sm font-bold text-navy-900">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-navy-50 text-navy-800">
            <Icon className="h-4 w-4" />
          </span>
          {title}
        </p>
        <button
          type="button"
          onClick={onEdit}
          className="inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-semibold text-lagoon-700 transition hover:bg-lagoon-50"
        >
          <Pencil className="h-3.5 w-3.5" /> Edit
        </button>
      </div>
      <dl className="mt-4 space-y-2.5">
        {rows.map((r) => (
          <div key={r.label} className="flex justify-between gap-4 text-sm">
            <dt className="shrink-0 text-slate-500">{r.label}</dt>
            <dd className="text-right font-semibold text-navy-900">{r.value}</dd>
          </div>
        ))}
      </dl>
    </div>
  );
}

export function StepReview({ ctl }: C) {
  const { data, goTo } = ctl;
  return (
    <div>
      <StepTitle title="Review your enquiry" subtitle="Check everything looks right, then send it to our travel team." />
      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <ReviewCard title="Trip details" icon={Luggage} rows={tripRows(data)} onEdit={() => goTo(1)} />
        <ReviewCard title="Your details" icon={User} rows={contactRows(data)} onEdit={() => goTo(2)} />
      </div>
      {data.message.trim() && (
        <div className="mt-4 rounded-2xl bg-slate-50 p-5">
          <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Message</p>
          <p className="mt-1.5 whitespace-pre-line text-sm text-slate-700">{data.message.trim()}</p>
        </div>
      )}
      <p className="mt-5 flex items-start gap-2 text-xs leading-relaxed text-slate-500">
        <Lock className="mt-0.5 h-3.5 w-3.5 shrink-0" />
        Your details are only used to respond to this enquiry. We never share your information with third parties.
      </p>
    </div>
  );
}

/* --------------------------- Quick message --------------------------- */

export function QuickForm({ ctl }: C) {
  const { data, set } = ctl;
  return (
    <div className="space-y-6">
      <StepTitle title="Send us a quick message" subtitle="Have a question? Drop us a line and we'll get right back to you." />
      <div>
        <Label>What's it about?</Label>
        <Chips className="mt-3" size="sm" ariaLabel="Topic" options={TOPICS} value={data.topic} onChange={(v) => set("topic", v)} allowDeselect={false} />
      </div>
      <ContactFields ctl={ctl} requireMessage />
    </div>
  );
}
