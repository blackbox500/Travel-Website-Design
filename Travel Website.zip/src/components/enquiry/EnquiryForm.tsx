import type { FormEvent } from "react";
import { ArrowLeft, ArrowRight, Check, CircleAlert, Clock, LoaderCircle, Mail, MessageSquareText, RotateCcw, Save, Send, Sparkles } from "lucide-react";
import { FORM } from "@/config";
import { cn } from "@/utils/cn";
import { WhatsAppIcon } from "../ui/BrandIcons";
import { QuickForm, StepContact, StepReview, StepService, StepTrip } from "./steps";
import { SuccessPanel } from "./SuccessPanel";
import { LAST_STEP, PLAN_STEPS, type EnquiryController, type Mode } from "./useEnquiry";

function ModeSwitch({ mode, onChange }: { mode: Mode; onChange: (m: Mode) => void }) {
  const items: { id: Mode; label: string; hint: string; icon: typeof Sparkles }[] = [
    { id: "plan", label: "Plan a trip", hint: "Get a custom quote", icon: Sparkles },
    { id: "quick", label: "Quick message", hint: "Ask a question", icon: MessageSquareText },
  ];
  return (
    <div role="tablist" aria-label="Enquiry type" className="relative grid grid-cols-2 rounded-2xl bg-slate-100 p-1.5">
      <span
        aria-hidden
        className={cn(
          "absolute bottom-1.5 top-1.5 w-[calc(50%-6px)] rounded-xl bg-white shadow-md shadow-navy-900/10 transition-transform duration-300 ease-out",
          mode === "plan" ? "translate-x-0" : "translate-x-[calc(100%+0px)]",
        )}
        style={{ left: 6 }}
      />
      {items.map(({ id, label, hint, icon: Icon }) => (
        <button
          key={id}
          type="button"
          role="tab"
          aria-selected={mode === id}
          onClick={() => onChange(id)}
          className={cn(
            "relative z-10 flex items-center justify-center gap-2.5 rounded-xl px-3 py-2.5 text-left transition-colors",
            mode === id ? "text-navy-900" : "text-slate-500 hover:text-navy-900",
          )}
        >
          <Icon className={cn("h-5 w-5 shrink-0", mode === id ? "text-sunset-500" : "")} />
          <span className="leading-tight">
            <span className="block text-sm font-bold">{label}</span>
            <span className="hidden text-[11px] font-medium text-slate-400 sm:block">{hint}</span>
          </span>
        </button>
      ))}
    </div>
  );
}

function Progress({ ctl }: { ctl: EnquiryController }) {
  const { step, goTo } = ctl;
  return (
    <div className="mt-8">
      <p className="mb-3 text-xs font-semibold text-slate-500 sm:hidden">
        Step {step + 1} of {PLAN_STEPS.length} · <span className="text-navy-900">{PLAN_STEPS[step].label}</span>
      </p>
      <ol className="grid grid-cols-4 gap-2">
        {PLAN_STEPS.map((s, i) => {
          const done = i < step;
          const active = i === step;
          return (
            <li key={s.id}>
              <button
                type="button"
                disabled={i > step}
                onClick={() => goTo(i)}
                aria-current={active ? "step" : undefined}
                className="group w-full text-left disabled:cursor-default"
              >
                <div className="h-1.5 overflow-hidden rounded-full bg-slate-100">
                  <div
                    className={cn(
                      "h-full rounded-full transition-all duration-500 ease-out",
                      done ? "w-full bg-lagoon-500" : active ? "w-1/2 bg-linear-to-r from-lagoon-500 to-sunset-400" : "w-0",
                    )}
                  />
                </div>
                <div className="mt-2.5 hidden items-center gap-2 sm:flex">
                  <span
                    className={cn(
                      "grid h-6 w-6 shrink-0 place-items-center rounded-full text-[11px] font-bold transition",
                      done ? "bg-lagoon-500 text-white" : active ? "bg-navy-900 text-white" : "bg-slate-100 text-slate-400",
                    )}
                  >
                    {done ? <Check className="h-3.5 w-3.5" strokeWidth={3} /> : i + 1}
                  </span>
                  <span
                    className={cn(
                      "truncate text-xs font-semibold",
                      active ? "text-navy-900" : done ? "text-slate-600 group-hover:text-lagoon-600" : "text-slate-400",
                    )}
                  >
                    {s.label}
                  </span>
                </div>
              </button>
            </li>
          );
        })}
      </ol>
    </div>
  );
}

function DraftBar({ ctl }: { ctl: EnquiryController }) {
  const { savedAt, restored, dirty, reset } = ctl;
  if (!dirty) return null;
  return (
    <div className="mt-6 flex flex-wrap items-center justify-between gap-2 rounded-xl bg-slate-50 px-4 py-2.5 text-xs text-slate-500">
      <span className="inline-flex items-center gap-1.5">
        <Save className="h-3.5 w-3.5 text-lagoon-600" />
        {restored
          ? "Welcome back! We restored your unfinished enquiry."
          : savedAt
            ? `Draft saved automatically · ${savedAt.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}`
            : "Saving draft…"}
      </span>
      <button type="button" onClick={reset} className="inline-flex items-center gap-1 font-semibold text-slate-600 transition hover:text-rose-600">
        <RotateCcw className="h-3.5 w-3.5" /> Start over
      </button>
    </div>
  );
}

export function EnquiryForm({ ctl }: { ctl: EnquiryController }) {
  const { mode, setMode, step, status, back, data, set } = ctl;
  const hasBackend = !!FORM.web3formsAccessKey;
  const sending = status === "sending";
  const isFinal = mode === "quick" || step === LAST_STEP;

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (sending) return;
    if (isFinal) ctl.submit("auto");
    else ctl.next();
  };

  const steps = [StepService, StepTrip, StepContact, StepReview];
  const StepView = steps[step];

  return (
    <div
      id="enquiry-form"
      ref={ctl.formRef}
      className={cn(
        "relative scroll-mt-24 overflow-hidden rounded-[2rem] border border-slate-200/80 bg-white shadow-2xl shadow-navy-900/[0.07] transition-[box-shadow] duration-500",
        ctl.flash && "shadow-sunset-500/30 ring-4 ring-sunset-300",
      )}
    >
      <div className="h-1.5 bg-linear-to-r from-navy-900 via-lagoon-500 to-sunset-500" />

      {status === "success" ? (
        <SuccessPanel ctl={ctl} />
      ) : (
        <form noValidate onSubmit={onSubmit} className="p-5 sm:p-8" aria-label="Enquiry form">
          <ModeSwitch mode={mode} onChange={setMode} />

          {mode === "plan" && <Progress ctl={ctl} />}

          <div key={`${mode}-${step}`} className="mt-8 animate-slide-in">
            {mode === "plan" ? <StepView ctl={ctl} /> : <QuickForm ctl={ctl} />}
          </div>

          {/* Honeypot – hidden from humans */}
          <input
            type="text"
            name="website"
            tabIndex={-1}
            autoComplete="off"
            aria-hidden="true"
            value={data.website}
            onChange={(e) => set("website", e.target.value)}
            className="absolute -left-[9999px] h-0 w-0 opacity-0"
          />

          {status === "error" && (
            <div role="alert" className="mt-6 flex animate-fade-up flex-col gap-3 rounded-2xl border border-rose-200 bg-rose-50 p-4 sm:flex-row sm:items-center sm:justify-between">
              <p className="flex items-start gap-2 text-sm text-rose-700">
                <CircleAlert className="mt-0.5 h-4 w-4 shrink-0" />
                {ctl.errorMsg} You can also send it instantly on WhatsApp.
              </p>
              <button
                type="button"
                onClick={() => ctl.submit("whatsapp")}
                className="inline-flex shrink-0 items-center justify-center gap-2 rounded-full bg-[#25D366] px-4 py-2 text-sm font-bold text-white"
              >
                <WhatsAppIcon className="h-4 w-4" /> Send via WhatsApp
              </button>
            </div>
          )}

          {/* Navigation */}
          <div className="mt-8 flex flex-col-reverse gap-3 border-t border-slate-100 pt-6 sm:flex-row sm:items-center sm:justify-between">
            {mode === "plan" && step > 0 ? (
              <button
                type="button"
                onClick={back}
                className="inline-flex items-center justify-center gap-2 rounded-full px-5 py-3 text-sm font-bold text-slate-600 transition hover:bg-slate-100 hover:text-navy-900"
              >
                <ArrowLeft className="h-4 w-4" /> Back
              </button>
            ) : (
              <span className="inline-flex items-center justify-center gap-1.5 text-xs font-medium text-slate-400 sm:justify-start">
                <Clock className="h-3.5 w-3.5" /> Takes less than 2 minutes
              </span>
            )}

            {!isFinal ? (
              <button
                type="submit"
                className="group inline-flex items-center justify-center gap-2 rounded-full bg-navy-900 px-7 py-3.5 text-sm font-bold text-white shadow-lg shadow-navy-900/20 transition hover:-translate-y-0.5 hover:bg-navy-800"
              >
                Continue
                <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
              </button>
            ) : hasBackend ? (
              <div className="flex flex-col-reverse gap-2 sm:flex-row">
                <button
                  type="button"
                  onClick={() => ctl.submit("whatsapp")}
                  className="inline-flex items-center justify-center gap-2 rounded-full border border-slate-200 px-5 py-3.5 text-sm font-bold text-navy-900 transition hover:border-[#25D366] hover:text-[#128C7E]"
                >
                  <WhatsAppIcon className="h-4 w-4 text-[#25D366]" /> Use WhatsApp
                </button>
                <button
                  type="submit"
                  disabled={sending}
                  className="inline-flex items-center justify-center gap-2 rounded-full bg-sunset-500 px-7 py-3.5 text-sm font-bold text-white shadow-lg shadow-sunset-500/30 transition hover:-translate-y-0.5 hover:bg-sunset-600 disabled:translate-y-0 disabled:opacity-70"
                >
                  {sending ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                  {sending ? "Sending…" : "Send enquiry"}
                </button>
              </div>
            ) : (
              <div className="flex flex-col-reverse gap-2 sm:flex-row">
                <button
                  type="button"
                  onClick={() => ctl.submit("email-client")}
                  className="inline-flex items-center justify-center gap-2 rounded-full border border-slate-200 px-5 py-3.5 text-sm font-bold text-navy-900 transition hover:border-lagoon-400 hover:text-lagoon-700"
                >
                  <Mail className="h-4 w-4" /> Send by email
                </button>
                <button
                  type="submit"
                  className="inline-flex items-center justify-center gap-2 rounded-full bg-[#25D366] px-7 py-3.5 text-sm font-bold text-white shadow-lg shadow-emerald-500/30 transition hover:-translate-y-0.5 hover:bg-[#1ebe5a]"
                >
                  <WhatsAppIcon className="h-4 w-4" /> Send on WhatsApp
                </button>
              </div>
            )}
          </div>

          <DraftBar ctl={ctl} />
        </form>
      )}
    </div>
  );
}
