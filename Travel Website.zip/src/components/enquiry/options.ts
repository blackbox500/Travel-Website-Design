export const COUNTRY_CODES = [
  { iso: "BD", code: "+880" },
  { iso: "IN", code: "+91" },
  { iso: "NP", code: "+977" },
  { iso: "BT", code: "+975" },
  { iso: "AE", code: "+971" },
  { iso: "SA", code: "+966" },
  { iso: "QA", code: "+974" },
  { iso: "KW", code: "+965" },
  { iso: "OM", code: "+968" },
  { iso: "MY", code: "+60" },
  { iso: "SG", code: "+65" },
  { iso: "GB", code: "+44" },
  { iso: "US", code: "+1" },
  { iso: "AU", code: "+61" },
];

export const DURATIONS = ["2–3 days", "4–5 days", "6–8 days", "9–12 days", "2 weeks+"] as const;
export const BUDGETS = ["Under Tk 30k", "Tk 30k – 60k", "Tk 60k – 1 lakh", "Tk 1 lakh +", "Not sure yet"] as const;
export const HOTEL_CLASSES = ["Budget", "3 Star", "4 Star", "5 Star / Luxury"] as const;
export const CABINS = ["Economy", "Premium Economy", "Business"] as const;
export const PASSPORT = ["Yes", "No", "Not sure"] as const;
export const TOPICS = ["General question", "Tour package", "Visa processing", "Hotel booking", "Air ticket", "Payment"] as const;
export const SUGGESTIONS = [
  "Honeymoon trip",
  "Travelling with kids",
  "Senior travellers",
  "Halal food preferred",
  "Need visa help too",
  "Budget-friendly options",
] as const;
