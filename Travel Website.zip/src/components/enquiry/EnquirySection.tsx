import { ArrowUpRight, Gift, Phone } from "lucide-react";
import { CONTACT, OFFERS } from "@/config";
import { cn } from "@/utils/cn";
import { useOfficeStatus } from "@/lib/hooks";
import { openEnquiry } from "@/lib/enquiryBus";
import { Link } from "@/lib/router";
import { pexels, telLink, waLink } from "@/lib/utils";
import { Reveal } from "../ui/Reveal";
import { SectionHeading, StatusDot } from "../ui/primitives";
import { WhatsAppIcon } from "../ui/BrandIcons";
import { EnquiryForm } from "./EnquiryForm";
import { TripSummary } from "./TripSummary";
import { useEnquiry } from "./useEnquiry";

function Offers() {
  return (
    <div className="rounded-[1.75rem] bg-white p-5 shadow-xl shadow-navy-900/[0.06] ring-1 ring-slate-200/70">
      <div className="flex items-center justify-between">
        <h3 className="flex items-center gap-2 text-sm font-bold text-navy-900">
          <Gift className="h-4 w-4 text-sunset-500" />
          Current offers
        </h3>
        <span className="rounded-full bg-sunset-50 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-sunset-600">Hot deals</span>
      </div>
      <ul className="mt-4 space-y-3">
        {OFFERS.map((o) => (
          <li key={o.id} className="group relative overflow-hidden rounded-2xl">
            <img
              src={pexels(o.image, 640, 320)}
              alt=""
              loading="lazy"
              className="absolute inset-0 h-full w-full object-cover transition duration-700 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-linear-to-r from-navy-950/95 via-navy-900/80 to-navy-900/30" />
            <div className="relative p-4 text-white">
              <span className="inline-flex rounded-full bg-sunset-500 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider">{o.badge}</span>
              <p className="mt-2 font-bold leading-snug">{o.title}</p>
              <p className="text-xs text-navy-100">{o.subtitle}</p>
              <p className="mt-1.5 text-lg font-extrabold text-sunset-300">{o.price}</p>
              <div className="mt-3 flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => openEnquiry(o.preset)}
                  className="rounded-full bg-white px-3.5 py-1.5 text-xs font-bold text-navy-900 transition hover:bg-sunset-100"
                >
                  Ask about this
                </button>
                <Link
                  to={o.link}
                  className="inline-flex items-center gap-0.5 text-xs font-semibold text-white/80 underline-offset-4 hover:text-white hover:underline"
                >
                  Details <ArrowUpRight className="h-3 w-3" />
                </Link>
              </div>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function TalkCard() {
  const { status, time } = useOfficeStatus();
  return (
    <div className="overflow-hidden rounded-[1.75rem] bg-navy-900 p-6 text-white shadow-xl shadow-navy-900/20">
      <p className="text-[11px] font-bold uppercase tracking-[0.22em] text-navy-200">Prefer to talk?</p>
      <p className="mt-2 text-xl font-bold">Our travel experts are a call away</p>
      <p className="mt-3 inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1.5 text-xs font-semibold">
        <StatusDot open={status.open} soon={status.closingSoon} />
        {status.title} · Dhaka {time}
      </p>
      <div className="mt-5 space-y-2">
        {CONTACT.phones.map((p) => (
          <a
            key={p.value}
            href={telLink(p.value)}
            className="flex items-center gap-3 rounded-2xl bg-white/10 px-4 py-3 text-sm font-bold transition hover:bg-white/20"
          >
            <Phone className="h-4 w-4 text-sunset-400" />
            {p.display}
          </a>
        ))}
        <a
          href={waLink("Hello SAARC Holiday! I have a question.")}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-3 rounded-2xl bg-[#25D366] px-4 py-3 text-sm font-bold transition hover:bg-[#1ebe5a]"
        >
          <WhatsAppIcon className="h-4 w-4" />
          Chat on WhatsApp
        </a>
      </div>
    </div>
  );
}

export function EnquirySection() {
  const ctl = useEnquiry();
  const showPass = ctl.mode === "plan" && ctl.status !== "success";

  return (
    <section id="enquiry" className="relative scroll-mt-20 pb-20 pt-20 sm:pb-24 sm:pt-24">
      <div className="bg-grid absolute inset-x-0 top-0 -z-10 h-[560px] [mask-image:linear-gradient(to_bottom,black,transparent)]" />
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal>
          <SectionHeading
            eyebrow="Leave us a message"
            title="Tell us about your dream trip"
            subtitle="Answer a few quick questions to get a personalised quote — or simply send us a quick message. It takes less than 2 minutes."
          />
        </Reveal>

        <div className="mt-12 grid items-start gap-8 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <EnquiryForm ctl={ctl} />
          </div>
          <aside className="flex flex-col gap-6 lg:col-span-4 lg:self-stretch" aria-label="Trip summary and offers">
            <Offers />
            <div className={cn("lg:sticky lg:top-24", showPass && "hidden lg:block")}>
              {showPass ? <TripSummary ctl={ctl} /> : <TalkCard />}
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
}
