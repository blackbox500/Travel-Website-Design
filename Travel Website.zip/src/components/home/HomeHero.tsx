import { useEffect, useState, type ComponentType, type FormEvent, type ReactNode } from "react";
import {
  ArrowRight,
  BedDouble,
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  MapPin,
  Palmtree,
  PlaneLanding,
  PlaneTakeoff,
  Search,
  Sparkles,
  Stamp,
  Users,
  Wallet,
} from "lucide-react";
import { DESTINATIONS, SETTINGS, SITE } from "@/config";
import { TOUR_STYLES } from "@/data/tours";
import { VISA_COUNTRIES } from "@/data/visa";
import { openEnquiry } from "@/lib/enquiryBus";
import { useReducedMotion } from "@/lib/hooks";
import { Link, navigate } from "@/lib/router";
import { pexels, todayISO } from "@/lib/utils";
import { cn } from "@/utils/cn";

type Icon = ComponentType<{ className?: string }>;

const SLIDES = [
  { image: 39128859, place: "Tiger's Nest, Bhutan" },
  { image: 15846574, place: "Phewa Lake, Pokhara" },
  { image: 33053824, place: "Phi Phi Islands, Thailand" },
  { image: 15480459, place: "Marina Bay, Singapore" },
  { image: 19031655, place: "Great Wall of China" },
];

export function HomeHero() {
  const [i, setI] = useState(0);
  const [paused, setPaused] = useState(false);
  const [ready, setReady] = useState(false);
  const [loaded, setLoaded] = useState<Set<number>>(() => new Set([0, 1]));
  const reduced = useReducedMotion();
  const go = (n: number) => setI((n + SLIDES.length) % SLIDES.length);

  useEffect(() => {
    const raf = requestAnimationFrame(() => setReady(true));
    return () => cancelAnimationFrame(raf);
  }, []);

  // Preload the next slide only when needed
  useEffect(() => {
    const next = (i + 1) % SLIDES.length;
    setLoaded((s) => (s.has(next) ? s : new Set(s).add(next)));
  }, [i]);

  return (
    <section
      className="relative isolate overflow-hidden bg-navy-950"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      aria-roledescription="carousel"
      aria-label="Featured destinations"
    >
      {SLIDES.map((s, idx) =>
        loaded.has(idx) ? (
          <img
            key={s.image}
            src={pexels(s.image, 1920, 1200)}
            alt=""
            aria-hidden
            fetchPriority={idx === 0 ? "high" : "low"}
            className={cn(
              "absolute inset-0 -z-20 h-full w-full object-cover",
              idx === i ? (ready ? "scale-100 opacity-100" : "scale-110 opacity-100") : "scale-110 opacity-0",
            )}
            style={{ transition: "opacity 1.4s ease, transform 9s ease-out" }}
          />
        ) : null,
      )}
      <div className="absolute inset-0 -z-10 bg-linear-to-r from-navy-950/90 via-navy-900/60 to-navy-900/10" />
      <div className="absolute inset-0 -z-10 bg-linear-to-t from-navy-950/85 via-transparent to-navy-950/30" />

      <div className="mx-auto flex min-h-[620px] max-w-7xl flex-col justify-center px-4 pb-56 pt-14 sm:min-h-[700px] sm:px-6 lg:px-8">
        <p className="animate-fade-up font-script text-3xl text-sunset-300 sm:text-4xl">{SITE.tagline}</p>
        <h1 className="mt-2 max-w-4xl animate-fade-up text-4xl font-extrabold leading-[1.05] tracking-tight text-white [animation-delay:100ms] sm:text-6xl lg:text-7xl">
          Discover the Himalayas <span className="text-sunset-400">&amp;</span> beyond
        </h1>
        <p className="mt-5 max-w-xl animate-fade-up text-base leading-relaxed text-navy-100 [animation-delay:200ms] sm:text-lg">
          Tour packages, visa processing, hotels and air tickets — thoughtfully planned by a trusted Dhaka-based travel agency.
        </p>
        <div className="mt-8 flex animate-fade-up flex-wrap gap-3 [animation-delay:300ms]">
          <Link
            to="/tours"
            className="group inline-flex items-center gap-2 rounded-full bg-sunset-500 px-6 py-3.5 text-sm font-bold text-white shadow-xl shadow-sunset-500/30 transition hover:-translate-y-0.5 hover:bg-sunset-600"
          >
            Explore tours <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
          </Link>
          <button
            type="button"
            onClick={() => openEnquiry({ mode: "plan" })}
            className="inline-flex items-center gap-2 rounded-full border border-white/25 bg-white/10 px-6 py-3.5 text-sm font-bold text-white backdrop-blur transition hover:bg-white/20"
          >
            <Sparkles className="h-4 w-4" /> Plan a custom trip
          </button>
        </div>
      </div>

      {/* Slide controls */}
      <div className="absolute inset-x-0 bottom-44 z-10">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2">
            {SLIDES.map((s, idx) => (
              <button
                key={s.image}
                type="button"
                onClick={() => go(idx)}
                aria-label={`Show slide ${idx + 1}: ${s.place}`}
                aria-current={idx === i}
                className="relative h-1.5 w-9 overflow-hidden rounded-full bg-white/25 transition hover:bg-white/40 sm:w-14"
              >
                {idx === i &&
                  (reduced ? (
                    <span className="absolute inset-0 rounded-full bg-sunset-400" />
                  ) : (
                    <span
                      key={i}
                      onAnimationEnd={() => go(i + 1)}
                      className="absolute inset-0 origin-left animate-progress rounded-full bg-sunset-400"
                      style={{ animationPlayState: paused ? "paused" : "running" }}
                    />
                  ))}
              </button>
            ))}
          </div>
          <div className="hidden items-center gap-2 sm:flex">
            <p key={i} className="flex animate-fade-up items-center gap-1.5 rounded-full bg-white/10 px-3 py-1.5 text-sm font-medium text-white backdrop-blur">
              <MapPin className="h-4 w-4 text-sunset-400" />
              {SLIDES[i].place}
            </p>
            <button
              type="button"
              onClick={() => go(i - 1)}
              aria-label="Previous slide"
              className="grid h-9 w-9 place-items-center rounded-full bg-white/10 text-white backdrop-blur transition hover:bg-white/25"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => go(i + 1)}
              aria-label="Next slide"
              className="grid h-9 w-9 place-items-center rounded-full bg-white/10 text-white backdrop-blur transition hover:bg-white/25"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ----------------------------- Search widget ----------------------------- */

type Tab = "tours" | "visa" | "hotels" | "flights";
const TABS: { id: Tab; label: string; icon: Icon }[] = [
  { id: "tours", label: "Tours", icon: Palmtree },
  { id: "visa", label: "Visa", icon: Stamp },
  { id: "hotels", label: "Hotels", icon: BedDouble },
  { id: "flights", label: "Flights", icon: PlaneTakeoff },
];

const CITIES = [
  "Bangkok (BKK)",
  "Kathmandu (KTM)",
  "Paro (PBH)",
  "Delhi (DEL)",
  "Kuala Lumpur (KUL)",
  "Singapore (SIN)",
  "Kunming (KMG)",
  "Beijing (PEK)",
  "Dubai (DXB)",
  "Jeddah (JED)",
];

function Field({ label, icon: I, children }: { label: string; icon: Icon; children: ReactNode }) {
  return (
    <label className="flex min-w-0 flex-1 cursor-pointer flex-col gap-1 rounded-2xl px-4 py-3 transition focus-within:bg-slate-50 hover:bg-slate-50">
      <span className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-[0.15em] text-slate-400">
        <I className="h-3.5 w-3.5 text-sunset-500" />
        {label}
      </span>
      {children}
    </label>
  );
}

const Divider = () => <span aria-hidden className="hidden w-px self-stretch bg-slate-100 lg:block" />;
const control = "w-full min-w-0 cursor-pointer bg-transparent py-0.5 text-[15px] font-semibold text-navy-900 focus:outline-none";

export function SearchWidget() {
  const [tab, setTab] = useState<Tab>("tours");
  const [dest, setDest] = useState("");
  const [style, setStyle] = useState("");
  const [budget, setBudget] = useState("");
  const [visaCountry, setVisaCountry] = useState("thailand");
  const [hotelDest, setHotelDest] = useState("bhutan");
  const [checkIn, setCheckIn] = useState("");
  const [guests, setGuests] = useState(2);
  const [to, setTo] = useState("");
  const [flightDate, setFlightDate] = useState("");
  const [pax, setPax] = useState(1);
  const visaInfo = VISA_COUNTRIES.find((v) => v.id === visaCountry);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (tab === "tours") {
      const q = new URLSearchParams();
      if (dest) q.set("destination", dest);
      if (style) q.set("style", style);
      if (budget) q.set("budget", budget);
      const qs = q.toString();
      navigate(`/tours${qs ? `?${qs}` : ""}`);
    } else if (tab === "visa") {
      navigate(`/visa?country=${visaCountry}`);
    } else if (tab === "hotels") {
      openEnquiry({ mode: "plan", service: "hotel", destinations: [hotelDest], departDate: checkIn || undefined, adults: guests });
    } else {
      openEnquiry({ mode: "plan", service: "air", fromCity: "Dhaka (DAC)", toCity: to, departDate: flightDate || undefined, adults: pax });
    }
  };

  return (
    <div className="relative z-20 mx-auto -mt-36 max-w-6xl px-4 sm:px-6 lg:px-8">
      <div className="rounded-[2rem] bg-navy-950/40 p-2 shadow-2xl shadow-navy-950/30 ring-1 ring-white/15 backdrop-blur-xl">
        <div role="tablist" aria-label="What are you looking for?" className="flex gap-1 overflow-x-auto p-1">
          {TABS.map(({ id, label, icon: I }) => (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={tab === id}
              onClick={() => setTab(id)}
              className={cn(
                "flex shrink-0 items-center gap-2 rounded-full px-4 py-2 text-sm font-bold transition",
                tab === id ? "bg-white text-navy-900 shadow" : "text-white/85 hover:bg-white/10",
              )}
            >
              <I className="h-4 w-4" />
              {label}
            </button>
          ))}
        </div>

        <form onSubmit={submit} className="mt-1 flex flex-col gap-1 rounded-[1.6rem] bg-white p-2 lg:flex-row lg:items-stretch">
          {tab === "tours" && (
            <>
              <Field label="Destination" icon={MapPin}>
                <select value={dest} onChange={(e) => setDest(e.target.value)} className={control}>
                  <option value="">All destinations</option>
                  {DESTINATIONS.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name}
                    </option>
                  ))}
                </select>
              </Field>
              <Divider />
              <Field label="Trip style" icon={Sparkles}>
                <select value={style} onChange={(e) => setStyle(e.target.value)} className={control}>
                  <option value="">Any style</option>
                  {TOUR_STYLES.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </Field>
              {SETTINGS.showPrices && (
                <>
                  <Divider />
                  <Field label="Budget / person" icon={Wallet}>
                    <select value={budget} onChange={(e) => setBudget(e.target.value)} className={control}>
                      <option value="">Any budget</option>
                      <option value="30000">Under BDT 30,000</option>
                      <option value="60000">Under BDT 60,000</option>
                      <option value="100000">Under BDT 1,00,000</option>
                    </select>
                  </Field>
                </>
              )}
            </>
          )}

          {tab === "visa" && (
            <>
              <Field label="Country" icon={MapPin}>
                <select value={visaCountry} onChange={(e) => setVisaCountry(e.target.value)} className={control}>
                  {VISA_COUNTRIES.map((v) => (
                    <option key={v.id} value={v.id}>
                      {v.name}
                    </option>
                  ))}
                </select>
              </Field>
              <Divider />
              <div className="flex min-w-0 flex-[1.4] flex-col justify-center gap-1 rounded-2xl px-4 py-3">
                <span className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-[0.15em] text-slate-400">
                  <Stamp className="h-3.5 w-3.5 text-sunset-500" /> Visa type
                </span>
                <span className="text-[15px] font-semibold text-navy-900">
                  {visaInfo?.type}
                  {visaInfo?.inOffer && <span className="ml-2 rounded-full bg-sunset-100 px-2 py-0.5 text-[11px] font-bold text-sunset-700">3-country offer</span>}
                </span>
              </div>
            </>
          )}

          {tab === "hotels" && (
            <>
              <Field label="Destination" icon={MapPin}>
                <select value={hotelDest} onChange={(e) => setHotelDest(e.target.value)} className={control}>
                  {DESTINATIONS.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name}
                    </option>
                  ))}
                </select>
              </Field>
              <Divider />
              <Field label="Check-in" icon={CalendarDays}>
                <input type="date" min={todayISO()} value={checkIn} onChange={(e) => setCheckIn(e.target.value)} className={control} />
              </Field>
              <Divider />
              <Field label="Guests" icon={Users}>
                <select value={guests} onChange={(e) => setGuests(Number(e.target.value))} className={control}>
                  {Array.from({ length: 10 }, (_, n) => n + 1).map((n) => (
                    <option key={n} value={n}>
                      {n} adult{n > 1 ? "s" : ""}
                    </option>
                  ))}
                </select>
              </Field>
            </>
          )}

          {tab === "flights" && (
            <>
              <Field label="Flying to" icon={PlaneLanding}>
                <input
                  list="flight-cities"
                  value={to}
                  onChange={(e) => setTo(e.target.value)}
                  placeholder="City or airport"
                  className={cn(control, "cursor-text placeholder:font-medium placeholder:text-slate-400")}
                />
                <datalist id="flight-cities">
                  {CITIES.map((c) => (
                    <option key={c} value={c} />
                  ))}
                </datalist>
              </Field>
              <Divider />
              <Field label="Departure" icon={CalendarDays}>
                <input type="date" min={todayISO()} value={flightDate} onChange={(e) => setFlightDate(e.target.value)} className={control} />
              </Field>
              <Divider />
              <Field label="Passengers" icon={Users}>
                <select value={pax} onChange={(e) => setPax(Number(e.target.value))} className={control}>
                  {Array.from({ length: 9 }, (_, n) => n + 1).map((n) => (
                    <option key={n} value={n}>
                      {n} passenger{n > 1 ? "s" : ""}
                    </option>
                  ))}
                </select>
              </Field>
            </>
          )}

          <button
            type="submit"
            className="flex items-center justify-center gap-2 rounded-[1.2rem] bg-sunset-500 px-8 py-4 text-sm font-bold text-white shadow-lg shadow-sunset-500/30 transition hover:bg-sunset-600 lg:ml-1"
          >
            <Search className="h-4 w-4" />
            {tab === "tours" ? "Search tours" : tab === "visa" ? "Check documents" : "Get a quote"}
          </button>
        </form>
      </div>
    </div>
  );
}
