import { useState } from "react";
import { SITE } from "@/config";
import { cn } from "@/utils/cn";

export function StatusDot({ open, soon }: { open: boolean; soon?: boolean }) {
  const color = open ? (soon ? "bg-amber-400" : "bg-emerald-400") : "bg-rose-400";
  return (
    <span className="relative flex h-2.5 w-2.5 shrink-0">
      {open && <span className={cn("absolute inline-flex h-full w-full animate-ping rounded-full opacity-75", color)} />}
      <span className={cn("relative inline-flex h-2.5 w-2.5 rounded-full", color)} />
    </span>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  subtitle,
  align = "center",
  light,
}: {
  eyebrow: string;
  title: string;
  subtitle?: string;
  align?: "center" | "left";
  light?: boolean;
}) {
  return (
    <div className={cn("max-w-2xl", align === "center" && "mx-auto text-center")}>
      <span
        className={cn(
          "inline-flex items-center gap-2 rounded-full px-3 py-1 text-[11px] font-bold uppercase tracking-[0.2em]",
          light ? "bg-white/10 text-sunset-300" : "bg-sunset-100/70 text-sunset-700",
        )}
      >
        <span className="h-1.5 w-1.5 rounded-full bg-current" />
        {eyebrow}
      </span>
      <h2
        className={cn(
          "mt-4 text-3xl font-extrabold tracking-tight text-balance sm:text-4xl",
          light ? "text-white" : "text-navy-900",
        )}
      >
        {title}
      </h2>
      {subtitle && (
        <p className={cn("mt-4 text-base leading-relaxed text-pretty sm:text-lg", light ? "text-navy-100" : "text-slate-500")}>
          {subtitle}
        </p>
      )}
    </div>
  );
}

/** Curved divider at the bottom of dark hero sections */
export function Wave({ className }: { className?: string }) {
  return (
    <svg
      className={cn("absolute -bottom-px left-0 h-14 w-full text-slate-50 sm:h-20", className)}
      viewBox="0 0 1440 80"
      preserveAspectRatio="none"
      aria-hidden
    >
      <path fill="currentColor" d="M0 80V44c120 22 240 33 360 33S600 62 720 46s240-40 360-40 240 18 360 34v40z" />
    </svg>
  );
}

/** Site logo with a text fallback if the image can't load */
export function Logo({ className }: { className?: string }) {
  const [failed, setFailed] = useState(false);
  if (failed) {
    return (
      <span className={cn("inline-flex flex-col justify-center leading-none", className)}>
        <span className="text-xl font-extrabold tracking-tight text-navy-900">
          SAARC <span className="text-lagoon-600">Holiday</span>
        </span>
        <span className="mt-0.5 text-[9px] font-bold tracking-[0.3em] text-sunset-600">TOUR AND TRAVEL</span>
      </span>
    );
  }
  return (
    <img
      src={SITE.logo}
      alt="SAARC Holiday – Tour and Travel"
      width={171}
      height={46}
      className={className}
      onError={() => setFailed(true)}
    />
  );
}
