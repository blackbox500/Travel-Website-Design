import type { ReactNode } from "react";
import { ChevronRight } from "lucide-react";
import { Link } from "@/lib/router";
import { pexels } from "@/lib/utils";
import { cn } from "@/utils/cn";
import { Wave } from "./primitives";

export interface Crumb {
  label: string;
  to?: string;
}

export function Breadcrumbs({ items, light = true }: { items: Crumb[]; light?: boolean }) {
  return (
    <nav aria-label="Breadcrumb">
      <ol className={cn("flex flex-wrap items-center gap-1.5 text-sm", light ? "text-navy-200" : "text-slate-500")}>
        {items.map((c, i) => (
          <li key={c.label} className="flex items-center gap-1.5">
            {i > 0 && <ChevronRight className="h-3.5 w-3.5 shrink-0" aria-hidden />}
            {c.to ? (
              <Link to={c.to} className={cn("transition", light ? "hover:text-white" : "hover:text-navy-900")}>
                {c.label}
              </Link>
            ) : (
              <span aria-current="page" className={cn("line-clamp-1 font-semibold", light ? "text-white" : "text-navy-900")}>
                {c.label}
              </span>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
}

export function PageHero({
  title,
  subtitle,
  eyebrow,
  image,
  crumbs,
  children,
}: {
  title: ReactNode;
  subtitle?: ReactNode;
  eyebrow?: string;
  image: number;
  crumbs: Crumb[];
  children?: ReactNode;
}) {
  return (
    <section className="relative isolate overflow-hidden bg-navy-950 pb-28 pt-12 sm:pb-32 sm:pt-16">
      <img
        src={pexels(image, 1920, 900)}
        alt=""
        fetchPriority="high"
        className="absolute inset-0 -z-20 h-full w-full animate-kenburns object-cover"
      />
      <div className="absolute inset-0 -z-10 bg-linear-to-r from-navy-950/95 via-navy-900/75 to-navy-900/25" />
      <div className="absolute inset-0 -z-10 bg-linear-to-t from-navy-950/70 via-transparent to-transparent" />
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="animate-fade-up">
          <Breadcrumbs items={crumbs} />
        </div>
        {eyebrow && <p className="mt-6 animate-fade-up font-script text-3xl text-sunset-300 [animation-delay:80ms]">{eyebrow}</p>}
        <h1
          className={cn(
            "max-w-3xl animate-fade-up text-4xl font-extrabold leading-tight tracking-tight text-balance text-white [animation-delay:140ms] sm:text-5xl",
            eyebrow ? "mt-1" : "mt-6",
          )}
        >
          {title}
        </h1>
        {subtitle && (
          <p className="mt-4 max-w-2xl animate-fade-up text-base leading-relaxed text-navy-100 [animation-delay:220ms] sm:text-lg">
            {subtitle}
          </p>
        )}
        {children && <div className="mt-8 animate-fade-up [animation-delay:300ms]">{children}</div>}
      </div>
      <Wave />
    </section>
  );
}
