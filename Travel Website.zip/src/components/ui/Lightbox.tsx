import { useCallback, useEffect, useRef } from "react";
import { ChevronLeft, ChevronRight, X } from "lucide-react";
import { pexels, pexelsW } from "@/lib/utils";
import { cn } from "@/utils/cn";

export interface LightboxItem {
  image: number;
  caption?: string;
}

/** Full-screen photo viewer with keyboard, swipe and thumbnail navigation */
export function Lightbox({
  items,
  index,
  onClose,
  onChange,
}: {
  items: LightboxItem[];
  index: number | null;
  onClose: () => void;
  onChange: (i: number) => void;
}) {
  const touchX = useRef<number | null>(null);
  const open = index !== null;

  const prev = useCallback(() => {
    if (index !== null) onChange((index - 1 + items.length) % items.length);
  }, [index, items.length, onChange]);
  const next = useCallback(() => {
    if (index !== null) onChange((index + 1) % items.length);
  }, [index, items.length, onChange]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowLeft") prev();
      if (e.key === "ArrowRight") next();
    };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [open, onClose, prev, next]);

  if (index === null || !items[index]) return null;
  const item = items[index];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Photo viewer"
      className="fixed inset-0 z-[90] flex animate-page-in flex-col bg-navy-950/95 backdrop-blur-sm"
      onTouchStart={(e) => (touchX.current = e.touches[0].clientX)}
      onTouchEnd={(e) => {
        if (touchX.current === null) return;
        const dx = e.changedTouches[0].clientX - touchX.current;
        if (Math.abs(dx) > 50) {
          if (dx > 0) prev();
          else next();
        }
        touchX.current = null;
      }}
    >
      <div className="flex items-center justify-between px-4 py-3 text-white sm:px-6">
        <span className="text-sm font-semibold tabular-nums">
          {index + 1} / {items.length}
        </span>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close photo viewer"
          className="grid h-11 w-11 place-items-center rounded-full bg-white/10 transition hover:bg-white/20"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      <div
        className="relative flex min-h-0 flex-1 items-center justify-center px-4 sm:px-20"
        onClick={(e) => {
          if (e.target === e.currentTarget) onClose();
        }}
      >
        <img
          key={item.image}
          src={pexelsW(item.image, 1600)}
          alt={item.caption ?? ""}
          className="max-h-full max-w-full animate-pop rounded-2xl object-contain shadow-2xl"
        />
        {items.length > 1 && (
          <>
            <button
              type="button"
              onClick={prev}
              aria-label="Previous photo"
              className="absolute left-2 top-1/2 grid h-12 w-12 -translate-y-1/2 place-items-center rounded-full bg-white/10 text-white transition hover:bg-white/25 sm:left-6"
            >
              <ChevronLeft className="h-6 w-6" />
            </button>
            <button
              type="button"
              onClick={next}
              aria-label="Next photo"
              className="absolute right-2 top-1/2 grid h-12 w-12 -translate-y-1/2 place-items-center rounded-full bg-white/10 text-white transition hover:bg-white/25 sm:right-6"
            >
              <ChevronRight className="h-6 w-6" />
            </button>
          </>
        )}
      </div>

      {item.caption && <p className="px-6 pt-3 text-center text-sm font-medium text-navy-100">{item.caption}</p>}

      <div className="flex gap-2 overflow-x-auto px-4 py-4 sm:justify-center">
        {items.map((it, i) => (
          <button
            key={`${it.image}-${i}`}
            type="button"
            onClick={() => onChange(i)}
            aria-label={`Show photo ${i + 1}`}
            className={cn(
              "h-14 w-20 shrink-0 overflow-hidden rounded-lg ring-2 transition",
              i === index ? "opacity-100 ring-sunset-400" : "opacity-50 ring-transparent hover:opacity-100",
            )}
          >
            <img src={pexels(it.image, 160, 112)} alt="" loading="lazy" className="h-full w-full object-cover" />
          </button>
        ))}
      </div>
    </div>
  );
}
