import { useState, type FormEvent } from "react";
import { ArrowRight, Check, LoaderCircle, Mail } from "lucide-react";
import { CONTACT, FORM } from "@/config";
import { mailLink } from "@/lib/utils";
import { cn } from "@/utils/cn";
import { useToast } from "./Toast";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export function Newsletter({ dark, className }: { dark?: boolean; className?: string }) {
  const [email, setEmail] = useState("");
  const [state, setState] = useState<"idle" | "sending" | "done">("idle");
  const [error, setError] = useState("");
  const toast = useToast();

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const value = email.trim();
    if (!EMAIL_RE.test(value)) {
      setError("Please enter a valid email address.");
      return;
    }
    setError("");
    if (FORM.web3formsAccessKey) {
      setState("sending");
      try {
        const fd = new FormData();
        fd.append("access_key", FORM.web3formsAccessKey);
        fd.append("subject", "New newsletter subscriber – SAARC Holiday website");
        fd.append("from_name", "SAARC Holiday Website");
        fd.append("email", value);
        fd.append("message", `Please add ${value} to the offers & travel deals mailing list.`);
        const res = await fetch("https://api.web3forms.com/submit", {
          method: "POST",
          headers: { Accept: "application/json" },
          body: fd,
        });
        const json = (await res.json()) as { success?: boolean };
        if (!json.success) throw new Error("failed");
      } catch {
        setState("idle");
        toast("Couldn't subscribe right now — please try again.", "error");
        return;
      }
    } else {
      window.location.href = mailLink(
        CONTACT.emails[0].value,
        "Subscribe me to SAARC Holiday offers",
        `Hello SAARC Holiday,\n\nPlease add ${value} to your offers & travel deals list.\n\nThank you!`,
      );
    }
    setState("done");
    setEmail("");
    toast("Thank you for subscribing!", "success");
  };

  if (state === "done") {
    return (
      <div
        role="status"
        className={cn(
          "flex items-center gap-3 rounded-2xl px-5 py-4 text-sm font-semibold",
          dark ? "bg-white/10 text-white" : "bg-emerald-50 text-emerald-700",
          className,
        )}
      >
        <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-emerald-500 text-white">
          <Check className="h-4 w-4" />
        </span>
        You're on the list — watch your inbox for exclusive deals!
      </div>
    );
  }

  return (
    <form onSubmit={submit} noValidate className={className}>
      <div
        className={cn(
          "flex items-center gap-2 rounded-full p-1.5 ring-1 transition focus-within:ring-2",
          dark
            ? "bg-white/10 ring-white/15 focus-within:ring-sunset-400"
            : "bg-white shadow-lg shadow-navy-900/5 ring-slate-200 focus-within:ring-lagoon-400",
        )}
      >
        <Mail className={cn("ml-3 h-4 w-4 shrink-0", dark ? "text-navy-200" : "text-slate-400")} />
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Your email address"
          aria-label="Email address"
          aria-invalid={!!error}
          className={cn(
            "min-w-0 flex-1 bg-transparent px-1 py-2 text-sm focus:outline-none",
            dark ? "text-white placeholder:text-navy-300" : "text-navy-900 placeholder:text-slate-400",
          )}
        />
        <button
          type="submit"
          disabled={state === "sending"}
          className="inline-flex shrink-0 items-center gap-1.5 rounded-full bg-sunset-500 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-sunset-600 disabled:opacity-70 sm:px-5"
        >
          {state === "sending" ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <ArrowRight className="h-4 w-4" />}
          Subscribe
        </button>
      </div>
      {error && (
        <p role="alert" className={cn("mt-2 pl-4 text-xs font-medium", dark ? "text-rose-300" : "text-rose-600")}>
          {error}
        </p>
      )}
    </form>
  );
}
