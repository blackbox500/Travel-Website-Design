import { useId, useState } from "react";
import { Plus } from "lucide-react";
import { cn } from "@/utils/cn";

export function Accordion({ items, defaultOpen = 0 }: { items: { q: string; a: string }[]; defaultOpen?: number | null }) {
  const [open, setOpen] = useState<number | null>(defaultOpen);
  const id = useId();
  return (
    <ul className="space-y-3">
      {items.map((f, i) => {
        const isOpen = open === i;
        return (
          <li
            key={f.q}
            className={cn(
              "overflow-hidden rounded-2xl border bg-white transition-all duration-300",
              isOpen ? "border-lagoon-200 shadow-lg shadow-lagoon-500/5" : "border-slate-200 hover:border-slate-300",
            )}
          >
            <h3>
              <button
                type="button"
                aria-expanded={isOpen}
                aria-controls={`${id}-${i}`}
                onClick={() => setOpen(isOpen ? null : i)}
                className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left font-semibold text-navy-900 sm:px-6"
              >
                {f.q}
                <span
                  className={cn(
                    "grid h-8 w-8 shrink-0 place-items-center rounded-full transition duration-300",
                    isOpen ? "rotate-45 bg-sunset-500 text-white" : "bg-slate-100 text-navy-900",
                  )}
                >
                  <Plus className="h-4 w-4" />
                </span>
              </button>
            </h3>
            <div
              id={`${id}-${i}`}
              role="region"
              className={cn("grid transition-[grid-template-rows] duration-300 ease-out", isOpen ? "grid-rows-[1fr]" : "grid-rows-[0fr]")}
            >
              <div className="overflow-hidden">
                <p className="px-5 pb-5 text-sm leading-relaxed text-slate-600 sm:px-6">{f.a}</p>
              </div>
            </div>
          </li>
        );
      })}
    </ul>
  );
}
