import { useEffect, useState, type FormEvent } from "react";
import { ArrowUp, Phone, Send, X } from "lucide-react";
import { CONTACT, SITE } from "@/config";
import { cn } from "@/utils/cn";
import { useOfficeStatus, useScrolled } from "@/lib/hooks";
import { telLink, waLink } from "@/lib/utils";
import { StatusDot } from "./ui/primitives";
import { WhatsAppIcon } from "./ui/BrandIcons";

const QUICK_REPLIES = [
  "I'm interested in a Bhutan tour package",
  "Tell me about the 3-country visa offer",
  "I need a hotel booking",
  "Can you quote an air ticket?",
];

export function FloatingChat() {
  const [open, setOpen] = useState(false);
  const [hint, setHint] = useState(false);
  const [text, setText] = useState("");
  const scrolled = useScrolled(700);
  const { status, time } = useOfficeStatus();

  useEffect(() => {
    const show = window.setTimeout(() => setHint(true), 6000);
    const hide = window.setTimeout(() => setHint(false), 16000);
    return () => {
      window.clearTimeout(show);
      window.clearTimeout(hide);
    };
  }, []);

  useEffect(() => {
    if (!open) return;
    setHint(false);
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  const send = (msg: string) => {
    if (!msg.trim()) return;
    window.open(waLink(msg.trim()), "_blank", "noopener,noreferrer");
    setText("");
  };

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    send(text);
  };

  return (
    <div className="fixed bottom-4 right-4 z-40 flex flex-col items-end gap-3 sm:bottom-6 sm:right-6">
      <div
        role="dialog"
        aria-label="Chat with SAARC Holiday on WhatsApp"
        inert={!open}
        className={cn(
          "w-[calc(100vw-2rem)] max-w-sm origin-bottom-right overflow-hidden rounded-3xl bg-white shadow-2xl shadow-navy-900/25 ring-1 ring-slate-200 transition-all duration-300",
          open ? "translate-y-0 scale-100 opacity-100" : "pointer-events-none translate-y-4 scale-90 opacity-0",
        )}
      >
        <div className="flex items-center gap-3 bg-[#075E54] px-5 py-4 text-white">
          <span className="relative grid h-11 w-11 place-items-center rounded-full bg-white text-sm font-extrabold text-navy-900">
            SH
            <span className="absolute -bottom-0.5 -right-0.5 rounded-full border-2 border-[#075E54]">
              <StatusDot open={status.open} soon={status.closingSoon} />
            </span>
          </span>
          <div className="min-w-0 flex-1">
            <p className="font-bold">{SITE.name}</p>
            <p className="truncate text-xs text-white/75">
              {status.open ? "Online · typically replies within hours" : `Away · ${status.detail}`}
            </p>
          </div>
          <button type="button" onClick={() => setOpen(false)} aria-label="Close chat" className="grid h-8 w-8 place-items-center rounded-full hover:bg-white/10">
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="space-y-3 bg-[#ECE5DD] px-4 py-5">
          <div className="max-w-[85%] rounded-2xl rounded-tl-sm bg-white px-4 py-3 text-sm text-slate-700 shadow-sm">
            Hello! 👋 Welcome to {SITE.name}. How can we help you plan your journey today?
            <span className="mt-1 block text-right text-[10px] text-slate-400">{time}</span>
          </div>
          <p className="pt-1 text-[11px] font-semibold uppercase tracking-wider text-slate-500">Quick questions</p>
          <div className="flex flex-col items-end gap-2">
            {QUICK_REPLIES.map((q) => (
              <button
                key={q}
                type="button"
                onClick={() => send(q)}
                className="rounded-2xl rounded-tr-sm bg-[#DCF8C6] px-4 py-2 text-right text-sm font-medium text-slate-700 shadow-sm transition hover:-translate-x-0.5 hover:bg-[#cdf2b3]"
              >
                {q}
              </button>
            ))}
          </div>
        </div>

        <form onSubmit={onSubmit} className="flex items-center gap-2 border-t border-slate-100 p-3">
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Type your message…"
            aria-label="Your message"
            className="min-w-0 flex-1 rounded-full bg-slate-100 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#25D366]/40"
          />
          <button
            type="submit"
            disabled={!text.trim()}
            aria-label="Send chat message via WhatsApp"
            className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-[#25D366] text-white transition hover:bg-[#1ebe5a] disabled:opacity-40"
          >
            <Send className="h-4 w-4" />
          </button>
        </form>
        <a
          href={telLink(CONTACT.phones[0].value)}
          className="flex items-center justify-center gap-2 border-t border-slate-100 py-2.5 text-xs font-semibold text-slate-500 transition hover:text-navy-900"
        >
          <Phone className="h-3.5 w-3.5" /> Prefer to call? {CONTACT.phones[0].display}
        </a>
      </div>

      <div className="flex items-center gap-3">
        {hint && !open && scrolled && (
          <button
            type="button"
            onClick={() => setOpen(true)}
            className="hidden animate-fade-up rounded-2xl rounded-br-sm bg-white px-4 py-2.5 text-sm font-semibold text-navy-900 shadow-xl ring-1 ring-slate-200 sm:block"
          >
            Need help planning? Chat with us 👋
          </button>
        )}
        <button
          type="button"
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          aria-label="Back to top"
          className={cn(
            "grid h-11 w-11 place-items-center rounded-full bg-white text-navy-900 shadow-lg ring-1 ring-slate-200 transition-all duration-300 hover:-translate-y-0.5",
            scrolled && !open ? "scale-100 opacity-100" : "pointer-events-none scale-75 opacity-0",
          )}
        >
          <ArrowUp className="h-5 w-5" />
        </button>
        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          aria-expanded={open}
          aria-label={open ? "Close chat" : "Chat with us on WhatsApp"}
          className="relative grid h-14 w-14 place-items-center rounded-full bg-[#25D366] text-white shadow-xl shadow-emerald-600/30 transition hover:scale-105 active:scale-95"
        >
          {!open && <span className="absolute inset-0 animate-ping rounded-full bg-[#25D366] opacity-25" />}
          {open ? <X className="h-6 w-6" /> : <WhatsAppIcon className="h-7 w-7 animate-wiggle" />}
        </button>
      </div>
    </div>
  );
}
