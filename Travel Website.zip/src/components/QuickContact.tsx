import { useState, type ComponentType, type ReactNode } from "react";
import { ArrowUpRight, Check, Copy, Mail, MapPin, Navigation, Phone } from "lucide-react";
import { CONTACT } from "@/config";
import { cn } from "@/utils/cn";
import { copyText, directionsUrl, mailLink, telLink, waLink } from "@/lib/utils";
import { useToast } from "./ui/Toast";
import { Reveal } from "./ui/Reveal";
import { WhatsAppIcon } from "./ui/BrandIcons";

type Accent = "navy" | "green" | "lagoon" | "sunset";

const ACCENTS: Record<Accent, { icon: string; glow: string; bar: string }> = {
  navy: { icon: "bg-navy-900 text-white shadow-navy-900/30", glow: "from-navy-100", bar: "bg-navy-900" },
  green: { icon: "bg-[#25D366] text-white shadow-emerald-500/30", glow: "from-emerald-100", bar: "bg-[#25D366]" },
  lagoon: { icon: "bg-lagoon-500 text-white shadow-lagoon-500/30", glow: "from-lagoon-100", bar: "bg-lagoon-500" },
  sunset: { icon: "bg-sunset-500 text-white shadow-sunset-500/30", glow: "from-sunset-100", bar: "bg-sunset-500" },
};

function useCopy() {
  const toast = useToast();
  const [copied, setCopied] = useState<string | null>(null);
  const copy = async (text: string, what: string) => {
    const ok = await copyText(text);
    toast(ok ? `${what} copied` : "Couldn't copy – please copy it manually", ok ? "success" : "error");
    if (ok) {
      setCopied(text);
      window.setTimeout(() => setCopied((c) => (c === text ? null : c)), 1600);
    }
  };
  return { copied, copy };
}

function Card({
  accent,
  icon: Icon,
  title,
  text,
  children,
  delay,
}: {
  accent: Accent;
  icon: ComponentType<{ className?: string }>;
  title: string;
  text: string;
  children: ReactNode;
  delay: number;
}) {
  const a = ACCENTS[accent];
  return (
    <Reveal delay={delay} className="h-full">
      <div className="group relative flex h-full flex-col overflow-hidden rounded-3xl border border-slate-200/70 bg-white p-6 shadow-xl shadow-navy-900/[0.06] transition duration-300 hover:-translate-y-1.5 hover:shadow-2xl hover:shadow-navy-900/10">
        <div className={cn("absolute inset-x-0 top-0 h-1 origin-left scale-x-0 transition-transform duration-500 group-hover:scale-x-100", a.bar)} />
        <div className={cn("pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full bg-radial to-transparent opacity-0 transition group-hover:opacity-100", a.glow)} />
        <span className={cn("grid h-12 w-12 place-items-center rounded-2xl shadow-lg transition duration-300 group-hover:rotate-6 group-hover:scale-110", a.icon)}>
          <Icon className="h-6 w-6" />
        </span>
        <h3 className="mt-5 text-lg font-bold text-navy-900">{title}</h3>
        <p className="mt-1 text-sm text-slate-500">{text}</p>
        <div className="mt-5 flex flex-1 flex-col justify-end gap-2">{children}</div>
      </div>
    </Reveal>
  );
}

function CopyRow({ value, href, label, copied, onCopy, actionIcon: ActionIcon }: {
  value: string;
  href: string;
  label: string;
  copied: boolean;
  onCopy: () => void;
  actionIcon: ComponentType<{ className?: string }>;
}) {
  return (
    <div className="flex items-center gap-1.5 rounded-2xl bg-slate-50 p-1.5 pl-3.5 ring-1 ring-slate-100 transition hover:ring-slate-200">
      <a href={href} className="min-w-0 flex-1 truncate text-sm font-semibold text-navy-900 hover:text-sunset-600" title={value}>
        {value}
      </a>
      <a href={href} aria-label={label} className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-white text-navy-900 shadow-sm transition hover:bg-navy-900 hover:text-white">
        <ActionIcon className="h-4 w-4" />
      </a>
      <button
        type="button"
        onClick={onCopy}
        aria-label={`Copy ${value}`}
        className={cn(
          "grid h-8 w-8 shrink-0 place-items-center rounded-xl shadow-sm transition",
          copied ? "bg-emerald-500 text-white" : "bg-white text-slate-500 hover:bg-slate-900 hover:text-white",
        )}
      >
        {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
      </button>
    </div>
  );
}

export function QuickContact() {
  const { copied, copy } = useCopy();
  return (
    <section aria-label="Ways to contact us" className="relative z-10 -mt-28 lg:-mt-32">
      <div className="mx-auto grid max-w-7xl gap-5 px-4 sm:grid-cols-2 sm:px-6 lg:grid-cols-4 lg:px-8">
        <Card accent="navy" icon={Phone} title="Call us" text="Speak directly with a travel expert." delay={0}>
          {CONTACT.phones.map((p) => (
            <CopyRow
              key={p.value}
              value={p.display}
              href={telLink(p.value)}
              label={`Call ${p.display}`}
              copied={copied === p.display}
              onCopy={() => copy(p.display, "Phone number")}
              actionIcon={Phone}
            />
          ))}
        </Card>

        <Card accent="green" icon={WhatsAppIcon} title="WhatsApp" text="Chat instantly — share photos & documents." delay={80}>
          <a
            href={waLink("Hello SAARC Holiday! I'd like some help planning a trip.")}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-between rounded-2xl bg-[#25D366] px-4 py-3 text-sm font-bold text-white transition hover:bg-[#1ebe5a]"
          >
            Start a chat
            <ArrowUpRight className="h-4 w-4" />
          </a>
          <div className="flex flex-wrap gap-1.5">
            {["Tour package", "Visa", "Hotel"].map((t) => (
              <a
                key={t}
                href={waLink(`Hello SAARC Holiday! I'd like to know about ${t.toLowerCase()} options.`)}
                target="_blank"
                rel="noopener noreferrer"
                className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700 ring-1 ring-emerald-100 transition hover:bg-emerald-100"
              >
                {t}
              </a>
            ))}
          </div>
        </Card>

        <Card accent="lagoon" icon={Mail} title="Email us" text="Get a detailed quote in your inbox." delay={160}>
          {CONTACT.emails.map((e) => (
            <CopyRow
              key={e.value}
              value={e.value}
              href={mailLink(e.value)}
              label={`Email ${e.value}`}
              copied={copied === e.value}
              onCopy={() => copy(e.value, "Email address")}
              actionIcon={Mail}
            />
          ))}
        </Card>

        <Card accent="sunset" icon={MapPin} title="Visit our office" text={CONTACT.address.full} delay={240}>
          <div className="grid grid-cols-2 gap-2">
            <a
              href={directionsUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-1.5 rounded-2xl bg-sunset-500 px-3 py-3 text-sm font-bold text-white transition hover:bg-sunset-600"
            >
              <Navigation className="h-4 w-4" />
              Directions
            </a>
            <button
              type="button"
              onClick={() => copy(CONTACT.address.full, "Address")}
              className={cn(
                "flex items-center justify-center gap-1.5 rounded-2xl px-3 py-3 text-sm font-bold ring-1 transition",
                copied === CONTACT.address.full ? "bg-emerald-50 text-emerald-700 ring-emerald-200" : "bg-white text-navy-900 ring-slate-200 hover:bg-slate-50",
              )}
            >
              {copied === CONTACT.address.full ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              {copied === CONTACT.address.full ? "Copied" : "Copy"}
            </button>
          </div>
        </Card>
      </div>
    </section>
  );
}
