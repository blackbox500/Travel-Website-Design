import { ArrowRight, Phone } from "lucide-react";
import { CONTACT, CTA_IMAGE } from "@/config";
import { openEnquiry, type EnquiryPreset } from "@/lib/enquiryBus";
import { pexels, telLink } from "@/lib/utils";
import { Reveal } from "./ui/Reveal";

export function CTABanner({
  eyebrow = "Your Dream, Our Mission!",
  title = "Ready to start your next journey?",
  text = "From the monasteries of Bhutan to the beaches of Thailand — let's turn your travel plans into memories that last a lifetime.",
  image = CTA_IMAGE,
  preset = { mode: "plan" },
  button = "Get a free quote",
}: {
  eyebrow?: string;
  title?: string;
  text?: string;
  image?: number;
  preset?: EnquiryPreset;
  button?: string;
}) {
  return (
    <section className="px-4 pb-20 sm:px-6 sm:pb-24 lg:px-8 print:hidden">
      <Reveal className="mx-auto max-w-7xl">
        <div className="relative overflow-hidden rounded-[2.5rem] bg-navy-950">
          <img src={pexels(image, 1600, 700)} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover opacity-70" />
          <div className="absolute inset-0 bg-linear-to-r from-navy-950 via-navy-950/85 to-navy-950/10" />
          <div className="relative grid gap-8 px-6 py-14 sm:px-12 sm:py-16 lg:grid-cols-5 lg:items-center">
            <div className="lg:col-span-3">
              <p className="font-script text-3xl text-sunset-300">{eyebrow}</p>
              <h2 className="mt-2 text-3xl font-extrabold tracking-tight text-balance text-white sm:text-4xl">{title}</h2>
              <p className="mt-4 max-w-lg text-navy-100">{text}</p>
            </div>
            <div className="flex flex-col gap-3 sm:flex-row lg:col-span-2 lg:flex-col lg:items-end xl:flex-row xl:justify-end">
              <button
                type="button"
                onClick={() => openEnquiry(preset)}
                className="group inline-flex items-center justify-center gap-2 rounded-full bg-sunset-500 px-7 py-4 text-sm font-bold text-white shadow-xl shadow-sunset-500/30 transition hover:-translate-y-0.5 hover:bg-sunset-600"
              >
                {button}
                <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
              </button>
              <a
                href={telLink(CONTACT.phones[0].value)}
                className="inline-flex items-center justify-center gap-2 rounded-full border border-white/25 bg-white/10 px-7 py-4 text-sm font-bold text-white backdrop-blur transition hover:bg-white/20"
              >
                <Phone className="h-4 w-4" />
                {CONTACT.phones[0].display}
              </a>
            </div>
          </div>
        </div>
      </Reveal>
    </section>
  );
}
