import { CONTACT } from "@/config";

const pad = (n: number) => String(n).padStart(2, "0");

/** Optimised, cropped Pexels CDN image */
export const pexels = (id: number, w = 800, h = 600) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=${w}&h=${h}`;

/** Un-cropped Pexels image (keeps the original aspect ratio) */
export const pexelsW = (id: number, w = 1600) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&w=${w}`;

export const flagUrl = (code: string) => `https://flagcdn.com/w40/${code}.png`;

export const formatBDT = (n: number) => `BDT ${n.toLocaleString("en-IN")}`;

export const slugify = (s: string) =>
  s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");

export const telLink = (value: string) => `tel:${value}`;

export const waLink = (text?: string, number: string = CONTACT.whatsapp.number) =>
  `https://wa.me/${number}${text ? `?text=${encodeURIComponent(text)}` : ""}`;

/** Share any text on WhatsApp (recipient chosen by the user) */
export const waShareLink = (text: string) => `https://wa.me/?text=${encodeURIComponent(text)}`;

export const fbShareLink = (url: string) => `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;

export function mailLink(to: string, subject?: string, body?: string) {
  const q: string[] = [];
  if (subject) q.push(`subject=${encodeURIComponent(subject)}`);
  if (body) q.push(`body=${encodeURIComponent(body)}`);
  return `mailto:${to}${q.length ? `?${q.join("&")}` : ""}`;
}

export const mapEmbedUrl = (type: "m" | "k", zoom: number) =>
  `https://maps.google.com/maps?q=${CONTACT.map.lat},${CONTACT.map.lng}&t=${type}&z=${zoom}&hl=en&ie=UTF8&iwloc=&output=embed`;

export const directionsUrl = () =>
  `https://www.google.com/maps/dir/?api=1&destination=${CONTACT.map.lat},${CONTACT.map.lng}`;

/**
 * Smooth-scroll an element into view below the sticky header.
 * (scrollIntoView ignores scroll-margin on overflow-hidden elements in Chrome.)
 */
export function scrollToEl(el: HTMLElement | null, gap = 20) {
  if (!el) return;
  const header = document.querySelector<HTMLElement>("[data-sticky-header]");
  const headerH = header ? Math.min(header.getBoundingClientRect().height, 66) : 0;
  const top = el.getBoundingClientRect().top + window.scrollY - headerH - gap;
  window.scrollTo({ top: Math.max(0, top), behavior: "smooth" });
}

/** Copy text with a graceful fallback for non-secure (http) pages */
export async function copyText(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    /* fall through to legacy method */
  }
  try {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand("copy");
    document.body.removeChild(ta);
    return ok;
  } catch {
    return false;
  }
}

export function makeRef() {
  const d = new Date();
  const rnd = Math.floor(1000 + Math.random() * 9000);
  return `SH-${String(d.getFullYear()).slice(2)}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${rnd}`;
}

export function todayISO() {
  const d = new Date();
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function formatDate(iso: string, withYear = true) {
  if (!iso) return "";
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, m - 1, d).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "short",
    ...(withYear ? { year: "numeric" } : {}),
  });
}

export function nightsBetween(a: string, b: string) {
  const [y1, m1, d1] = a.split("-").map(Number);
  const [y2, m2, d2] = b.split("-").map(Number);
  return Math.round((Date.UTC(y2, m2 - 1, d2) - Date.UTC(y1, m1 - 1, d1)) / 86_400_000);
}

export function nextMonths(count: number) {
  const out: string[] = [];
  const d = new Date();
  d.setDate(1);
  for (let i = 0; i < count; i++) {
    out.push(d.toLocaleDateString("en-GB", { month: "short", year: "numeric" }));
    d.setMonth(d.getMonth() + 1);
  }
  return out;
}

/** "Dhaka (DAC)" → "DAC", "Bangkok" → "BAN" */
export function cityCode(value: string) {
  const inParens = value.match(/\(([A-Za-z]{3})\)/);
  if (inParens) return inParens[1].toUpperCase();
  const letters = value.replace(/[^A-Za-z]/g, "");
  return letters ? letters.slice(0, 3).toUpperCase() : "???";
}
