import type { ServiceId } from "@/config";
import { navigate } from "./router";
import { scrollToEl } from "./utils";

/**
 * Lets any button on any page open the enquiry form with pre-filled values.
 * If the form isn't on the current page, we navigate to /contact and apply it there.
 */
export const ENQUIRY_EVENT = "saarc:enquiry";

export interface EnquiryPreset {
  mode?: "plan" | "quick";
  service?: ServiceId;
  destinations?: string[];
  message?: string;
  topic?: string;
  departDate?: string;
  adults?: number;
  children?: number;
  fromCity?: string;
  toCity?: string;
}

let pending: EnquiryPreset | null = null;

export function consumePendingEnquiry() {
  const p = pending;
  pending = null;
  return p;
}

export function openEnquiry(preset: EnquiryPreset = {}) {
  const form = document.getElementById("enquiry-form");
  if (form) {
    window.dispatchEvent(new CustomEvent<EnquiryPreset>(ENQUIRY_EVENT, { detail: preset }));
    scrollToEl(form);
    return;
  }
  pending = preset;
  navigate("/contact");
}
