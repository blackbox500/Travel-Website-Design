import { useEffect, useSyncExternalStore, type AnchorHTMLAttributes } from "react";
import { SITE } from "@/config";

/**
 * Tiny hash router (#/tours/bhutan-classic…).
 * Hash URLs let the whole site work as a single uploaded index.html on any host.
 */

function readHash() {
  const raw = window.location.hash.replace(/^#!?/, "");
  return raw.startsWith("/") ? raw : "/";
}

function subscribe(callback: () => void) {
  window.addEventListener("hashchange", callback);
  return () => window.removeEventListener("hashchange", callback);
}

export function useLocation() {
  const full = useSyncExternalStore(subscribe, readHash, () => "/");
  const q = full.indexOf("?");
  const raw = q === -1 ? full : full.slice(0, q);
  const pathname = raw.length > 1 ? raw.replace(/\/+$/, "") : raw;
  return { full, pathname, search: q === -1 ? "" : full.slice(q + 1) };
}

export function navigate(to: string, opts: { replace?: boolean } = {}) {
  if (readHash() === to) {
    window.scrollTo({ top: 0, behavior: "smooth" });
    return;
  }
  if (opts.replace) {
    window.history.replaceState(null, "", `#${to}`);
    window.dispatchEvent(new HashChangeEvent("hashchange"));
  } else {
    window.location.hash = to;
  }
}

type LinkProps = Omit<AnchorHTMLAttributes<HTMLAnchorElement>, "href"> & { to: string };

export function Link({ to, onClick, ...rest }: LinkProps) {
  return (
    <a
      href={`#${to}`}
      onClick={(e) => {
        onClick?.(e);
        if (!e.defaultPrevented && readHash() === to) window.scrollTo({ top: 0, behavior: "smooth" });
      }}
      {...rest}
    />
  );
}

export function matchPath(pattern: string, pathname: string): Record<string, string> | null {
  const p = pattern.split("/").filter(Boolean);
  const a = pathname.split("/").filter(Boolean);
  if (p.length !== a.length) return null;
  const params: Record<string, string> = {};
  try {
    for (let i = 0; i < p.length; i++) {
      if (p[i].startsWith(":")) params[p[i].slice(1)] = decodeURIComponent(a[i]);
      else if (p[i] !== a[i]) return null;
    }
  } catch {
    return null;
  }
  return params;
}

export const isActive = (pathname: string, to: string) =>
  to === "/" ? pathname === "/" : pathname === to || pathname.startsWith(`${to}/`);

const DEFAULT_TITLE = `${SITE.name} – Tour & Travel Agency in Dhaka, Bangladesh`;
const DEFAULT_DESC = document.querySelector('meta[name="description"]')?.getAttribute("content") ?? "";

export function useTitle(title?: string, description?: string) {
  useEffect(() => {
    document.title = title ? `${title} | ${SITE.name}` : DEFAULT_TITLE;
    document.querySelector('meta[name="description"]')?.setAttribute("content", description || DEFAULT_DESC);
  }, [title, description]);
}
