import { useCallback, useSyncExternalStore } from "react";

/** Saved tours, persisted in localStorage and synced across components & tabs */
const KEY = "saarc-wishlist-v1";
const listeners = new Set<() => void>();

function read(): string[] {
  try {
    const value = JSON.parse(localStorage.getItem(KEY) || "[]");
    return Array.isArray(value) ? value.filter((x): x is string => typeof x === "string") : [];
  } catch {
    return [];
  }
}

let cache: string[] = read();

const emit = () => listeners.forEach((l) => l());

window.addEventListener("storage", (e) => {
  if (e.key === KEY) {
    cache = read();
    emit();
  }
});

function write(next: string[]) {
  cache = next;
  try {
    localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    /* storage unavailable */
  }
  emit();
}

function subscribe(cb: () => void) {
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
}

export function useWishlist() {
  const list = useSyncExternalStore(subscribe, () => cache, () => cache);
  const toggle = useCallback((slug: string) => {
    const had = cache.includes(slug);
    write(had ? cache.filter((s) => s !== slug) : [...cache, slug]);
    return !had;
  }, []);
  const remove = useCallback((slug: string) => write(cache.filter((s) => s !== slug)), []);
  const clear = useCallback(() => write([]), []);
  return { list, has: (slug: string) => list.includes(slug), toggle, remove, clear };
}
