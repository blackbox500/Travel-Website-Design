import { OFFICE_HOURS } from "@/config";

export const DAY_NAMES = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const SHORT_TO_INDEX: Record<string, number> = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };

export const toMinutes = (hhmm: string) => {
  const [h, m] = hhmm.split(":").map(Number);
  return h * 60 + (m || 0);
};

export function formatMinutes(total: number) {
  const h = Math.floor(total / 60) % 24;
  const m = total % 60;
  const h12 = h % 12 === 0 ? 12 : h % 12;
  return `${h12}:${String(m).padStart(2, "0")} ${h >= 12 ? "PM" : "AM"}`;
}

export function formatDuration(min: number) {
  const h = Math.floor(min / 60);
  const m = min % 60;
  return h ? `${h}h ${m}m` : `${m}m`;
}

/** Weekday + minutes-since-midnight in the office's timezone (Asia/Dhaka) */
export function zonedParts(date: Date) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: OFFICE_HOURS.timezone,
    weekday: "short",
    hour: "numeric",
    minute: "numeric",
    hourCycle: "h23",
  }).formatToParts(date);
  const get = (type: string) => parts.find((p) => p.type === type)?.value ?? "0";
  return {
    day: SHORT_TO_INDEX[get("weekday")] ?? date.getDay(),
    minutes: (Number(get("hour")) % 24) * 60 + Number(get("minute")),
  };
}

export const zonedTime = (date: Date) =>
  new Intl.DateTimeFormat("en-US", { timeZone: OFFICE_HOURS.timezone, hour: "numeric", minute: "2-digit" }).format(
    date,
  );

export interface OfficeStatus {
  open: boolean;
  closingSoon: boolean;
  title: string;
  detail: string;
  minutesLeft: number | null;
}

export function getOfficeStatus(date: Date): OfficeStatus {
  const { day, minutes } = zonedParts(date);
  const today = OFFICE_HOURS.schedule[day];

  if (today) {
    const open = toMinutes(today.open);
    const close = toMinutes(today.close);
    if (minutes >= open && minutes < close) {
      const left = close - minutes;
      return {
        open: true,
        closingSoon: left <= 60,
        title: left <= 60 ? "Closing soon" : "Open now",
        detail: `Closes at ${formatMinutes(close)}`,
        minutesLeft: left,
      };
    }
    if (minutes < open) {
      return { open: false, closingSoon: false, title: "Closed now", detail: `Opens today at ${formatMinutes(open)}`, minutesLeft: null };
    }
  }

  for (let i = 1; i <= 7; i++) {
    const d = (day + i) % 7;
    const s = OFFICE_HOURS.schedule[d];
    if (s) {
      return {
        open: false,
        closingSoon: false,
        title: "Closed now",
        detail: `Opens ${i === 1 ? "tomorrow" : DAY_NAMES[d]} at ${formatMinutes(toMinutes(s.open))}`,
        minutesLeft: null,
      };
    }
  }
  return { open: false, closingSoon: false, title: "Closed", detail: "", minutesLeft: null };
}

/** Week starting Saturday (Bangladesh work week) */
export function weekSchedule(date: Date) {
  const { day } = zonedParts(date);
  return [6, 0, 1, 2, 3, 4, 5].map((i) => {
    const s = OFFICE_HOURS.schedule[i];
    return {
      index: i,
      name: DAY_NAMES[i],
      hours: s ? `${formatMinutes(toMinutes(s.open))} – ${formatMinutes(toMinutes(s.close))}` : "Closed",
      closed: !s,
      isToday: i === day,
    };
  });
}
