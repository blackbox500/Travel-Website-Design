/**
 * ============================================================================
 *  SAARC HOLIDAY – SITE CONFIGURATION
 *  ---------------------------------------------------------------------------
 *  Contact details, settings, offers and FAQs live in this file.
 *   • Tour packages   → src/data/tours.ts
 *   • Destinations    → src/data/destinations.ts
 *   • Blog articles   → src/data/blog.ts
 *   • Visa checklists → src/data/visa.ts
 *   • Testimonials    → src/data/testimonials.ts   (⚠️ sample content)
 * ============================================================================
 */

/** Logo is bundled into index.html, so the site keeps working even if WordPress is removed */
import logoUrl from "@/assets/saarc-logo.png";

export type ServiceId = "tour" | "visa" | "hotel" | "air" | "group" | "other";

export const SITE = {
  name: "SAARC Holiday",
  fullName: "SAARC Holiday Tour & Travel",
  tagline: "Your Journey, Our Commitment.",
  url: "https://saarcholiday.com/",
  logo: logoUrl,
  membership: "Member of TOAB",
  about:
    "SAARC Holiday is a trusted travel and tourism agency committed to creating seamless, memorable, and affordable travel experiences for travelers from Bangladesh and beyond.",
  aboutLong: [
    "SAARC Holiday is a trusted travel and tourism agency committed to creating seamless, memorable, and affordable travel experiences for travelers from Bangladesh and beyond. With extensive knowledge of regional and international tourism, we specialize in delivering thoughtfully designed holiday packages, visa assistance, tour arrangements, and personalized travel solutions tailored to the unique needs and preferences of every traveler.",
    "At SAARC Holiday, we believe that travel is more than simply visiting a destination—it is about discovering new cultures, creating meaningful experiences, and making memories that last a lifetime. With a strong focus on reliability, personalized service, and customer satisfaction, we strive to make every journey smooth, enjoyable, and truly unforgettable.",
  ],
};

/** ⚙️ Global settings */
export const SETTINGS = {
  /** Show tour prices. Set to false to display "Price on request" everywhere. */
  showPrices: true,
  /** Child (2–11 yrs) price as a share of the adult price – used for estimates on tour pages. */
  childPriceRatio: 0.75,
  /** ⚠️ Reviews in src/data/testimonials.ts are SAMPLES – replace them with real reviews or set this to false. */
  showTestimonials: true,
  priceNote:
    "Prices are per person on a twin-sharing basis for the land package and exclude international airfare unless stated. Final prices depend on travel dates, hotel availability and exchange rates.",
};

export const CONTACT = {
  phones: [
    { label: "Hotline", display: "+880 1805-484118", value: "+8801805484118" },
    { label: "Alternate", display: "+880 1894-711317", value: "+8801894711317" },
  ],
  /** Number used for every WhatsApp button (digits only, with country code). */
  whatsapp: { number: "8801805484118", display: "+880 1805-484118" },
  emails: [
    { label: "Bookings & enquiries", value: "saarcholiday26@gmail.com" },
    { label: "General", value: "contact@saarcholiday.com" },
  ],
  address: {
    line1: "232/2 West Agargaon (8th Floor, Flat A)",
    line2: "Dhaka 1207, Bangladesh",
    full: "232/2 (8th Floor, Flat A), West Agargaon, Dhaka 1207, Bangladesh",
    short: "West Agargaon, Dhaka",
  },
  map: {
    lat: 23.7803881,
    lng: 90.3680574,
    placeUrl: "https://maps.app.goo.gl/SKFVrgEJbHhiLAJ37",
  },
  facebook: "https://www.facebook.com/profile.php?id=100071319487312",
  responseTime: "We usually reply within a few hours during office hours.",
};

/**
 * Office hours in Bangladesh time (24h "HH:MM"). 0 = Sunday … 6 = Saturday.
 * Use `null` for a closed day. ⚠️ Please confirm these with the office.
 */
export const OFFICE_HOURS: {
  timezone: string;
  schedule: Record<number, { open: string; close: string } | null>;
} = {
  timezone: "Asia/Dhaka",
  schedule: {
    6: { open: "10:00", close: "19:00" }, // Saturday
    0: { open: "10:00", close: "19:00" }, // Sunday
    1: { open: "10:00", close: "19:00" }, // Monday
    2: { open: "10:00", close: "19:00" }, // Tuesday
    3: { open: "10:00", close: "19:00" }, // Wednesday
    4: { open: "10:00", close: "19:00" }, // Thursday
    5: null, // Friday – closed
  },
};

export const FORM = {
  /**
   * Paste a FREE access key from https://web3forms.com (enter saarcholiday26@gmail.com there)
   * to receive enquiries & newsletter sign-ups straight to your inbox.
   * Leave it empty and enquiries open WhatsApp / email with the details pre-filled.
   */
  web3formsAccessKey: "",
};

/** Pexels photo IDs used on the contact page */
export const HERO_IMAGE = 7806281; // Tiger's Nest, Bhutan with prayer flags
export const CTA_IMAGE = 35408915; // Himalayan peaks at sunrise

export interface NavItem {
  label: string;
  to: string;
  mega?: boolean;
}

export const NAV: NavItem[] = [
  { label: "Home", to: "/" },
  { label: "Destinations", to: "/destinations" },
  { label: "Tours", to: "/tours", mega: true },
  { label: "Visa", to: "/visa" },
  { label: "Gallery", to: "/gallery" },
  { label: "Blog", to: "/blog" },
  { label: "About", to: "/about" },
  { label: "Contact", to: "/contact" },
];

export interface Destination {
  id: string;
  name: string;
  tagline: string;
  image: number;
  flag: string;
  code: string;
}

export const DESTINATIONS: Destination[] = [
  { id: "bhutan", name: "Bhutan", tagline: "Land of the Thunder Dragon", image: 39128859, flag: "bt", code: "PBH" },
  { id: "nepal", name: "Nepal", tagline: "Himalayan adventures", image: 32225790, flag: "np", code: "KTM" },
  { id: "india", name: "India", tagline: "Heritage & wonders", image: 11948442, flag: "in", code: "DEL" },
  { id: "china", name: "China", tagline: "Ancient meets modern", image: 19031655, flag: "cn", code: "PEK" },
  { id: "mongolia", name: "Mongolia", tagline: "Endless blue skies", image: 4321589, flag: "mn", code: "UBN" },
  { id: "thailand", name: "Thailand", tagline: "Beaches & islands", image: 28544989, flag: "th", code: "BKK" },
  { id: "malaysia", name: "Malaysia", tagline: "Truly Asia", image: 11719269, flag: "my", code: "KUL" },
  { id: "singapore", name: "Singapore", tagline: "The Lion City", image: 15480459, flag: "sg", code: "SIN" },
];

export const SERVICES: { id: ServiceId; label: string; description: string }[] = [
  { id: "tour", label: "Tour Package", description: "Hotels, transport & sightseeing in one plan" },
  { id: "visa", label: "Visa Processing", description: "Document guidance & application support" },
  { id: "hotel", label: "Hotel Booking", description: "Handpicked stays at special rates" },
  { id: "air", label: "Air Ticket", description: "Domestic & international flights" },
  { id: "group", label: "Group / Corporate", description: "Family, office & study tours" },
  { id: "other", label: "Something Else", description: "Ask us anything about travel" },
];

export interface Offer {
  id: string;
  badge: string;
  title: string;
  subtitle: string;
  price: string;
  image: number;
  link: string;
  preset: { mode: "plan"; service: ServiceId; destinations: string[]; message: string };
}

export const OFFERS: Offer[] = [
  {
    id: "visa-3",
    badge: "Limited time",
    title: "3-Country Visa Offer",
    subtitle: "Thailand · Malaysia · Singapore",
    price: "BDT 16,780",
    image: 15480459,
    link: "/blog/three-country-visa-offer",
    preset: {
      mode: "plan",
      service: "visa",
      destinations: ["thailand", "malaysia", "singapore"],
      message:
        "I'm interested in the 3-Country Visa Offer (Thailand, Malaysia & Singapore – BDT 16,780). Please share the required documents and processing details.",
    },
  },
  {
    id: "bhutan-hotel",
    badge: "Special rates",
    title: "Bhutan Hotel Special",
    subtitle: "Free Wi-Fi · Room service · Free parking",
    price: "Breakfast from Nu. 250",
    image: 39128859,
    link: "/blog/bhutan-hotel-special-offer",
    preset: {
      mode: "plan",
      service: "hotel",
      destinations: ["bhutan"],
      message: "I'd like to know more about the Bhutan Hotel Special Offer and room availability.",
    },
  },
];

export const PAYMENT_METHODS = [
  { name: "bKash", color: "#e2136e" },
  { name: "Nagad", color: "#ec1c24" },
  { name: "Rocket", color: "#8c3494" },
  { name: "VISA", color: "#1a1f71" },
  { name: "Bangla QR", color: "#006a4e" },
];

export const FAQS: { q: string; a: string; category: "General" | "Tours" | "Visa" | "Payment" }[] = [
  {
    category: "General",
    q: "How quickly will you reply to my enquiry?",
    a: "We usually reply within a few hours during office hours (Saturday to Thursday). Enquiries received late in the evening or on Friday are answered on the next working day. For anything urgent, please call or WhatsApp our hotline.",
  },
  {
    category: "Tours",
    q: "Can you customise a tour package for my family or group?",
    a: "Absolutely. Share your destination, travel dates, number of travellers and budget, and we will tailor an itinerary — hotels, transport, sightseeing and guides — around your preferences. Family, honeymoon, corporate and group tours are all welcome.",
  },
  {
    category: "Visa",
    q: "Do you help with visa processing?",
    a: "Yes. Our team guides you through the required documents, application forms and submission process for popular destinations. Please note that visa approval is solely at the discretion of the respective embassy or immigration authority.",
  },
  {
    category: "Visa",
    q: "What is the 3-Country Visa Offer?",
    a: "With one set of documents you can apply for visa processing for Thailand, Malaysia and Singapore — all for BDT 16,780. It's a limited-time offer subject to terms and conditions, so contact us to confirm what's included and the processing details.",
  },
  {
    category: "Tours",
    q: "Can you arrange hotels in Bhutan?",
    a: "Yes. Our Bhutan Hotel Special Offer includes free Wi-Fi, room service, a restaurant & bar and free parking, with breakfast from Nu. 250 per person. Room availability is subject to confirmation at the time of booking.",
  },
  {
    category: "Payment",
    q: "Which payment methods do you accept?",
    a: "You can pay securely using bKash, Nagad, Rocket, Visa cards or Bangla QR. Our team will share the payment details once your booking is confirmed.",
  },
  {
    category: "General",
    q: "Do I need to visit your office to book?",
    a: "Not at all. You can plan and book entirely by phone, WhatsApp or email. You're always welcome to visit our office in West Agargaon, Dhaka during office hours — we recommend calling ahead so the right consultant is available.",
  },
  {
    category: "General",
    q: "Are you a member of any travel association?",
    a: "Yes — SAARC Holiday is a member of TOAB (Tour Operators Association of Bangladesh), committed to reliable service and customer satisfaction.",
  },
];
