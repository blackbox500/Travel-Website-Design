import { useEffect, useMemo, useRef, useState } from "react";
import { ArrowRight, CalendarDays, ChevronDown, Clock, Link2, Lightbulb, ListChecks, Tag } from "lucide-react";
import { AUTHOR, getPost, POSTS, readingTime, type Block } from "@/data/blog";
import { getTour } from "@/data/tours";
import { openEnquiry } from "@/lib/enquiryBus";
import { Link, useTitle } from "@/lib/router";
import { copyText, fbShareLink, formatDate, pexels, scrollToEl, slugify, waShareLink } from "@/lib/utils";
import { cn } from "@/utils/cn";
import { Breadcrumbs } from "@/components/ui/PageHero";
import { useToast } from "@/components/ui/Toast";
import { FacebookIcon, WhatsAppIcon } from "@/components/ui/BrandIcons";
import { BlogCard } from "@/components/cards/BlogCard";
import { TourCard } from "@/components/cards/TourCard";
import { CTABanner } from "@/components/CTABanner";
import { NotFoundPage } from "./NotFoundPage";

/** Renders **bold** segments inside plain strings */
function Inline({ text }: { text: string }) {
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return (
    <>
      {parts.map((p, i) =>
        p.startsWith("**") && p.endsWith("**") ? (
          <strong key={i} className="font-semibold text-navy-900">
            {p.slice(2, -2)}
          </strong>
        ) : (
          <span key={i}>{p}</span>
        ),
      )}
    </>
  );
}

function BlockView({ b }: { b: Block }) {
  switch (b.type) {
    case "p":
      return (
        <p className="text-[17px] leading-8 text-slate-600">
          <Inline text={b.text} />
        </p>
      );
    case "h2":
      return (
        <h2 id={slugify(b.text)} className="scroll-mt-28 pt-4 text-2xl font-extrabold tracking-tight text-navy-900 sm:text-[28px]">
          {b.text}
        </h2>
      );
    case "h3":
      return <h3 className="pt-2 text-xl font-bold text-navy-900">{b.text}</h3>;
    case "ul":
      return (
        <ul className="space-y-3">
          {b.items.map((it, j) => (
            <li key={j} className="flex gap-3 text-[17px] leading-7 text-slate-600">
              <span className="mt-2.5 h-2 w-2 shrink-0 rounded-full bg-sunset-500" />
              <span>
                <Inline text={it} />
              </span>
            </li>
          ))}
        </ul>
      );
    case "ol":
      return (
        <ol className="space-y-3">
          {b.items.map((it, j) => (
            <li key={j} className="flex gap-3 text-[17px] leading-7 text-slate-600">
              <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-navy-900 text-xs font-bold text-white">
                {(b.start ?? 1) + j}
              </span>
              <span className="pt-0.5">
                <Inline text={it} />
              </span>
            </li>
          ))}
        </ol>
      );
    case "tip":
      return (
        <aside className="rounded-2xl border-l-4 border-sunset-500 bg-sunset-50 p-5">
          <p className="flex items-center gap-2 font-bold text-navy-900">
            <Lightbulb className="h-5 w-5 text-sunset-500" />
            {b.title}
          </p>
          <p className="mt-2 text-[15px] leading-7 text-slate-700">
            <Inline text={b.text} />
          </p>
        </aside>
      );
    case "image":
      return (
        <figure>
          <img src={pexels(b.image, 1200, 700)} alt={b.caption ?? ""} loading="lazy" className="w-full rounded-2xl object-cover" />
          {b.caption && <figcaption className="mt-2 text-center text-sm text-slate-400">{b.caption}</figcaption>}
        </figure>
      );
    case "table":
      return (
        <div className="overflow-x-auto rounded-2xl ring-1 ring-slate-200">
          <table className="w-full min-w-[480px] text-left text-sm">
            <thead className="bg-navy-900 text-white">
              <tr>
                {b.head.map((h) => (
                  <th key={h} className="px-4 py-3 font-semibold">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 bg-white">
              {b.rows.map((r, j) => (
                <tr key={j} className="even:bg-slate-50/60">
                  {r.map((c, k) => (
                    <td key={k} className={cn("px-4 py-3 text-slate-600", k === 0 && "font-semibold text-navy-900")}>
                      {c}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      );
  }
}

export function BlogPostPage({ slug }: { slug: string }) {
  const post = getPost(slug);
  useTitle(post ? post.title : "Article not found", post?.excerpt);
  const articleRef = useRef<HTMLElement>(null);
  const [progress, setProgress] = useState(0);
  const [active, setActive] = useState("");
  const toast = useToast();

  const headings = useMemo(
    () =>
      post
        ? post.content
            .filter((b): b is Extract<Block, { type: "h2" }> => b.type === "h2")
            .map((b) => ({ id: slugify(b.text), text: b.text }))
        : [],
    [post],
  );

  useEffect(() => {
    const onScroll = () => {
      const el = articleRef.current;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const total = rect.height - window.innerHeight * 0.6;
      setProgress(Math.min(1, Math.max(0, -rect.top / Math.max(1, total))));
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, [slug]);

  useEffect(() => {
    if (!headings.length) return;
    const els = headings.map((h) => document.getElementById(h.id)).filter((x): x is HTMLElement => !!x);
    const io = new IntersectionObserver(
      (entries) => {
        const visible = entries.filter((e) => e.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
        if (visible[0]) setActive(visible[0].target.id);
      },
      { rootMargin: "-90px 0px -60% 0px" },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [headings]);

  if (!post) return <NotFoundPage />;

  const url = window.location.href;
  const tour = post.relatedTour ? getTour(post.relatedTour) : undefined;
  const related = POSTS.filter((p) => p.slug !== post.slug)
    .map((p) => ({ p, score: (p.category === post.category ? 2 : 0) + p.tags.filter((t) => post.tags.includes(t)).length }))
    .sort((a, b) => b.score - a.score)
    .slice(0, 3)
    .map((x) => x.p);

  const copyLink = async () => {
    const ok = await copyText(url);
    toast(ok ? "Link copied to clipboard" : "Couldn't copy the link", ok ? "success" : "error");
  };

  const toc = (
    <ol className="space-y-1 border-l-2 border-slate-100">
      {headings.map((h) => (
        <li key={h.id}>
          <button
            type="button"
            onClick={() => scrollToEl(document.getElementById(h.id))}
            className={cn(
              "-ml-0.5 block border-l-2 py-1.5 pl-4 text-left text-sm transition",
              active === h.id ? "border-sunset-500 font-semibold text-navy-900" : "border-transparent text-slate-500 hover:text-navy-900",
            )}
          >
            {h.text}
          </button>
        </li>
      ))}
    </ol>
  );

  const shareButtons = (
    <div className="flex gap-2">
      <a
        href={fbShareLink(url)}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Share on Facebook"
        className="grid h-10 w-10 place-items-center rounded-full bg-white text-navy-900 ring-1 ring-slate-200 transition hover:bg-[#1877F2] hover:text-white hover:ring-[#1877F2]"
      >
        <FacebookIcon className="h-4 w-4" />
      </a>
      <a
        href={waShareLink(`${post.title} ${url}`)}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Share on WhatsApp"
        className="grid h-10 w-10 place-items-center rounded-full bg-white text-navy-900 ring-1 ring-slate-200 transition hover:bg-[#25D366] hover:text-white hover:ring-[#25D366]"
      >
        <WhatsAppIcon className="h-4 w-4" />
      </a>
      <button
        type="button"
        onClick={copyLink}
        aria-label="Copy link"
        className="grid h-10 w-10 place-items-center rounded-full bg-white text-navy-900 ring-1 ring-slate-200 transition hover:bg-navy-900 hover:text-white"
      >
        <Link2 className="h-4 w-4" />
      </button>
    </div>
  );

  return (
    <>
      <div
        aria-hidden
        className="fixed inset-x-0 top-0 z-[70] h-1 origin-left bg-linear-to-r from-lagoon-500 to-sunset-500 print:hidden"
        style={{ transform: `scaleX(${progress})` }}
      />

      <header className="bg-white pb-10 pt-8">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6">
          <div className="flex justify-center">
            <Breadcrumbs light={false} items={[{ label: "Home", to: "/" }, { label: "Blog", to: "/blog" }, { label: post.category }]} />
          </div>
          <span className="mt-6 inline-flex rounded-full bg-sunset-100 px-3 py-1 text-xs font-bold uppercase tracking-wider text-sunset-700">
            {post.category}
          </span>
          <h1 className="mt-4 text-3xl font-extrabold leading-tight tracking-tight text-balance text-navy-900 sm:text-5xl">{post.title}</h1>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-slate-500">{post.excerpt}</p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-sm text-slate-500">
            <span className="inline-flex items-center gap-2">
              <span className="grid h-8 w-8 place-items-center rounded-full bg-navy-900 text-[11px] font-bold text-white">SH</span>
              <span className="font-semibold text-navy-900">{AUTHOR.name}</span>
            </span>
            <span className="inline-flex items-center gap-1.5">
              <CalendarDays className="h-4 w-4" />
              {formatDate(post.date)}
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Clock className="h-4 w-4" />
              {readingTime(post)} min read
            </span>
          </div>
        </div>
        <div className="mx-auto mt-10 max-w-6xl px-4 sm:px-6">
          <img
            src={pexels(post.cover, 1600, 800)}
            alt=""
            fetchPriority="high"
            className="aspect-[16/9] w-full rounded-[2rem] object-cover shadow-2xl shadow-navy-900/15 sm:aspect-[2/1]"
          />
        </div>
      </header>

      <section className="pb-16 pt-12">
        <div className="mx-auto grid max-w-6xl gap-12 px-4 sm:px-6 lg:grid-cols-12 lg:px-8">
          <aside className="hidden lg:col-span-4 lg:block xl:col-span-3 print:hidden">
            <div className="sticky top-24 space-y-8">
              {headings.length > 0 && (
                <nav aria-label="Table of contents">
                  <p className="mb-3 flex items-center gap-2 text-xs font-bold uppercase tracking-[0.18em] text-slate-400">
                    <ListChecks className="h-4 w-4" /> In this article
                  </p>
                  {toc}
                </nav>
              )}
              <div>
                <p className="mb-3 text-xs font-bold uppercase tracking-[0.18em] text-slate-400">Share</p>
                {shareButtons}
              </div>
              {post.cta && (
                <div className="rounded-3xl bg-navy-900 p-6 text-white">
                  <p className="font-script text-2xl text-sunset-300">Inspired?</p>
                  <p className="mt-1 font-bold">Let our travel experts plan it for you.</p>
                  <button
                    type="button"
                    onClick={() => post.cta && openEnquiry(post.cta.preset)}
                    className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-full bg-sunset-500 py-3 text-sm font-bold text-white transition hover:bg-sunset-600"
                  >
                    {post.cta.label} <ArrowRight className="h-4 w-4" />
                  </button>
                </div>
              )}
            </div>
          </aside>

          <article ref={articleRef} className="min-w-0 lg:col-span-8 xl:col-span-9">
            <div className="max-w-3xl space-y-6">
              {headings.length > 0 && (
                <details className="group rounded-2xl bg-white p-4 ring-1 ring-slate-200 lg:hidden print:hidden">
                  <summary className="flex cursor-pointer list-none items-center justify-between text-sm font-bold text-navy-900">
                    <span className="flex items-center gap-2">
                      <ListChecks className="h-4 w-4 text-sunset-500" /> In this article
                    </span>
                    <ChevronDown className="h-4 w-4 transition group-open:rotate-180" />
                  </summary>
                  <div className="mt-4">{toc}</div>
                </details>
              )}

              {post.content.map((b, i) => (
                <BlockView key={i} b={b} />
              ))}

              <div className="flex flex-wrap items-center gap-2 border-t border-slate-200 pt-8">
                <Tag className="h-4 w-4 text-slate-400" />
                {post.tags.map((t) => (
                  <span key={t} className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold capitalize text-slate-600">
                    {t.replace(/-/g, " ")}
                  </span>
                ))}
              </div>

              <div className="flex flex-wrap items-center justify-between gap-4 rounded-3xl bg-white p-6 ring-1 ring-slate-200/70">
                <div className="flex items-center gap-4">
                  <span className="grid h-14 w-14 place-items-center rounded-full bg-linear-to-br from-navy-900 to-lagoon-600 text-lg font-bold text-white">
                    SH
                  </span>
                  <div>
                    <p className="font-bold text-navy-900">{AUTHOR.name}</p>
                    <p className="text-sm text-slate-500">{AUTHOR.role}</p>
                  </div>
                </div>
                <div className="lg:hidden">{shareButtons}</div>
              </div>

              {post.cta && (
                <div className="rounded-3xl bg-linear-to-r from-navy-900 to-navy-800 p-7 text-white lg:hidden">
                  <p className="font-bold">Let our travel experts plan it for you.</p>
                  <button
                    type="button"
                    onClick={() => post.cta && openEnquiry(post.cta.preset)}
                    className="mt-4 inline-flex items-center gap-2 rounded-full bg-sunset-500 px-5 py-3 text-sm font-bold text-white"
                  >
                    {post.cta.label} <ArrowRight className="h-4 w-4" />
                  </button>
                </div>
              )}

              {tour && (
                <div className="print:hidden">
                  <p className="mb-4 text-xs font-bold uppercase tracking-[0.18em] text-slate-400">Featured package</p>
                  <div className="max-w-sm">
                    <TourCard tour={tour} />
                  </div>
                </div>
              )}
            </div>
          </article>
        </div>
      </section>

      <section className="bg-white py-16 sm:py-20 print:hidden">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex items-end justify-between gap-6">
            <h2 className="text-2xl font-extrabold text-navy-900 sm:text-3xl">Keep reading</h2>
            <Link to="/blog" className="inline-flex items-center gap-1 text-sm font-bold text-sunset-600 hover:text-sunset-700">
              All articles <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {related.map((p) => (
              <BlogCard key={p.slug} post={p} />
            ))}
          </div>
        </div>
      </section>

      <div className="pt-16 sm:pt-20">
        <CTABanner />
      </div>
    </>
  );
}
