import { useTitle } from "@/lib/router";
import { Hero } from "@/components/Hero";
import { QuickContact } from "@/components/QuickContact";
import { EnquirySection } from "@/components/enquiry/EnquirySection";
import { VisitUs } from "@/components/VisitUs";
import { FAQ } from "@/components/FAQ";
import { CTABanner } from "@/components/CTABanner";

export function ContactPage() {
  useTitle(
    "Contact Us",
    "Contact SAARC Holiday Tour & Travel, West Agargaon, Dhaka. Call or WhatsApp +880 1805-484118, or send an enquiry for tour packages, visa processing, hotel booking and air tickets.",
  );
  return (
    <>
      <Hero />
      <QuickContact />
      <EnquirySection />
      <VisitUs />
      <FAQ />
      <CTABanner />
    </>
  );
}
