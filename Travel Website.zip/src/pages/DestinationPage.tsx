import { useCallback, useState } from "react";
import { ArrowRight, CalendarDays, Clock, Coins, Languages, Lightbulb, Plane, Sparkles, Stamp } from "lucide-react";
import { getDestination } from "@/data/destinations";
import { TOURS } from "@/data/tours";
import { POSTS } from "@/data/blog";
import { openEnquiry } from "@/lib/enquiryBus";
import { Link, useTitle } from "@/lib/router";
import { flagUrl, pexels, scrollToEl } from "@/lib/utils";
import { PageHero } from "@/components/ui/PageHero";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/primitives";
import { Accordion } from "@/components/ui/Accordion";
import { Lightbox, type LightboxItem } from "@/components/ui/Lightbox";
import { TourCard } from "@/components/cards/TourCard";
import { BlogCard } from "@/components/cards/BlogCard";
import { CTABanner } from "@/components/CTABanner";
import { NotFoundPage } from "./NotFoundPage";

export function DestinationPage({ id }: { id: string }) {
  const d = getDestination(id);
  useTitle(d ? `${d.name} Tours & Travel Guide` : "Destination not found", d?.summary);
  const [lightbox, setLightbox] = useState<number | null>(null);
  const closeLightbox = useCallback(() => setLightbox(null), []);

  if (!d) return <NotFoundPage />;

  const tours = TOURS.filter((t) => t.destinations.includes(d.id));
  const posts = POSTS.filter((p) => p.tags.includes(d.id)).slice(0, 3);
  const photos: LightboxItem[] = [
    ...d.highlights.map((h) => ({ image: h.image, caption: h.title })),
    ...d.gallery.filter((g) => !d.highlights.some((h) => h.image === g)).map((g) => ({ image: g, caption: d.name })),
  ];
  const facts = [
    { icon: CalendarDays, label: "Best time", value: d.facts.bestTime },
    { icon: Clock, label: "Ideal trip", value: d.facts.duration },
    { icon: Plane, label: "From Dhaka", value: d.facts.flight },
    { icon: Stamp, label: "Visa", value: d.facts.visa },
    { icon: Coins, label: "Currency", value: d.facts.currency },
    { icon: Languages, label: "Language", value: d.facts.language },
  ];

  return (
    <>
      <PageHero
        image={d.hero}
        crumbs={[{ label: "Home", to: "/" }, { label: "Destinations", to: "/destinations" }, { label: d.name }]}
        eyebrow={d.tagline}
        title={
          <span className="flex items-center gap-4">
            <img src={flagUrl(d.flag)} alt="" className="h-9 w-12 rounded-md object-cover shadow-lg ring-2 ring-white/30" />
            {d.name}
          </span>
        }
        subtitle={d.summary}
      >
        <div className="flex flex-wrap gap-3 pb-6">
          <button
            type="button"
            onClick={() => scrollToEl(document.getElementById("tours"))}
            className="inline-flex items-center gap-2 rounded-full bg-sunset-500 px-6 py-3.5 text-sm font-bold text-white shadow-xl shadow-sunset-500/30 transition hover:bg-sunset-600"
          >
            View {d.name} tours <ArrowRight className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => openEnquiry({ mode: "plan", service: "tour", destinations: [d.id] })}
            className="inline-flex items-center gap-2 rounded-full border border-white/25 bg-white/10 px-6 py-3.5 text-sm font-bold text-white backdrop-blur transition hover:bg-white/20"
          >
            <Sparkles className="h-4 w-4" /> Plan a custom trip
          </button>
        </div>
      </PageHero>

      <section className="relative z-10 -mt-16 px-4 sm:px-6 lg:px-8">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-2 rounded-[2rem] bg-white p-3 shadow-2xl shadow-navy-900/10 ring-1 ring-slate-200/70 sm:grid-cols-3 sm:p-4 lg:grid-cols-6">
          {facts.map(({ icon: I, label, value }) => (
            <div key={label} className="rounded-2xl p-3 transition hover:bg-slate-50">
              <I className="h-5 w-5 text-sunset-500" />
              <p className="mt-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">{label}</p>
              <p className="mt-0.5 text-sm font-bold leading-snug text-navy-900">{value}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="py-16 sm:py-20">
        <div className="mx-auto grid max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-3 lg:px-8">
          <Reveal className="lg:col-span-2">
            <SectionHeading align="left" eyebrow={`Discover ${d.name}`} title={`Why visit ${d.name}?`} />
            <div className="mt-6 space-y-4 text-[17px] leading-8 text-slate-600">
              {d.intro.map((p) => (
                <p key={p.slice(0, 32)}>{p}</p>
              ))}
            </div>
          </Reveal>
          <Reveal delay={100}>
            <aside className="relative h-full overflow-hidden rounded-3xl bg-navy-900 p-7 text-white">
              <div className="pointer-events-none absolute -right-12 -top-12 h-40 w-40 rounded-full bg-sunset-500/20 blur-2xl" />
              <span className="relative grid h-12 w-12 place-items-center rounded-2xl bg-sunset-500">
                <Stamp className="h-6 w-6" />
              </span>
              <h3 className="relative mt-5 text-lg font-bold">Visa for Bangladeshi travellers</h3>
              <p className="relative mt-3 text-sm leading-relaxed text-navy-100">{d.visaNote}</p>
              <Link
                to={`/visa?country=${d.id}`}
                className="relative mt-6 inline-flex items-center gap-2 rounded-full bg-white px-5 py-2.5 text-sm font-bold text-navy-900 transition hover:bg-sunset-100"
              >
                Check documents <ArrowRight className="h-4 w-4" />
              </Link>
            </aside>
          </Reveal>
        </div>
      </section>

      <section className="bg-white py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <SectionHeading eyebrow="Highlights" title={`Unmissable experiences in ${d.name}`} />
          </Reveal>
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {d.highlights.map((h, i) => (
              <Reveal key={h.title} delay={i * 80} className="h-full">
                <button
                  type="button"
                  onClick={() => setLightbox(i)}
                  className="group flex h-full w-full flex-col overflow-hidden rounded-3xl bg-white text-left shadow-lg shadow-navy-900/5 ring-1 ring-slate-200/70 transition hover:-translate-y-1 hover:shadow-2xl"
                >
                  <div className="aspect-[4/3] overflow-hidden">
                    <img src={pexels(h.image, 600, 450)} alt={h.title} loading="lazy" className="h-full w-full object-cover transition duration-700 group-hover:scale-110" />
                  </div>
                  <div className="p-5">
                    <p className="font-bold text-navy-900">{h.title}</p>
                    <p className="mt-1.5 text-sm leading-relaxed text-slate-500">{h.text}</p>
                  </div>
                </button>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section id="tours" className="scroll-mt-24 py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-end">
            <Reveal>
              <SectionHeading align="left" eyebrow="Tour packages" title={`${d.name} tours`} subtitle="Private tours you can tailor to your dates, budget and travel style." />
            </Reveal>
            <Link
              to={`/tours?destination=${d.id}`}
              className="inline-flex shrink-0 items-center gap-2 rounded-full border border-slate-200 bg-white px-5 py-2.5 text-sm font-bold text-navy-900 transition hover:border-navy-900"
            >
              Filter all tours <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          {tours.length > 0 ? (
            <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {tours.map((t, i) => (
                <Reveal key={t.slug} delay={i * 80} className="h-full">
                  <TourCard tour={t} className="h-full" />
                </Reveal>
              ))}
            </div>
          ) : (
            <div className="mt-10 rounded-3xl border border-dashed border-slate-300 bg-white p-10 text-center">
              <p className="font-bold text-navy-900">Custom {d.name} trips available on request</p>
              <button
                type="button"
                onClick={() => openEnquiry({ mode: "plan", service: "tour", destinations: [d.id] })}
                className="mt-4 rounded-full bg-navy-900 px-5 py-2.5 text-sm font-bold text-white"
              >
                Request a custom trip
              </button>
            </div>
          )}
        </div>
      </section>

      <section className="bg-white py-16 sm:py-20">
        <div className="mx-auto grid max-w-7xl gap-12 px-4 sm:px-6 lg:grid-cols-2 lg:px-8">
          <Reveal>
            <SectionHeading align="left" eyebrow="Travel tips" title={`Know before you go`} />
            <ul className="mt-8 space-y-4">
              {d.tips.map((t) => (
                <li key={t} className="flex gap-4 rounded-2xl bg-slate-50 p-4">
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-sunset-100 text-sunset-600">
                    <Lightbulb className="h-4 w-4" />
                  </span>
                  <p className="text-sm leading-relaxed text-slate-600">{t}</p>
                </li>
              ))}
            </ul>
          </Reveal>
          <Reveal delay={100}>
            <SectionHeading align="left" eyebrow="Gallery" title={`${d.name} in pictures`} />
            <div className="mt-8 grid grid-cols-3 gap-3">
              {photos.slice(0, 6).map((p, i) => (
                <button
                  key={`${p.image}-${i}`}
                  type="button"
                  onClick={() => setLightbox(i)}
                  className={`group relative overflow-hidden rounded-2xl ${i === 0 ? "col-span-2 row-span-2" : ""}`}
                  aria-label={`Open photo: ${p.caption}`}
                >
                  <img
                    src={pexels(p.image, i === 0 ? 700 : 350, i === 0 ? 700 : 350)}
                    alt=""
                    loading="lazy"
                    className="aspect-square h-full w-full object-cover transition duration-700 group-hover:scale-110"
                  />
                </button>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      <section className="py-16 sm:py-20">
        <div className="mx-auto max-w-3xl px-4 sm:px-6">
          <Reveal>
            <SectionHeading eyebrow="FAQ" title={`${d.name} travel questions`} />
          </Reveal>
          <div className="mt-10">
            <Accordion items={d.faqs} />
          </div>
        </div>
        {posts.length > 0 && (
          <div className="mx-auto mt-20 max-w-7xl px-4 sm:px-6 lg:px-8">
            <h2 className="text-2xl font-extrabold text-navy-900">Related reading</h2>
            <div className="mt-8 grid gap-6 md:grid-cols-3">
              {posts.map((p) => (
                <BlogCard key={p.slug} post={p} />
              ))}
            </div>
          </div>
        )}
      </section>

      <CTABanner
        image={d.hero}
        eyebrow={`Explore ${d.name}`}
        title={`Ready to plan your ${d.name} trip?`}
        text="Tell us your dates and budget — we'll craft a personalised itinerary and guide you through the visa process."
        preset={{ mode: "plan", service: "tour", destinations: [d.id] }}
        button={`Plan my ${d.name} trip`}
      />

      <Lightbox items={photos} index={lightbox} onClose={closeLightbox} onChange={setLightbox} />
    </>
  );
}
