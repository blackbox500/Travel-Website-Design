import { useEffect, useMemo, useState, type Dispatch, type ReactNode, type SetStateAction } from "react";
import { Search, SearchX, SlidersHorizontal, Sparkles, X } from "lucide-react";
import { DESTINATIONS, SETTINGS } from "@/config";
import { TOUR_STYLES, TOURS, type TourStyle } from "@/data/tours";
import { openEnquiry } from "@/lib/enquiryBus";
import { navigate, useLocation, useTitle } from "@/lib/router";
import { flagUrl, formatBDT } from "@/lib/utils";
import { cn } from "@/utils/cn";
import { PageHero } from "@/components/ui/PageHero";
import { TourCard } from "@/components/cards/TourCard";
import { CTABanner } from "@/components/CTABanner";

type DurationId = "short" | "medium" | "long";
const DURATIONS: { id: DurationId; label: string; test: (n: number) => boolean }[] = [
  { id: "short", label: "Up to 4 nights", test: (n) => n <= 4 },
  { id: "medium", label: "5–6 nights", test: (n) => n >= 5 && n <= 6 },
  { id: "long", label: "7+ nights", test: (n) => n >= 7 },
];

type Sort = "recommended" | "price-asc" | "price-desc" | "duration";

interface Filters {
  q: string;
  dest: string[];
  durations: DurationId[];
  styles: TourStyle[];
  maxPrice: number;
}

const PRICE_CAP = Math.ceil(Math.max(...TOURS.map((t) => t.price)) / 5000) * 5000;
const PRICE_FLOOR = Math.floor(Math.min(...TOURS.map((t) => t.price)) / 5000) * 5000;
const EMPTY: Filters = { q: "", dest: [], durations: [], styles: [], maxPrice: PRICE_CAP };

const toggleIn = <T,>(arr: T[], v: T) => (arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v]);

function fromQuery(search: string): Filters {
  const p = new URLSearchParams(search);
  const budget = Number(p.get("budget"));
  return {
    ...EMPTY,
    q: p.get("q") ?? "",
    dest: (p.get("destination") ?? "").split(",").filter((id) => DESTINATIONS.some((d) => d.id === id)),
    styles: (p.get("style") ?? "").split(",").filter((s): s is TourStyle => (TOUR_STYLES as string[]).includes(s)),
    maxPrice: budget > 0 ? Math.min(Math.max(budget, PRICE_FLOOR), PRICE_CAP) : PRICE_CAP,
  };
}

function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      className={cn(
        "rounded-full border px-3.5 py-1.5 text-xs font-semibold transition active:scale-95",
        active ? "border-navy-900 bg-navy-900 text-white" : "border-slate-200 bg-white text-slate-600 hover:border-slate-300",
      )}
    >
      {children}
    </button>
  );
}

function FilterPanel({ filters, setFilters }: { filters: Filters; setFilters: Dispatch<SetStateAction<Filters>> }) {
  const count = (id: string) => TOURS.filter((t) => t.destinations.includes(id)).length;
  return (
    <div className="space-y-7">
      <div className="relative">
        <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
        <input
          type="search"
          value={filters.q}
          onChange={(e) => setFilters((f) => ({ ...f, q: e.target.value }))}
          placeholder="Search tours or cities…"
          aria-label="Search tours"
          className="w-full rounded-xl border border-slate-200 bg-white py-3 pl-11 pr-4 text-sm shadow-sm transition placeholder:text-slate-400 focus:border-lagoon-400 focus:outline-none focus:ring-4 focus:ring-lagoon-100"
        />
      </div>

      <fieldset>
        <legend className="text-sm font-bold text-navy-900">Destination</legend>
        <div className="mt-3 space-y-1">
          {DESTINATIONS.map((d) => {
            const on = filters.dest.includes(d.id);
            return (
              <label
                key={d.id}
                className={cn(
                  "flex cursor-pointer items-center gap-3 rounded-xl px-3 py-2 text-sm transition",
                  on ? "bg-sunset-50 text-navy-900" : "text-slate-600 hover:bg-slate-50",
                )}
              >
                <input
                  type="checkbox"
                  checked={on}
                  onChange={() => setFilters((f) => ({ ...f, dest: toggleIn(f.dest, d.id) }))}
                  className="h-4 w-4 cursor-pointer accent-sunset-500"
                />
                <img src={flagUrl(d.flag)} alt="" className="h-3.5 w-5 rounded-[2px] object-cover" />
                <span className="font-semibold">{d.name}</span>
                <span className="ml-auto text-xs text-slate-400">{count(d.id)}</span>
              </label>
            );
          })}
        </div>
      </fieldset>

      <fieldset>
        <legend className="text-sm font-bold text-navy-900">Duration</legend>
        <div className="mt-3 flex flex-wrap gap-2">
          {DURATIONS.map((d) => (
            <Chip
              key={d.id}
              active={filters.durations.includes(d.id)}
              onClick={() => setFilters((f) => ({ ...f, durations: toggleIn(f.durations, d.id) }))}
            >
              {d.label}
            </Chip>
          ))}
        </div>
      </fieldset>

      {SETTINGS.showPrices && (
        <fieldset>
          <legend className="flex w-full items-center justify-between text-sm font-bold text-navy-900">
            Max budget / person
            <span className="text-xs font-bold text-sunset-600">{formatBDT(filters.maxPrice)}</span>
          </legend>
          <input
            type="range"
            min={PRICE_FLOOR}
            max={PRICE_CAP}
            step={1000}
            value={filters.maxPrice}
            onChange={(e) => setFilters((f) => ({ ...f, maxPrice: Number(e.target.value) }))}
            aria-label="Maximum budget per person"
            className="mt-4 w-full cursor-pointer accent-sunset-500"
          />
          <div className="mt-1 flex justify-between text-[11px] text-slate-400">
            <span>{formatBDT(PRICE_FLOOR)}</span>
            <span>{formatBDT(PRICE_CAP)}</span>
          </div>
        </fieldset>
      )}

      <fieldset>
        <legend className="text-sm font-bold text-navy-900">Trip style</legend>
        <div className="mt-3 flex flex-wrap gap-2">
          {TOUR_STYLES.map((s) => (
            <Chip key={s} active={filters.styles.includes(s)} onClick={() => setFilters((f) => ({ ...f, styles: toggleIn(f.styles, s) }))}>
              {s}
            </Chip>
          ))}
        </div>
      </fieldset>
    </div>
  );
}

export function ToursPage() {
  useTitle(
    "Tour Packages",
    "Private tour packages from Bangladesh to Bhutan, Nepal, India, China, Mongolia, Thailand, Malaysia and Singapore — hotels, transport and sightseeing included.",
  );
  const { search } = useLocation();
  const [filters, setFilters] = useState<Filters>(() => fromQuery(search));
  const [sort, setSort] = useState<Sort>("recommended");
  const [drawer, setDrawer] = useState(false);

  useEffect(() => {
    setFilters(fromQuery(search));
  }, [search]);

  useEffect(() => {
    if (!drawer) return;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = "";
    };
  }, [drawer]);

  const results = useMemo(() => {
    const q = filters.q.trim().toLowerCase();
    const list = TOURS.filter(
      (t) =>
        (!filters.dest.length || t.destinations.some((d) => filters.dest.includes(d))) &&
        (!filters.durations.length || filters.durations.some((id) => DURATIONS.find((x) => x.id === id)?.test(t.nights))) &&
        (!filters.styles.length || filters.styles.some((s) => t.styles.includes(s))) &&
        (!SETTINGS.showPrices || t.price <= filters.maxPrice) &&
        (!q || `${t.title} ${t.route.join(" ")} ${t.destinations.join(" ")}`.toLowerCase().includes(q)),
    );
    const sorted = [...list];
    if (sort === "price-asc") sorted.sort((a, b) => a.price - b.price);
    else if (sort === "price-desc") sorted.sort((a, b) => b.price - a.price);
    else if (sort === "duration") sorted.sort((a, b) => a.nights - b.nights);
    else sorted.sort((a, b) => Number(!!b.featured) - Number(!!a.featured));
    return sorted;
  }, [filters, sort]);

  const chips = [
    ...filters.dest.map((id) => ({
      key: `d-${id}`,
      label: DESTINATIONS.find((d) => d.id === id)?.name ?? id,
      remove: () => setFilters((f) => ({ ...f, dest: f.dest.filter((x) => x !== id) })),
    })),
    ...filters.durations.map((id) => ({
      key: `t-${id}`,
      label: DURATIONS.find((d) => d.id === id)?.label ?? id,
      remove: () => setFilters((f) => ({ ...f, durations: f.durations.filter((x) => x !== id) })),
    })),
    ...filters.styles.map((s) => ({
      key: `s-${s}`,
      label: s,
      remove: () => setFilters((f) => ({ ...f, styles: f.styles.filter((x) => x !== s) })),
    })),
    ...(SETTINGS.showPrices && filters.maxPrice < PRICE_CAP
      ? [{ key: "price", label: `Up to ${formatBDT(filters.maxPrice)}`, remove: () => setFilters((f) => ({ ...f, maxPrice: PRICE_CAP })) }]
      : []),
    ...(filters.q.trim() ? [{ key: "q", label: `“${filters.q.trim()}”`, remove: () => setFilters((f) => ({ ...f, q: "" })) }] : []),
  ];

  const reset = () => {
    setFilters(EMPTY);
    if (search) navigate("/tours", { replace: true });
  };

  return (
    <>
      <PageHero
        image={35408915}
        crumbs={[{ label: "Home", to: "/" }, { label: "Tours" }]}
        eyebrow="Find your perfect trip"
        title="Tour packages"
        subtitle="Private, fully customisable tours with hand-picked hotels, transport and sightseeing — from the Himalaya to Southeast Asia."
      />

      <section className="py-12 sm:py-16">
        <div className="mx-auto grid max-w-7xl gap-8 px-4 sm:px-6 lg:grid-cols-12 lg:px-8">
          <aside className="hidden lg:col-span-3 lg:block" aria-label="Filters">
            <div className="sticky top-24 rounded-3xl bg-white p-6 shadow-lg shadow-navy-900/5 ring-1 ring-slate-200/70">
              <div className="mb-6 flex items-center justify-between">
                <p className="flex items-center gap-2 font-bold text-navy-900">
                  <SlidersHorizontal className="h-4 w-4 text-sunset-500" /> Filters
                </p>
                {chips.length > 0 && (
                  <button type="button" onClick={reset} className="text-xs font-semibold text-slate-500 transition hover:text-rose-600">
                    Reset all
                  </button>
                )}
              </div>
              <FilterPanel filters={filters} setFilters={setFilters} />
            </div>
          </aside>

          <div className="lg:col-span-9">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <p className="text-sm text-slate-500">
                <span className="text-lg font-extrabold text-navy-900">{results.length}</span> tour{results.length === 1 ? "" : "s"} found
              </p>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setDrawer(true)}
                  className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2.5 text-sm font-bold text-navy-900 lg:hidden"
                >
                  <SlidersHorizontal className="h-4 w-4" /> Filters
                  {chips.length > 0 && (
                    <span className="grid h-5 min-w-5 place-items-center rounded-full bg-sunset-500 px-1 text-[10px] text-white">{chips.length}</span>
                  )}
                </button>
                <label className="sr-only" htmlFor="sort">
                  Sort tours
                </label>
                <select
                  id="sort"
                  value={sort}
                  onChange={(e) => setSort(e.target.value as Sort)}
                  className="cursor-pointer rounded-full border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-navy-900 focus:outline-none focus:ring-4 focus:ring-lagoon-100"
                >
                  <option value="recommended">Recommended</option>
                  {SETTINGS.showPrices && <option value="price-asc">Price: low to high</option>}
                  {SETTINGS.showPrices && <option value="price-desc">Price: high to low</option>}
                  <option value="duration">Duration: shortest first</option>
                </select>
              </div>
            </div>

            {chips.length > 0 && (
              <div className="mt-4 flex flex-wrap items-center gap-2">
                {chips.map((c) => (
                  <button
                    key={c.key}
                    type="button"
                    onClick={c.remove}
                    className="inline-flex animate-pop items-center gap-1.5 rounded-full bg-navy-50 py-1 pl-3 pr-2 text-xs font-semibold text-navy-900 transition hover:bg-navy-100"
                  >
                    {c.label}
                    <X className="h-3.5 w-3.5" />
                  </button>
                ))}
                <button type="button" onClick={reset} className="px-2 text-xs font-semibold text-slate-500 hover:text-rose-600">
                  Clear all
                </button>
              </div>
            )}

            {results.length > 0 ? (
              <div className="mt-6 grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
                {results.map((t) => (
                  <TourCard key={t.slug} tour={t} className="animate-fade-up" />
                ))}
                <div className="flex flex-col justify-between rounded-3xl bg-linear-to-br from-navy-900 to-navy-800 p-7 text-white">
                  <Sparkles className="h-9 w-9 text-sunset-400" />
                  <div className="mt-10">
                    <p className="text-xl font-extrabold">Want something different?</p>
                    <p className="mt-2 text-sm text-navy-200">
                      Every trip can be tailored — or we'll design a brand-new itinerary just for you.
                    </p>
                    <button
                      type="button"
                      onClick={() => openEnquiry({ mode: "plan", service: "tour" })}
                      className="mt-5 rounded-full bg-sunset-500 px-5 py-2.5 text-sm font-bold text-white transition hover:bg-sunset-600"
                    >
                      Plan a custom trip
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="mt-6 rounded-3xl border border-dashed border-slate-300 bg-white p-12 text-center">
                <SearchX className="mx-auto h-10 w-10 text-slate-300" />
                <p className="mt-4 text-lg font-bold text-navy-900">No tours match your filters</p>
                <p className="mt-1 text-sm text-slate-500">Try removing a filter — or ask us to create a custom trip.</p>
                <div className="mt-6 flex flex-wrap justify-center gap-3">
                  <button type="button" onClick={reset} className="rounded-full bg-navy-900 px-5 py-2.5 text-sm font-bold text-white">
                    Reset filters
                  </button>
                  <button
                    type="button"
                    onClick={() => openEnquiry({ mode: "plan", service: "tour", destinations: filters.dest })}
                    className="rounded-full border border-slate-200 px-5 py-2.5 text-sm font-bold text-navy-900"
                  >
                    Request a custom trip
                  </button>
                </div>
              </div>
            )}

            {SETTINGS.showPrices && <p className="mt-8 text-xs leading-relaxed text-slate-400">* {SETTINGS.priceNote}</p>}
          </div>
        </div>
      </section>

      {/* Mobile filter sheet */}
      <div className={cn("fixed inset-0 z-[70] lg:hidden", drawer ? "pointer-events-auto" : "pointer-events-none")} inert={!drawer}>
        <div
          onClick={() => setDrawer(false)}
          className={cn("absolute inset-0 bg-navy-950/50 transition-opacity duration-300", drawer ? "opacity-100" : "opacity-0")}
        />
        <div
          className={cn(
            "absolute inset-x-0 bottom-0 flex max-h-[88vh] flex-col rounded-t-[2rem] bg-white transition-transform duration-300",
            drawer ? "translate-y-0" : "translate-y-full",
          )}
          role="dialog"
          aria-label="Filter tours"
        >
          <div className="flex items-center justify-between border-b border-slate-100 px-6 py-4">
            <p className="font-bold text-navy-900">Filters</p>
            <button
              type="button"
              onClick={() => setDrawer(false)}
              aria-label="Close filters"
              className="grid h-9 w-9 place-items-center rounded-full bg-slate-100"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto px-6 py-5">
            <FilterPanel filters={filters} setFilters={setFilters} />
          </div>
          <div className="flex gap-3 border-t border-slate-100 p-4">
            <button type="button" onClick={reset} className="rounded-full border border-slate-200 px-5 py-3 text-sm font-bold text-navy-900">
              Reset
            </button>
            <button
              type="button"
              onClick={() => setDrawer(false)}
              className="flex-1 rounded-full bg-sunset-500 py-3 text-sm font-bold text-white"
            >
              Show {results.length} tour{results.length === 1 ? "" : "s"}
            </button>
          </div>
        </div>
      </div>

      <CTABanner />
    </>
  );
}
