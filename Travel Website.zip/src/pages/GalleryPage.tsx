import { useCallback, useMemo, useState } from "react";
import { Expand } from "lucide-react";
import { DESTINATION_INFO } from "@/data/destinations";
import { useTitle } from "@/lib/router";
import { flagUrl, pexels } from "@/lib/utils";
import { cn } from "@/utils/cn";
import { PageHero } from "@/components/ui/PageHero";
import { Lightbox } from "@/components/ui/Lightbox";
import { CTABanner } from "@/components/CTABanner";

interface GalleryItem {
  image: number;
  caption: string;
  dest: string;
}

/** Every unique destination photo, interleaved so countries are mixed */
const ALL: GalleryItem[] = (() => {
  const seen = new Set<number>();
  const groups = DESTINATION_INFO.map((d) => {
    const items: GalleryItem[] = [];
    for (const h of d.highlights) {
      if (!seen.has(h.image)) {
        seen.add(h.image);
        items.push({ image: h.image, caption: `${h.title} · ${d.name}`, dest: d.id });
      }
    }
    for (const g of d.gallery) {
      if (!seen.has(g)) {
        seen.add(g);
        items.push({ image: g, caption: d.name, dest: d.id });
      }
    }
    return items;
  });
  const out: GalleryItem[] = [];
  const max = Math.max(...groups.map((g) => g.length));
  for (let i = 0; i < max; i++) groups.forEach((g) => g[i] && out.push(g[i]));
  return out;
})();

const SHAPES = [
  { cls: "aspect-[4/5]", w: 600, h: 750 },
  { cls: "aspect-[4/3]", w: 800, h: 600 },
  { cls: "aspect-square", w: 700, h: 700 },
  { cls: "aspect-[3/4]", w: 600, h: 800 },
  { cls: "aspect-[16/11]", w: 800, h: 550 },
];

export function GalleryPage() {
  useTitle("Gallery", "Photos from Bhutan, Nepal, India, China, Mongolia, Thailand, Malaysia and Singapore — destinations you can explore with SAARC Holiday.");
  const [filter, setFilter] = useState("all");
  const [lightbox, setLightbox] = useState<number | null>(null);
  const closeLightbox = useCallback(() => setLightbox(null), []);
  const items = useMemo(() => (filter === "all" ? ALL : ALL.filter((i) => i.dest === filter)), [filter]);

  return (
    <>
      <PageHero
        image={6904727}
        crumbs={[{ label: "Home", to: "/" }, { label: "Gallery" }]}
        eyebrow="Get inspired"
        title="Travel gallery"
        subtitle="A glimpse of the mountains, monasteries, islands and cities waiting for you."
      />

      <section className="py-12 sm:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div role="tablist" aria-label="Filter photos by destination" className="flex gap-2 overflow-x-auto pb-2 lg:flex-wrap lg:justify-center">
            <button
              type="button"
              role="tab"
              aria-selected={filter === "all"}
              onClick={() => setFilter("all")}
              className={cn(
                "shrink-0 rounded-full px-4 py-2 text-sm font-bold transition",
                filter === "all" ? "bg-navy-900 text-white shadow-lg shadow-navy-900/20" : "bg-white text-slate-600 ring-1 ring-slate-200 hover:bg-slate-50",
              )}
            >
              All photos <span className="ml-1 opacity-60">{ALL.length}</span>
            </button>
            {DESTINATION_INFO.map((d) => {
              const count = ALL.filter((i) => i.dest === d.id).length;
              return (
                <button
                  key={d.id}
                  type="button"
                  role="tab"
                  aria-selected={filter === d.id}
                  onClick={() => setFilter(d.id)}
                  className={cn(
                    "inline-flex shrink-0 items-center gap-2 rounded-full px-4 py-2 text-sm font-bold transition",
                    filter === d.id ? "bg-navy-900 text-white shadow-lg shadow-navy-900/20" : "bg-white text-slate-600 ring-1 ring-slate-200 hover:bg-slate-50",
                  )}
                >
                  <img src={flagUrl(d.flag)} alt="" className="h-3.5 w-5 rounded-[2px] object-cover" />
                  {d.name}
                  <span className="opacity-60">{count}</span>
                </button>
              );
            })}
          </div>

          <div key={filter} className="mt-10 columns-1 gap-4 sm:columns-2 lg:columns-3 xl:columns-4">
            {items.map((it, i) => {
              const shape = SHAPES[i % SHAPES.length];
              return (
                <button
                  key={it.image}
                  type="button"
                  onClick={() => setLightbox(i)}
                  className={cn("group relative mb-4 block w-full animate-fade-up break-inside-avoid overflow-hidden rounded-3xl bg-slate-200", shape.cls)}
                  style={{ animationDelay: `${Math.min(i, 12) * 40}ms` }}
                  aria-label={`Open photo: ${it.caption}`}
                >
                  <img
                    src={pexels(it.image, shape.w, shape.h)}
                    alt={it.caption}
                    loading="lazy"
                    className="h-full w-full object-cover transition duration-700 group-hover:scale-110"
                  />
                  <span className="absolute inset-0 bg-linear-to-t from-navy-950/80 via-transparent to-transparent opacity-0 transition duration-300 group-hover:opacity-100" />
                  <span className="absolute inset-x-4 bottom-4 flex translate-y-2 items-end justify-between gap-3 text-left opacity-0 transition duration-300 group-hover:translate-y-0 group-hover:opacity-100">
                    <span className="text-sm font-semibold text-white">{it.caption}</span>
                    <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-white/90 text-navy-900">
                      <Expand className="h-4 w-4" />
                    </span>
                  </span>
                </button>
              );
            })}
          </div>
          <p className="mt-6 text-center text-xs text-slate-400">Photos: Pexels contributors. Replace with your own trip photos anytime.</p>
        </div>
      </section>

      <CTABanner />
      <Lightbox items={items} index={lightbox} onClose={closeLightbox} onChange={setLightbox} />
    </>
  );
}
