import { useEffect, useState, type ComponentType } from "react";
import {
  Check,
  CircleCheck,
  ClipboardList,
  FileSearch,
  Info,
  MessageCircle,
  Printer,
  RotateCcw,
  Send,
  ShieldCheck,
  Stamp,
} from "lucide-react";
import { CONTACT, DESTINATIONS, OFFERS } from "@/config";
import {
  APPLICANT_TYPES,
  BASIC_DOCS,
  COMMON_DOCS,
  TYPE_DOCS,
  VISA_COUNTRIES,
  VISA_FAQS,
  VISA_OFFER,
  type ApplicantType,
} from "@/data/visa";
import { openEnquiry } from "@/lib/enquiryBus";
import { useLocation, useTitle } from "@/lib/router";
import { flagUrl, pexels, scrollToEl, telLink, waLink } from "@/lib/utils";
import { cn } from "@/utils/cn";
import { PageHero } from "@/components/ui/PageHero";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/primitives";
import { Accordion } from "@/components/ui/Accordion";
import { WhatsAppIcon } from "@/components/ui/BrandIcons";
import { CTABanner } from "@/components/CTABanner";

type Icon = ComponentType<{ className?: string }>;

const isCountry = (c: string | null): c is string => !!c && VISA_COUNTRIES.some((v) => v.id === c);

const STEPS: { icon: Icon; title: string; text: string }[] = [
  { icon: MessageCircle, title: "Free consultation", text: "Tell us where you're going and when — we'll explain the exact requirements." },
  { icon: FileSearch, title: "Document check", text: "Our visa desk reviews your documents and flags anything missing or incorrect." },
  { icon: Send, title: "Application", text: "We prepare and submit your application, including bookings that support it." },
  { icon: ShieldCheck, title: "Updates to the end", text: "We keep you informed until your decision — and help plan the trip itself." },
];

const R = 34;
const CIRC = 2 * Math.PI * R;

export function VisaPage() {
  useTitle(
    "Visa Services",
    "Visa processing help for Bangladeshi passport holders — Thailand, Malaysia & Singapore 3-country offer for BDT 16,780, plus China, Bhutan, Nepal, India and Mongolia.",
  );
  const { search } = useLocation();
  const queryCountry = new URLSearchParams(search).get("country");
  const [country, setCountry] = useState(isCountry(queryCountry) ? queryCountry : "thailand");
  const [applicant, setApplicant] = useState<ApplicantType>("employee");
  const [checked, setChecked] = useState<Record<string, boolean>>({});

  useEffect(() => {
    if (!isCountry(queryCountry)) return;
    setCountry(queryCountry);
    const t = window.setTimeout(() => scrollToEl(document.getElementById("visa-checker")), 400);
    return () => window.clearTimeout(t);
  }, [queryCountry]);

  const info = VISA_COUNTRIES.find((c) => c.id === country) ?? VISA_COUNTRIES[0];
  const applicantLabel = APPLICANT_TYPES.find((a) => a.id === applicant)?.label ?? "";
  const docs: { text: string; tag?: string }[] =
    info.docs === "basic"
      ? [...BASIC_DOCS.map((text) => ({ text })), ...info.extras.map((text) => ({ text, tag: info.name }))]
      : [
          ...COMMON_DOCS.map((text) => ({ text })),
          ...TYPE_DOCS[applicant].map((text) => ({ text, tag: applicantLabel })),
          ...info.extras.map((text) => ({ text, tag: info.name })),
        ];
  const key = (doc: string) => `${info.id}|${doc}`;
  const ready = docs.filter((d) => checked[key(d.text)]);
  const missing = docs.filter((d) => !checked[key(d.text)]);
  const pct = docs.length ? Math.round((ready.length / docs.length) * 100) : 0;

  const waText = [
    `Hello SAARC Holiday! I'm preparing a ${info.name} visa application${info.docs === "full" ? ` (${applicantLabel})` : ""}.`,
    "",
    `Ready (${ready.length}/${docs.length}):`,
    ...(ready.length ? ready.map((d) => `✅ ${d.text}`) : ["—"]),
    "",
    "Still needed:",
    ...(missing.length ? missing.map((d) => `⬜ ${d.text}`) : ["Nothing — all set!"]),
    "",
    "Could you help me with the next steps?",
  ].join("\n");

  const resetCountry = () =>
    setChecked((c) => Object.fromEntries(Object.entries(c).filter(([k]) => !k.startsWith(`${info.id}|`))));

  return (
    <>
      <PageHero
        image={33497885}
        crumbs={[{ label: "Home", to: "/" }, { label: "Visa Services" }]}
        eyebrow="Hassle-free paperwork"
        title="Visa services for Bangladeshi travellers"
        subtitle="Clear document guidance and application support for Thailand, Malaysia, Singapore, China, Bhutan, Nepal, India and Mongolia."
      >
        <div className="flex flex-wrap gap-3 pb-6">
          <button
            type="button"
            onClick={() => scrollToEl(document.getElementById("visa-checker"))}
            className="inline-flex items-center gap-2 rounded-full bg-sunset-500 px-6 py-3.5 text-sm font-bold text-white shadow-xl shadow-sunset-500/30 transition hover:bg-sunset-600"
          >
            <ClipboardList className="h-4 w-4" /> Check my documents
          </button>
          <a
            href={waLink("Hello SAARC Holiday! I need help with a visa application.")}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-full bg-[#25D366] px-6 py-3.5 text-sm font-bold text-white transition hover:bg-[#1ebe5a]"
          >
            <WhatsAppIcon className="h-4 w-4" /> Ask on WhatsApp
          </a>
        </div>
      </PageHero>

      {/* 3-country offer */}
      <section className="py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <div className="relative overflow-hidden rounded-[2.5rem] bg-navy-900 text-white">
              <img src={pexels(15480459, 1600, 800)} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover opacity-25" />
              <div className="absolute inset-0 bg-linear-to-r from-navy-950 via-navy-900/90 to-lagoon-800/60" />
              <div className="relative grid gap-10 p-8 sm:p-12 lg:grid-cols-5">
                <div className="lg:col-span-3">
                  <span className="inline-flex rounded-full bg-sunset-500 px-3 py-1 text-[11px] font-bold uppercase tracking-wider">Limited-time offer</span>
                  <h2 className="mt-4 text-3xl font-extrabold leading-tight sm:text-4xl">Visit 3 countries with one set of documents</h2>
                  <p className="mt-4 max-w-xl text-navy-100">
                    Apply for visa processing for Thailand, Malaysia and Singapore together — the simplest way to plan a Southeast Asia holiday.
                  </p>
                  <div className="mt-6 flex flex-wrap gap-2">
                    {VISA_OFFER.countries.map((id) => {
                      const d = DESTINATIONS.find((x) => x.id === id);
                      return d ? (
                        <span key={id} className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1.5 text-sm font-semibold ring-1 ring-white/15">
                          <img src={flagUrl(d.flag)} alt="" className="h-4 w-6 rounded-sm object-cover" />
                          {d.name}
                        </span>
                      ) : null;
                    })}
                  </div>
                  <ul className="mt-8 grid gap-2 sm:grid-cols-2">
                    {VISA_OFFER.points.map((p) => (
                      <li key={p} className="flex items-center gap-2 text-sm text-navy-100">
                        <CircleCheck className="h-4 w-4 shrink-0 text-emerald-400" />
                        {p}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="flex flex-col justify-between gap-6 rounded-3xl bg-white/10 p-6 ring-1 ring-white/15 backdrop-blur lg:col-span-2">
                  <div>
                    <p className="text-sm text-navy-200">All three visas processed for</p>
                    <p className="mt-1 text-5xl font-extrabold text-sunset-300">{VISA_OFFER.price}</p>
                  </div>
                  <div className="space-y-2">
                    <button
                      type="button"
                      onClick={() => openEnquiry(OFFERS[0].preset)}
                      className="w-full rounded-full bg-sunset-500 py-3.5 text-sm font-bold text-white shadow-lg shadow-sunset-500/30 transition hover:bg-sunset-600"
                    >
                      Apply for the offer
                    </button>
                    <a
                      href={telLink(CONTACT.phones[0].value)}
                      className="block w-full rounded-full border border-white/25 py-3.5 text-center text-sm font-bold text-white transition hover:bg-white/10"
                    >
                      Call {CONTACT.phones[0].display}
                    </a>
                  </div>
                  <p className="flex gap-2 text-[11px] leading-relaxed text-navy-200">
                    <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                    {VISA_OFFER.notice}
                  </p>
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* Interactive checklist */}
      <section id="visa-checker" className="scroll-mt-24 bg-white py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <SectionHeading
              eyebrow="Interactive checklist"
              title="Are your documents ready?"
              subtitle="Choose a country and your profession, then tick off what you already have. Send the list to us when you're ready."
            />
          </Reveal>

          <div role="tablist" aria-label="Choose a country" className="mt-10 flex gap-2 overflow-x-auto pb-2 lg:flex-wrap lg:justify-center">
            {VISA_COUNTRIES.map((c) => (
              <button
                key={c.id}
                type="button"
                role="tab"
                aria-selected={country === c.id}
                onClick={() => setCountry(c.id)}
                className={cn(
                  "inline-flex shrink-0 items-center gap-2 rounded-full border px-4 py-2.5 text-sm font-bold transition",
                  country === c.id
                    ? "border-navy-900 bg-navy-900 text-white shadow-lg shadow-navy-900/20"
                    : "border-slate-200 bg-white text-slate-600 hover:border-slate-300",
                )}
              >
                <img src={flagUrl(c.flag)} alt="" className="h-4 w-6 rounded-sm object-cover" />
                {c.name}
                {c.inOffer && <span className="h-1.5 w-1.5 rounded-full bg-sunset-400" aria-label="Part of 3-country offer" />}
              </button>
            ))}
          </div>

          <div key={info.id} className="mt-8 grid animate-fade-up gap-6 lg:grid-cols-5">
            <div className="space-y-5 lg:col-span-2">
              <div className="rounded-3xl bg-slate-50 p-6 ring-1 ring-slate-200/70">
                <div className="flex items-center gap-3">
                  <img src={flagUrl(info.flag)} alt="" className="h-8 w-12 rounded-md object-cover shadow" />
                  <div>
                    <p className="text-lg font-extrabold text-navy-900">{info.name}</p>
                    <p className="text-sm font-semibold text-sunset-600">{info.type}</p>
                  </div>
                </div>
                {info.inOffer && (
                  <p className="mt-4 inline-flex items-center gap-1.5 rounded-full bg-sunset-100 px-3 py-1 text-xs font-bold text-sunset-700">
                    <Stamp className="h-3.5 w-3.5" /> Included in the {VISA_OFFER.price} 3-country offer
                  </p>
                )}
                <p className="mt-4 text-sm leading-relaxed text-slate-600">{info.method}</p>
                {info.note && <p className="mt-3 rounded-2xl bg-white p-3 text-xs leading-relaxed text-slate-500 ring-1 ring-slate-200">{info.note}</p>}
              </div>

              {info.docs === "full" && (
                <div className="rounded-3xl bg-white p-6 ring-1 ring-slate-200/70">
                  <p className="text-sm font-bold text-navy-900">I am a…</p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {APPLICANT_TYPES.map((a) => (
                      <button
                        key={a.id}
                        type="button"
                        aria-pressed={applicant === a.id}
                        onClick={() => setApplicant(a.id)}
                        className={cn(
                          "rounded-full border px-3.5 py-1.5 text-xs font-semibold transition",
                          applicant === a.id ? "border-lagoon-500 bg-lagoon-50 text-navy-900" : "border-slate-200 text-slate-600 hover:border-slate-300",
                        )}
                      >
                        {a.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex items-center gap-5 rounded-3xl bg-navy-900 p-6 text-white">
                <div className="relative shrink-0">
                  <svg viewBox="0 0 80 80" className="h-24 w-24 -rotate-90" aria-hidden>
                    <circle cx="40" cy="40" r={R} fill="none" stroke="currentColor" strokeWidth="8" className="text-white/10" />
                    <circle
                      cx="40"
                      cy="40"
                      r={R}
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="8"
                      strokeLinecap="round"
                      strokeDasharray={CIRC}
                      strokeDashoffset={CIRC * (1 - pct / 100)}
                      className={cn("transition-[stroke-dashoffset] duration-500", pct === 100 ? "text-emerald-400" : "text-sunset-400")}
                    />
                  </svg>
                  <span className="absolute inset-0 grid place-items-center text-xl font-extrabold">{pct}%</span>
                </div>
                <div>
                  <p className="font-bold">
                    {ready.length} of {docs.length} documents ready
                  </p>
                  <p className="mt-1 text-sm text-navy-200">
                    {pct === 100 ? "Great — you're ready to apply! Send us your list." : "Tick off each document as you collect it."}
                  </p>
                </div>
              </div>

              <div className="grid gap-2 sm:grid-cols-2">
                <a
                  href={waLink(waText)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 rounded-full bg-[#25D366] px-4 py-3 text-sm font-bold text-white transition hover:bg-[#1ebe5a]"
                >
                  <WhatsAppIcon className="h-4 w-4" /> Send list on WhatsApp
                </a>
                <button
                  type="button"
                  onClick={() =>
                    openEnquiry({
                      mode: "plan",
                      service: "visa",
                      destinations: DESTINATIONS.some((d) => d.id === info.id) ? [info.id] : [],
                      message: `I need help with a ${info.name} visa${info.docs === "full" ? ` (${applicantLabel})` : ""}. Documents still needed: ${
                        missing.map((d) => d.text).join("; ") || "none"
                      }.`,
                    })
                  }
                  className="flex items-center justify-center gap-2 rounded-full bg-sunset-500 px-4 py-3 text-sm font-bold text-white transition hover:bg-sunset-600"
                >
                  <Send className="h-4 w-4" /> Ask our visa desk
                </button>
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="flex items-center justify-center gap-2 rounded-full border border-slate-200 px-4 py-3 text-sm font-bold text-navy-900 transition hover:border-navy-900"
                >
                  <Printer className="h-4 w-4" /> Print checklist
                </button>
                <button
                  type="button"
                  onClick={resetCountry}
                  className="flex items-center justify-center gap-2 rounded-full border border-slate-200 px-4 py-3 text-sm font-bold text-navy-900 transition hover:border-rose-300 hover:text-rose-600"
                >
                  <RotateCcw className="h-4 w-4" /> Reset
                </button>
              </div>
            </div>

            <div className="lg:col-span-3">
              <ul className="space-y-2.5">
                {docs.map((d) => {
                  const on = !!checked[key(d.text)];
                  return (
                    <li key={d.text}>
                      <button
                        type="button"
                        role="checkbox"
                        aria-checked={on}
                        onClick={() => setChecked((c) => ({ ...c, [key(d.text)]: !c[key(d.text)] }))}
                        className={cn(
                          "flex w-full items-center gap-3 rounded-2xl border px-4 py-3.5 text-left text-sm transition active:scale-[0.99]",
                          on ? "border-emerald-200 bg-emerald-50/70 text-navy-900" : "border-slate-200 bg-white text-slate-700 hover:border-slate-300",
                        )}
                      >
                        <span
                          className={cn(
                            "grid h-6 w-6 shrink-0 place-items-center rounded-lg border-2 transition",
                            on ? "border-emerald-500 bg-emerald-500 text-white" : "border-slate-300 bg-white",
                          )}
                        >
                          {on && <Check className="h-4 w-4 animate-pop" strokeWidth={3} />}
                        </span>
                        <span className={cn("font-medium", on && "text-slate-500 line-through decoration-emerald-500/50")}>{d.text}</span>
                        {d.tag && (
                          <span className="ml-auto shrink-0 rounded-full bg-slate-100 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-slate-500">
                            {d.tag}
                          </span>
                        )}
                      </button>
                    </li>
                  );
                })}
              </ul>
              <p className="mt-4 flex gap-2 text-xs leading-relaxed text-slate-400">
                <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                This checklist is a general guide. Embassy requirements change from time to time — our visa desk will confirm the latest list for your application.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <SectionHeading eyebrow="How we help" title="From documents to decision" />
          </Reveal>
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {STEPS.map(({ icon: I, title, text }, i) => (
              <Reveal key={title} delay={i * 80} className="h-full">
                <div className="relative h-full rounded-3xl bg-white p-6 ring-1 ring-slate-200/70">
                  <span className="absolute right-5 top-5 text-4xl font-extrabold text-slate-100">0{i + 1}</span>
                  <span className="grid h-12 w-12 place-items-center rounded-2xl bg-lagoon-50 text-lagoon-600">
                    <I className="h-6 w-6" />
                  </span>
                  <p className="mt-5 font-bold text-navy-900">{title}</p>
                  <p className="mt-1.5 text-sm leading-relaxed text-slate-500">{text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="bg-white py-16 sm:py-20">
        <div className="mx-auto grid max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-3 lg:px-8">
          <div className="lg:col-span-2">
            <SectionHeading align="left" eyebrow="Visa FAQ" title="Common visa questions" />
            <div className="mt-8">
              <Accordion items={VISA_FAQS} />
            </div>
          </div>
          <aside className="h-fit rounded-3xl bg-navy-900 p-7 text-white lg:sticky lg:top-24">
            <Stamp className="h-9 w-9 text-sunset-400" />
            <p className="mt-4 text-xl font-bold">Talk to our visa desk</p>
            <p className="mt-2 text-sm text-navy-200">Send us photos of your documents on WhatsApp or visit our office in West Agargaon.</p>
            <div className="mt-6 space-y-2">
              {CONTACT.phones.map((p) => (
                <a key={p.value} href={telLink(p.value)} className="block rounded-2xl bg-white/10 px-4 py-3 text-sm font-bold transition hover:bg-white/20">
                  {p.display}
                </a>
              ))}
            </div>
          </aside>
        </div>
      </section>

      <div className="pt-16 sm:pt-20">
        <CTABanner
          image={18662417}
          eyebrow="Visa + holiday"
          title="Turn your visa into a full holiday"
          text="Pair our 3-country visa offer with the Southeast Asia Trio tour — hotels, transfers and sightseeing all arranged."
          preset={{ mode: "plan", service: "tour", destinations: ["singapore", "malaysia", "thailand"] }}
          button="Plan my Southeast Asia trip"
        />
      </div>
    </>
  );
}
