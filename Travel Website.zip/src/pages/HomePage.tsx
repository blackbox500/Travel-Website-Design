import { useRef, useState, type ComponentType } from "react";
import {
  ArrowRight,
  ArrowUpRight,
  BadgeCheck,
  BedDouble,
  ChevronLeft,
  ChevronRight,
  CircleCheck,
  ClipboardList,
  Compass,
  HeartHandshake,
  MessageCircle,
  Palmtree,
  PlaneTakeoff,
  Quote,
  ShieldCheck,
  Sparkles,
  Stamp,
  Star,
  Users,
  Wallet,
} from "lucide-react";
import { DESTINATIONS, OFFERS, SETTINGS } from "@/config";
import { DESTINATION_INFO, getDestination, REGIONS, type Region } from "@/data/destinations";
import { TOURS } from "@/data/tours";
import { POSTS } from "@/data/blog";
import { TESTIMONIALS } from "@/data/testimonials";
import { VISA_OFFER } from "@/data/visa";
import { openEnquiry, type EnquiryPreset } from "@/lib/enquiryBus";
import { Link, useTitle } from "@/lib/router";
import { flagUrl, pexels } from "@/lib/utils";
import { cn } from "@/utils/cn";
import { HomeHero, SearchWidget } from "@/components/home/HomeHero";
import { TourCard } from "@/components/cards/TourCard";
import { DestinationCard } from "@/components/cards/DestinationCard";
import { BlogCard } from "@/components/cards/BlogCard";
import { CTABanner } from "@/components/CTABanner";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/primitives";
import { CountUp } from "@/components/ui/CountUp";

type Icon = ComponentType<{ className?: string }>;

const TRUST: { icon: Icon; title: string; text: string }[] = [
  { icon: BadgeCheck, title: "TOAB member", text: "Registered with the Tour Operators Association of Bangladesh" },
  { icon: Stamp, title: "Visa experts", text: "Document guidance & processing for popular destinations" },
  { icon: Wallet, title: "Easy payments", text: "bKash, Nagad, Rocket, Visa card & Bangla QR" },
  { icon: HeartHandshake, title: "Personalised trips", text: "Every itinerary tailored to your budget & style" },
];

function TrustStrip() {
  return (
    <section className="mx-auto max-w-7xl px-4 pt-14 sm:px-6 lg:px-8">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {TRUST.map(({ icon: I, title, text }, i) => (
          <Reveal key={title} delay={i * 70} className="h-full">
            <div className="flex h-full items-start gap-4 rounded-2xl bg-white p-5 ring-1 ring-slate-200/70 transition hover:shadow-lg hover:shadow-navy-900/5">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-sunset-100 text-sunset-600">
                <I className="h-5 w-5" />
              </span>
              <div>
                <p className="font-bold text-navy-900">{title}</p>
                <p className="mt-0.5 text-sm leading-snug text-slate-500">{text}</p>
              </div>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

function FeaturedDestinations() {
  const order = ["bhutan", "nepal", "thailand", "singapore", "malaysia", "india", "china", "mongolia"];
  const list = order.map((id) => getDestination(id)).filter((d): d is NonNullable<typeof d> => !!d);
  return (
    <section className="py-20 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col items-start justify-between gap-6 lg:flex-row lg:items-end">
          <Reveal>
            <SectionHeading
              align="left"
              eyebrow="Top destinations"
              title="Where will you go next?"
              subtitle="From the monasteries of the Himalaya to the islands of Southeast Asia — explore our most-loved destinations."
            />
          </Reveal>
          <Link
            to="/destinations"
            className="inline-flex shrink-0 items-center gap-2 rounded-full border border-slate-200 bg-white px-5 py-2.5 text-sm font-bold text-navy-900 transition hover:border-navy-900"
          >
            All destinations <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <div className="mt-12 grid auto-rows-[200px] grid-cols-2 gap-4 sm:auto-rows-[240px] lg:grid-cols-4">
          {list.map((d, i) => (
            <Reveal key={d.id} delay={(i % 4) * 60} className={cn("h-full", i === 0 && "col-span-2 row-span-2")}>
              <DestinationCard d={d} large={i === 0} className="h-full" />
            </Reveal>
          ))}
          <Reveal delay={180} className="h-full">
            <Link
              to="/destinations"
              className="group flex h-full flex-col justify-between rounded-3xl bg-linear-to-br from-sunset-500 to-sunset-600 p-6 text-white shadow-lg shadow-sunset-500/20"
            >
              <Compass className="h-9 w-9 transition duration-500 group-hover:rotate-90" />
              <div>
                <p className="text-xl font-extrabold leading-tight">Not sure where to go?</p>
                <p className="mt-1 flex items-center gap-1 text-sm font-semibold text-white/90">
                  Try our destination finder <ArrowUpRight className="h-4 w-4" />
                </p>
              </div>
            </Link>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function PopularTours() {
  const [region, setRegion] = useState<"All" | Region>("All");
  const tabs: ("All" | Region)[] = ["All", ...REGIONS];
  const list = TOURS.filter((t) => region === "All" || t.destinations.some((d) => getDestination(d)?.region === region))
    .sort((a, b) => Number(!!b.featured) - Number(!!a.featured))
    .slice(0, 6);

  return (
    <section className="bg-white py-20 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col items-start justify-between gap-6 lg:flex-row lg:items-end">
          <Reveal>
            <SectionHeading
              align="left"
              eyebrow="Popular packages"
              title="Hand-picked tours for every traveller"
              subtitle="Private tours with hotels, transport and sightseeing — fully customisable to your dates and budget."
            />
          </Reveal>
          <div role="tablist" aria-label="Filter tours by region" className="flex flex-wrap gap-2">
            {tabs.map((t) => (
              <button
                key={t}
                type="button"
                role="tab"
                aria-selected={region === t}
                onClick={() => setRegion(t)}
                className={cn(
                  "rounded-full px-4 py-2 text-sm font-semibold transition",
                  region === t ? "bg-navy-900 text-white shadow-md shadow-navy-900/20" : "bg-slate-100 text-slate-600 hover:bg-slate-200",
                )}
              >
                {t}
              </button>
            ))}
          </div>
        </div>
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((t, i) => (
            <Reveal key={t.slug} delay={(i % 3) * 80} className="h-full">
              <TourCard tour={t} className="h-full" />
            </Reveal>
          ))}
        </div>
        <div className="mt-12 text-center">
          <Link
            to="/tours"
            className="group inline-flex items-center gap-2 rounded-full bg-navy-900 px-7 py-3.5 text-sm font-bold text-white shadow-lg shadow-navy-900/20 transition hover:-translate-y-0.5 hover:bg-navy-800"
          >
            View all {TOURS.length} tour packages <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
          </Link>
        </div>
      </div>
    </section>
  );
}

function OffersSection() {
  const [visa, bhutan] = OFFERS;
  return (
    <section className="py-20 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal>
          <SectionHeading
            eyebrow="Special offers"
            title="Deals you don't want to miss"
            subtitle="Limited-time offers from SAARC Holiday — ask us for details and availability."
          />
        </Reveal>
        <div className="mt-12 grid gap-6 lg:grid-cols-5">
          <Reveal className="h-full lg:col-span-3">
            <div className="relative h-full overflow-hidden rounded-[2rem] bg-navy-900 p-8 text-white sm:p-10">
              <img src={pexels(18662417, 1200, 800)} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover opacity-30" />
              <div className="absolute inset-0 bg-linear-to-br from-navy-950 via-navy-900/90 to-lagoon-700/60" />
              <div className="relative">
                <span className="inline-flex rounded-full bg-sunset-500 px-3 py-1 text-[11px] font-bold uppercase tracking-wider">{visa.badge}</span>
                <h3 className="mt-4 text-3xl font-extrabold leading-tight sm:text-4xl">
                  3 countries.
                  <br />
                  One set of documents.
                </h3>
                <div className="mt-6 flex flex-wrap gap-2">
                  {VISA_OFFER.countries.map((id) => {
                    const d = DESTINATIONS.find((x) => x.id === id);
                    if (!d) return null;
                    return (
                      <span key={id} className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1.5 text-sm font-semibold ring-1 ring-white/15">
                        <img src={flagUrl(d.flag)} alt="" className="h-4 w-6 rounded-sm object-cover" />
                        {d.name}
                      </span>
                    );
                  })}
                </div>
                <div className="mt-8 flex flex-wrap items-end justify-between gap-6">
                  <div>
                    <p className="text-sm text-navy-200">Visa processing for all three</p>
                    <p className="text-4xl font-extrabold text-sunset-300 sm:text-5xl">{VISA_OFFER.price}</p>
                  </div>
                  <div className="flex flex-wrap gap-3">
                    <button
                      type="button"
                      onClick={() => openEnquiry(visa.preset)}
                      className="rounded-full bg-sunset-500 px-5 py-3 text-sm font-bold text-white shadow-lg shadow-sunset-500/30 transition hover:bg-sunset-600"
                    >
                      Ask about this offer
                    </button>
                    <Link
                      to="/visa?country=thailand"
                      className="rounded-full border border-white/25 bg-white/10 px-5 py-3 text-sm font-bold text-white transition hover:bg-white/20"
                    >
                      Check documents
                    </Link>
                  </div>
                </div>
                <ul className="mt-8 grid gap-2 sm:grid-cols-2">
                  {VISA_OFFER.points.map((p) => (
                    <li key={p} className="flex items-center gap-2 text-sm text-navy-100">
                      <CircleCheck className="h-4 w-4 shrink-0 text-emerald-400" />
                      {p}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </Reveal>

          <Reveal className="h-full lg:col-span-2" delay={120}>
            <div className="group relative flex h-full min-h-[440px] flex-col justify-end overflow-hidden rounded-[2rem] p-8 text-white">
              <img
                src={pexels(37747857, 900, 1000)}
                alt=""
                loading="lazy"
                className="absolute inset-0 h-full w-full object-cover transition duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-linear-to-t from-navy-950 via-navy-950/60 to-transparent" />
              <div className="relative">
                <span className="inline-flex rounded-full bg-sunset-500 px-3 py-1 text-[11px] font-bold uppercase tracking-wider">{bhutan.badge}</span>
                <h3 className="mt-3 text-2xl font-extrabold">{bhutan.title}</h3>
                <p className="mt-2 text-sm text-navy-100">Free Wi-Fi · Room service · Restaurant &amp; bar · Free parking</p>
                <div className="mt-5 grid grid-cols-3 gap-2 text-center">
                  {[
                    ["Breakfast", "Nu. 250"],
                    ["Lunch", "Nu. 450"],
                    ["Dinner", "Nu. 450"],
                  ].map(([meal, price]) => (
                    <div key={meal} className="rounded-2xl bg-white/10 px-2 py-3 ring-1 ring-white/15 backdrop-blur">
                      <p className="text-[10px] font-semibold uppercase tracking-wider text-navy-200">{meal}</p>
                      <p className="mt-0.5 font-bold">{price}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-6 flex flex-wrap items-center gap-4">
                  <button
                    type="button"
                    onClick={() => openEnquiry(bhutan.preset)}
                    className="rounded-full bg-white px-5 py-3 text-sm font-bold text-navy-900 transition hover:bg-sunset-100"
                  >
                    Check availability
                  </button>
                  <Link to={bhutan.link} className="inline-flex items-center gap-1 text-sm font-semibold text-white/90 hover:text-white">
                    Read offer <ArrowRight className="h-4 w-4" />
                  </Link>
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

const SERVICE_CARDS: { icon: Icon; title: string; text: string; cta: string; to?: string; preset?: EnquiryPreset }[] = [
  { icon: Palmtree, title: "Tour Packages", text: "Hand-crafted holidays with hotels, transport, guides and sightseeing.", cta: "Browse tours", to: "/tours" },
  { icon: Stamp, title: "Visa Processing", text: "Document guidance and application support — including our 3-country offer.", cta: "Visa services", to: "/visa" },
  { icon: BedDouble, title: "Hotel Booking", text: "Handpicked stays at special rates, from budget to luxury.", cta: "Request hotels", preset: { mode: "plan", service: "hotel" } },
  { icon: PlaneTakeoff, title: "Air Tickets", text: "Domestic and international flights at competitive fares.", cta: "Get a fare", preset: { mode: "plan", service: "air" } },
  { icon: Users, title: "Group & Corporate", text: "Family reunions, office trips, study tours and incentive groups.", cta: "Plan a group trip", preset: { mode: "plan", service: "group" } },
  { icon: Compass, title: "Custom Trips", text: "Tell us your dream — we'll design a one-of-a-kind itinerary.", cta: "Start planning", preset: { mode: "plan" } },
];

function ServicesSection() {
  const cls =
    "group flex h-full w-full flex-col rounded-3xl border border-slate-200/70 bg-slate-50/60 p-7 text-left transition duration-300 hover:-translate-y-1 hover:border-transparent hover:bg-navy-900 hover:shadow-2xl hover:shadow-navy-900/20";
  return (
    <section className="bg-white py-20 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal>
          <SectionHeading
            eyebrow="What we do"
            title="Everything you need for a perfect trip"
            subtitle="One trusted team for tours, visas, hotels and flights — so you can relax and enjoy the journey."
          />
        </Reveal>
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICE_CARDS.map((s, i) => {
            const inner = (
              <>
                <span className="grid h-14 w-14 place-items-center rounded-2xl bg-sunset-100 text-sunset-600 transition duration-300 group-hover:bg-sunset-500 group-hover:text-white">
                  <s.icon className="h-6 w-6" />
                </span>
                <h3 className="mt-6 text-xl font-bold text-navy-900 transition group-hover:text-white">{s.title}</h3>
                <p className="mt-2 flex-1 text-sm leading-relaxed text-slate-500 transition group-hover:text-navy-200">{s.text}</p>
                <span className="mt-6 inline-flex items-center gap-1.5 text-sm font-bold text-sunset-600 transition group-hover:text-sunset-300">
                  {s.cta} <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
                </span>
              </>
            );
            return (
              <Reveal key={s.title} delay={(i % 3) * 70} className="h-full">
                {s.to ? (
                  <Link to={s.to} className={cls}>
                    {inner}
                  </Link>
                ) : (
                  <button type="button" onClick={() => openEnquiry(s.preset)} className={cls}>
                    {inner}
                  </button>
                )}
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}

const STEPS: { icon: Icon; title: string; text: string }[] = [
  { icon: ClipboardList, title: "Tell us your plan", text: "Share your destination, dates, travellers and budget — online, by phone or on WhatsApp." },
  { icon: Compass, title: "Get your itinerary", text: "We design a personalised plan with hotels, transport and a clear quote." },
  { icon: Wallet, title: "Confirm & pay easily", text: "Pay securely with bKash, Nagad, Rocket, Visa card or Bangla QR." },
  { icon: PlaneTakeoff, title: "Travel with confidence", text: "We handle the details and stay in touch throughout your journey." },
];

function HowItWorks() {
  return (
    <section className="py-20 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal>
          <SectionHeading eyebrow="How it works" title="Your trip in four easy steps" />
        </Reveal>
        <ol className="relative mt-14 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          <span aria-hidden className="absolute left-[12%] right-[12%] top-8 hidden border-t-2 border-dashed border-slate-200 lg:block" />
          {STEPS.map(({ icon: I, title, text }, i) => (
            <Reveal key={title} delay={i * 100}>
              <li className="relative text-center">
                <span className="relative mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-navy-900 text-white shadow-xl shadow-navy-900/20">
                  <I className="h-7 w-7" />
                  <span className="absolute -right-2 -top-2 grid h-7 w-7 place-items-center rounded-full bg-sunset-500 text-xs font-bold ring-4 ring-slate-50">
                    {i + 1}
                  </span>
                </span>
                <h3 className="mt-6 text-lg font-bold text-navy-900">{title}</h3>
                <p className="mx-auto mt-2 max-w-xs text-sm leading-relaxed text-slate-500">{text}</p>
              </li>
            </Reveal>
          ))}
        </ol>
      </div>
    </section>
  );
}

const REASONS: { icon: Icon; title: string; text: string }[] = [
  { icon: BadgeCheck, title: "Registered & trusted", text: "A member of the Tour Operators Association of Bangladesh (TOAB)." },
  { icon: Sparkles, title: "Tailor-made itineraries", text: "Every trip is designed around your dates, budget and travel style." },
  { icon: Stamp, title: "Visa know-how", text: "Clear document guidance for Thailand, Malaysia, Singapore, Bhutan, China and more." },
  { icon: Wallet, title: "Transparent pricing", text: "Clear quotes that show what's included — and flexible ways to pay." },
  { icon: MessageCircle, title: "Always reachable", text: "Talk to us by phone, WhatsApp or email, or visit our Dhaka office." },
  { icon: ShieldCheck, title: "Peace of mind", text: "Support from the moment you enquire until you're back home." },
];

function WhyUs() {
  const stats = [
    { value: `${DESTINATION_INFO.length}`, label: "Destinations" },
    { value: `${TOURS.length}+`, label: "Tour packages" },
    { value: "3-in-1", label: "Visa offer" },
    { value: "TOAB", label: "Member agency" },
  ];
  return (
    <section className="overflow-hidden bg-white py-20 sm:py-24">
      <div className="mx-auto grid max-w-7xl items-center gap-14 px-4 sm:px-6 lg:grid-cols-2 lg:px-8">
        <Reveal>
          <div className="relative mx-auto grid max-w-lg grid-cols-2 gap-4">
            <img src={pexels(7658255, 500, 650)} alt="Travel consultants planning a trip" loading="lazy" className="h-72 w-full rounded-3xl object-cover sm:h-80" />
            <img src={pexels(4173221, 500, 650)} alt="Happy family travelling" loading="lazy" className="mt-12 h-72 w-full rounded-3xl object-cover sm:h-80" />
            <img src={pexels(37747857, 1000, 500)} alt="Punakha Dzong, Bhutan" loading="lazy" className="col-span-2 h-44 w-full rounded-3xl object-cover" />
            <div className="absolute -left-2 top-1/2 flex -translate-y-1/2 animate-float items-center gap-3 rounded-2xl bg-white p-4 shadow-2xl shadow-navy-900/15 sm:-left-8">
              <span className="grid h-11 w-11 place-items-center rounded-xl bg-emerald-50 text-emerald-600">
                <BadgeCheck className="h-6 w-6" />
              </span>
              <div>
                <p className="text-sm font-bold text-navy-900">Member of TOAB</p>
                <p className="text-xs text-slate-500">Trusted travel partner</p>
              </div>
            </div>
          </div>
        </Reveal>
        <div>
          <Reveal>
            <SectionHeading
              align="left"
              eyebrow="Why SAARC Holiday"
              title="Travel more, worry less"
              subtitle="We believe travel is about discovering new cultures, creating meaningful experiences and making memories that last a lifetime."
            />
          </Reveal>
          <div className="mt-8 grid gap-5 sm:grid-cols-2">
            {REASONS.map(({ icon: I, title, text }, i) => (
              <Reveal key={title} delay={(i % 2) * 80}>
                <div className="flex gap-3">
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-lagoon-50 text-lagoon-600">
                    <I className="h-5 w-5" />
                  </span>
                  <div>
                    <p className="font-bold text-navy-900">{title}</p>
                    <p className="mt-0.5 text-sm leading-relaxed text-slate-500">{text}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
          <Reveal className="mt-10">
            <dl className="grid grid-cols-2 gap-4 rounded-3xl bg-navy-900 p-6 text-white sm:grid-cols-4">
              {stats.map((s) => (
                <div key={s.label} className="text-center">
                  <dt className="sr-only">{s.label}</dt>
                  <dd className="text-3xl font-extrabold text-sunset-300">
                    <CountUp value={s.value} />
                  </dd>
                  <p className="mt-1 text-xs font-medium text-navy-200">{s.label}</p>
                </div>
              ))}
            </dl>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function Testimonials() {
  const ref = useRef<HTMLDivElement>(null);
  const scroll = (dir: 1 | -1) => {
    const el = ref.current;
    if (el) el.scrollBy({ left: dir * el.clientWidth * 0.8, behavior: "smooth" });
  };
  return (
    <section className="py-20 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-end">
          <Reveal>
            <SectionHeading align="left" eyebrow="Traveller stories" title="What our travellers say" />
          </Reveal>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => scroll(-1)}
              aria-label="Previous reviews"
              className="grid h-11 w-11 place-items-center rounded-full border border-slate-200 bg-white text-navy-900 transition hover:bg-navy-900 hover:text-white"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={() => scroll(1)}
              aria-label="More reviews"
              className="grid h-11 w-11 place-items-center rounded-full border border-slate-200 bg-white text-navy-900 transition hover:bg-navy-900 hover:text-white"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>
        </div>
        <div ref={ref} className="mt-10 flex snap-x snap-mandatory gap-5 overflow-x-auto pb-4 [scrollbar-width:none]">
          {TESTIMONIALS.map((t) => (
            <figure
              key={t.name}
              className="flex w-[85%] shrink-0 snap-start flex-col rounded-3xl bg-white p-7 shadow-lg shadow-navy-900/5 ring-1 ring-slate-200/70 sm:w-[calc(50%-10px)] lg:w-[calc(33.333%-14px)]"
            >
              <div className="flex items-center justify-between">
                <div className="flex gap-0.5" aria-label={`${t.rating} out of 5 stars`}>
                  {Array.from({ length: 5 }, (_, i) => (
                    <Star key={i} className={cn("h-4 w-4", i < t.rating ? "fill-amber-400 text-amber-400" : "text-slate-200")} />
                  ))}
                </div>
                <Quote className="h-8 w-8 text-sunset-200" />
              </div>
              <blockquote className="mt-4 flex-1 text-[15px] leading-relaxed text-slate-600">“{t.text}”</blockquote>
              <figcaption className="mt-6 flex items-center gap-3 border-t border-slate-100 pt-5">
                <span className="grid h-11 w-11 place-items-center rounded-full bg-linear-to-br from-navy-800 to-lagoon-600 text-sm font-bold text-white">
                  {t.name
                    .split(/\s+/)
                    .map((w) => w[0])
                    .join("")
                    .slice(0, 2)}
                </span>
                <div>
                  <p className="font-bold text-navy-900">{t.name}</p>
                  <p className="text-xs text-slate-500">
                    {t.trip} · {t.location}
                  </p>
                </div>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}

function LatestPosts() {
  return (
    <section className="bg-white py-20 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-end">
          <Reveal>
            <SectionHeading align="left" eyebrow="Travel blog" title="Guides, tips & travel news" />
          </Reveal>
          <Link
            to="/blog"
            className="inline-flex shrink-0 items-center gap-2 rounded-full border border-slate-200 px-5 py-2.5 text-sm font-bold text-navy-900 transition hover:border-navy-900"
          >
            All articles <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {POSTS.slice(0, 3).map((p, i) => (
            <Reveal key={p.slug} delay={i * 80} className="h-full">
              <BlogCard post={p} className="h-full" />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function GalleryMarquee() {
  const items = DESTINATION_INFO.flatMap((d) => d.highlights.slice(0, 2).map((h) => ({ image: h.image, caption: h.title })));
  return (
    <section className="overflow-hidden py-20">
      <div className="mx-auto mb-10 flex max-w-7xl items-end justify-between gap-6 px-4 sm:px-6 lg:px-8">
        <Reveal>
          <SectionHeading align="left" eyebrow="Gallery" title="Moments from our destinations" />
        </Reveal>
        <Link
          to="/gallery"
          className="hidden shrink-0 items-center gap-2 rounded-full border border-slate-200 bg-white px-5 py-2.5 text-sm font-bold text-navy-900 transition hover:border-navy-900 sm:inline-flex"
        >
          View gallery <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
      <div className="flex w-max animate-marquee gap-4 hover:[animation-play-state:paused]">
        {[...items, ...items].map((it, i) => {
          const clone = i >= items.length;
          return (
            <Link
              key={`${it.image}-${i}`}
              to="/gallery"
              aria-hidden={clone || undefined}
              tabIndex={clone ? -1 : undefined}
              className="group relative h-56 w-80 shrink-0 overflow-hidden rounded-3xl"
            >
              <img
                src={pexels(it.image, 640, 448)}
                alt={clone ? "" : it.caption}
                loading="lazy"
                className="h-full w-full object-cover transition duration-700 group-hover:scale-110"
              />
              <span className="absolute inset-x-0 bottom-0 bg-linear-to-t from-navy-950/80 to-transparent p-4 text-sm font-semibold text-white">
                {it.caption}
              </span>
            </Link>
          );
        })}
      </div>
    </section>
  );
}

export function HomePage() {
  useTitle();
  return (
    <>
      <HomeHero />
      <SearchWidget />
      <TrustStrip />
      <FeaturedDestinations />
      <PopularTours />
      <OffersSection />
      <ServicesSection />
      <HowItWorks />
      <WhyUs />
      {SETTINGS.showTestimonials && <Testimonials />}
      <LatestPosts />
      <GalleryMarquee />
      <CTABanner />
    </>
  );
}
