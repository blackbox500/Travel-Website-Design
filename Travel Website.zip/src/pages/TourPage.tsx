import { useCallback, useState } from "react";
import {
  CalendarDays,
  Check,
  ChevronDown,
  Clock,
  Images,
  Info,
  MapPin,
  Phone,
  Printer,
  Share2,
  Sparkles,
  Users,
  X,
} from "lucide-react";
import { CONTACT, DESTINATIONS, SETTINGS } from "@/config";
import { getTour, TOUR_FAQS, TOURS, type Tour } from "@/data/tours";
import { openEnquiry } from "@/lib/enquiryBus";
import { Link, useTitle } from "@/lib/router";
import { copyText, flagUrl, formatBDT, formatDate, pexels, telLink, todayISO, waLink } from "@/lib/utils";
import { cn } from "@/utils/cn";
import { Stepper, TextField } from "@/components/enquiry/fields";
import { Accordion } from "@/components/ui/Accordion";
import { Breadcrumbs } from "@/components/ui/PageHero";
import { Lightbox } from "@/components/ui/Lightbox";
import { Reveal } from "@/components/ui/Reveal";
import { useToast } from "@/components/ui/Toast";
import { WhatsAppIcon } from "@/components/ui/BrandIcons";
import { TourCard, WishlistButton } from "@/components/cards/TourCard";
import { CTABanner } from "@/components/CTABanner";
import { NotFoundPage } from "./NotFoundPage";

interface BookingState {
  date: string;
  adults: number;
  kids: number;
}

function BookingCard({
  tour,
  state,
  setState,
  idPrefix,
}: {
  tour: Tour;
  state: BookingState;
  setState: (s: BookingState) => void;
  idPrefix: string;
}) {
  const childPrice = Math.round((tour.price * SETTINGS.childPriceRatio) / 100) * 100;
  const total = state.adults * tour.price + state.kids * childPrice;
  const people = `${state.adults} adult${state.adults > 1 ? "s" : ""}${
    state.kids ? ` and ${state.kids} child${state.kids > 1 ? "ren" : ""}` : ""
  }`;
  const message = `I'd like to book "${tour.title}" (${tour.nights}N/${tour.nights + 1}D)${
    state.date ? ` from ${formatDate(state.date)}` : ""
  } for ${people}.${SETTINGS.showPrices ? ` Estimated total: ${formatBDT(total)}.` : ""}`;

  return (
    <div className="overflow-hidden rounded-[1.75rem] bg-white shadow-2xl shadow-navy-900/10 ring-1 ring-slate-200/70">
      <div className="relative overflow-hidden bg-navy-900 p-6 text-white">
        <div className="pointer-events-none absolute -right-10 -top-10 h-36 w-36 rounded-full bg-sunset-500/25 blur-2xl" />
        {SETTINGS.showPrices ? (
          <div className="relative">
            <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-navy-200">
              From {tour.oldPrice && <span className="ml-1 normal-case tracking-normal line-through">{formatBDT(tour.oldPrice)}</span>}
            </p>
            <p className="mt-1 text-3xl font-extrabold">
              {formatBDT(tour.price)} <span className="text-sm font-medium text-navy-200">/ person</span>
            </p>
            <p className="mt-1 text-xs text-navy-200">Twin sharing · land package</p>
          </div>
        ) : (
          <p className="relative text-2xl font-extrabold">Price on request</p>
        )}
      </div>
      <div className="space-y-4 p-6">
        <TextField
          id={`${idPrefix}-date`}
          type="date"
          label="Preferred travel date"
          icon={CalendarDays}
          optional
          min={todayISO()}
          value={state.date}
          onChange={(v) => setState({ ...state, date: v })}
        />
        <Stepper label="Adults" hint="12+ years" value={state.adults} min={1} max={30} onChange={(v) => setState({ ...state, adults: v })} />
        <Stepper label="Children" hint="2–11 years" value={state.kids} min={0} max={20} onChange={(v) => setState({ ...state, kids: v })} />

        {SETTINGS.showPrices && (
          <div className="space-y-2 rounded-2xl bg-slate-50 p-4 text-sm">
            <div className="flex justify-between text-slate-500">
              <span>
                {state.adults} × adult ({formatBDT(tour.price)})
              </span>
              <span className="font-semibold text-navy-900">{formatBDT(state.adults * tour.price)}</span>
            </div>
            {state.kids > 0 && (
              <div className="flex justify-between text-slate-500">
                <span>
                  {state.kids} × child ({formatBDT(childPrice)})
                </span>
                <span className="font-semibold text-navy-900">{formatBDT(state.kids * childPrice)}</span>
              </div>
            )}
            <div className="flex items-end justify-between border-t border-slate-200 pt-2">
              <span className="font-bold text-navy-900">Estimated total</span>
              <span key={total} className="animate-pop text-xl font-extrabold text-sunset-600">
                {formatBDT(total)}
              </span>
            </div>
          </div>
        )}

        <button
          type="button"
          onClick={() =>
            openEnquiry({
              mode: "plan",
              service: "tour",
              destinations: tour.destinations,
              departDate: state.date || undefined,
              adults: state.adults,
              children: state.kids,
              message,
            })
          }
          className="w-full rounded-full bg-sunset-500 py-3.5 text-sm font-bold text-white shadow-lg shadow-sunset-500/30 transition hover:-translate-y-0.5 hover:bg-sunset-600"
        >
          Request this tour
        </button>
        <div className="grid grid-cols-2 gap-2">
          <a
            href={waLink(`Hello SAARC Holiday! ${message}`)}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 rounded-full bg-[#25D366] py-3 text-sm font-bold text-white transition hover:bg-[#1ebe5a]"
          >
            <WhatsAppIcon className="h-4 w-4" /> WhatsApp
          </a>
          <a
            href={telLink(CONTACT.phones[0].value)}
            className="flex items-center justify-center gap-2 rounded-full border border-slate-200 py-3 text-sm font-bold text-navy-900 transition hover:border-navy-900"
          >
            <Phone className="h-4 w-4" /> Call us
          </a>
        </div>
        <p className="text-center text-xs leading-relaxed text-slate-400">
          No payment needed to enquire · Pay later via bKash, Nagad, Rocket, card or Bangla QR
        </p>
      </div>
    </div>
  );
}

export function TourPage({ slug }: { slug: string }) {
  const tour = getTour(slug);
  useTitle(tour ? tour.title : "Tour not found", tour?.summary);
  const [lightbox, setLightbox] = useState<number | null>(null);
  const [openDays, setOpenDays] = useState<Set<number>>(() => new Set([0]));
  const [booking, setBooking] = useState<BookingState>({ date: "", adults: 2, kids: 0 });
  const toast = useToast();
  const closeLightbox = useCallback(() => setLightbox(null), []);

  if (!tour) return <NotFoundPage />;

  const dests = DESTINATIONS.filter((d) => tour.destinations.includes(d.id));
  const allOpen = openDays.size === tour.itinerary.length;
  const toggleDay = (i: number) =>
    setOpenDays((s) => {
      const n = new Set(s);
      if (n.has(i)) n.delete(i);
      else n.add(i);
      return n;
    });
  const photos = tour.images.map((image, i) => ({ image, caption: `${tour.title} · photo ${i + 1}` }));
  const related = TOURS.filter((t) => t.slug !== tour.slug)
    .map((t) => ({
      t,
      score: (t.destinations.some((d) => tour.destinations.includes(d)) ? 2 : 0) + t.styles.filter((s) => tour.styles.includes(s)).length * 0.5,
    }))
    .sort((a, b) => b.score - a.score)
    .slice(0, 3)
    .map((x) => x.t);

  const share = async () => {
    const url = window.location.href;
    if ("share" in navigator) {
      try {
        await navigator.share({ title: tour.title, text: tour.summary, url });
      } catch {
        /* cancelled */
      }
      return;
    }
    const ok = await copyText(url);
    toast(ok ? "Link copied to clipboard" : "Couldn't copy the link", ok ? "success" : "error");
  };

  const facts = [
    { icon: Clock, label: "Duration", value: `${tour.nights} nights / ${tour.nights + 1} days` },
    { icon: MapPin, label: "Destinations", value: dests.map((d) => d.name).join(", ") },
    { icon: Users, label: "Tour type", value: "Private · any group size" },
    { icon: Sparkles, label: "Best for", value: tour.styles.slice(0, 2).join(" & ") },
  ];

  return (
    <>
      <section className="bg-white pb-10 pt-8">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Breadcrumbs light={false} items={[{ label: "Home", to: "/" }, { label: "Tours", to: "/tours" }, { label: tour.title }]} />
          <div className="mt-5 flex flex-wrap items-start justify-between gap-4">
            <div className="max-w-3xl">
              <div className="flex flex-wrap items-center gap-2">
                {tour.badge && (
                  <span className="rounded-full bg-sunset-500 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-white">{tour.badge}</span>
                )}
                {dests.map((d) => (
                  <Link
                    key={d.id}
                    to={`/destinations/${d.id}`}
                    className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 py-1 pl-1.5 pr-3 text-xs font-semibold text-slate-600 transition hover:bg-slate-200"
                  >
                    <img src={flagUrl(d.flag)} alt="" className="h-3.5 w-5 rounded-[2px] object-cover" />
                    {d.name}
                  </Link>
                ))}
              </div>
              <h1 className="mt-3 text-3xl font-extrabold tracking-tight text-balance text-navy-900 sm:text-4xl">{tour.title}</h1>
              <p className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-slate-500">
                <span className="inline-flex items-center gap-1.5">
                  <Clock className="h-4 w-4 text-sunset-500" />
                  {tour.nights}N / {tour.nights + 1}D
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <MapPin className="h-4 w-4 text-sunset-500" />
                  {tour.route.join(" → ")}
                </span>
              </p>
            </div>
            <div className="flex gap-2 print:hidden">
              <WishlistButton slug={tour.slug} title={tour.title} className="h-11 w-11 bg-white ring-1 ring-slate-200" />
              <button
                type="button"
                onClick={share}
                aria-label="Share this tour"
                className="grid h-11 w-11 place-items-center rounded-full bg-white text-navy-900 shadow-lg ring-1 ring-slate-200 transition hover:scale-110"
              >
                <Share2 className="h-5 w-5" />
              </button>
              <button
                type="button"
                onClick={() => window.print()}
                aria-label="Print itinerary"
                className="grid h-11 w-11 place-items-center rounded-full bg-white text-navy-900 shadow-lg ring-1 ring-slate-200 transition hover:scale-110"
              >
                <Printer className="h-5 w-5" />
              </button>
            </div>
          </div>

          <div className="mt-6 grid h-[280px] grid-cols-4 grid-rows-2 gap-3 sm:h-[440px]">
            <button
              type="button"
              onClick={() => setLightbox(0)}
              className="group relative col-span-4 row-span-2 overflow-hidden rounded-3xl sm:col-span-2"
            >
              <img
                src={pexels(tour.images[0], 1200, 900)}
                alt={tour.title}
                fetchPriority="high"
                className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
              />
              <span className="absolute bottom-4 left-4 inline-flex items-center gap-2 rounded-full bg-white/95 px-4 py-2 text-sm font-bold text-navy-900 shadow-lg print:hidden">
                <Images className="h-4 w-4" /> View {tour.images.length} photos
              </span>
            </button>
            {tour.images.slice(1, 3).map((img, i) => (
              <button
                key={img}
                type="button"
                onClick={() => setLightbox(i + 1)}
                className="group relative col-span-2 row-span-1 hidden overflow-hidden rounded-3xl sm:block"
              >
                <img src={pexels(img, 800, 450)} alt="" loading="lazy" className="h-full w-full object-cover transition duration-700 group-hover:scale-105" />
                {i === 1 && tour.images.length > 3 && (
                  <span className="absolute inset-0 grid place-items-center bg-navy-950/50 text-lg font-bold text-white">
                    +{tour.images.length - 3} more
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 sm:py-16">
        <div className="mx-auto grid max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-3 lg:px-8">
          <div className="min-w-0 space-y-12 lg:col-span-2">
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {facts.map(({ icon: I, label, value }) => (
                <div key={label} className="rounded-2xl bg-white p-4 ring-1 ring-slate-200/70">
                  <I className="h-5 w-5 text-sunset-500" />
                  <p className="mt-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">{label}</p>
                  <p className="mt-0.5 text-sm font-bold text-navy-900">{value}</p>
                </div>
              ))}
            </div>

            <Reveal>
              <h2 className="text-2xl font-extrabold text-navy-900">Overview</h2>
              <p className="mt-3 text-[17px] leading-8 text-slate-600">{tour.summary}</p>
              <ul className="mt-6 grid gap-3 sm:grid-cols-2">
                {tour.highlights.map((h) => (
                  <li key={h} className="flex items-start gap-3 rounded-2xl bg-white p-4 text-sm font-medium text-navy-900 ring-1 ring-slate-200/70">
                    <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-sunset-100 text-sunset-600">
                      <Check className="h-3.5 w-3.5" strokeWidth={3} />
                    </span>
                    {h}
                  </li>
                ))}
              </ul>
            </Reveal>

            <div className="lg:hidden print:hidden">
              <BookingCard tour={tour} state={booking} setState={setBooking} idPrefix="m" />
            </div>

            <div>
              <div className="flex flex-wrap items-center justify-between gap-3">
                <h2 className="text-2xl font-extrabold text-navy-900">Day-by-day itinerary</h2>
                <button
                  type="button"
                  onClick={() => setOpenDays(allOpen ? new Set() : new Set(tour.itinerary.map((_, i) => i)))}
                  className="rounded-full bg-navy-50 px-4 py-2 text-xs font-bold text-navy-900 transition hover:bg-navy-100 print:hidden"
                >
                  {allOpen ? "Collapse all" : "Expand all"}
                </button>
              </div>
              <ol className="relative mt-6 space-y-4 before:absolute before:bottom-6 before:left-[19px] before:top-6 before:w-0.5 before:bg-slate-200">
                {tour.itinerary.map((day, i) => {
                  const isOpen = openDays.has(i);
                  return (
                    <li key={day.title} className="relative pl-14">
                      <span
                        className={cn(
                          "absolute left-0 top-2 grid h-10 w-10 place-items-center rounded-full text-xs font-bold ring-4 ring-slate-50 transition",
                          isOpen ? "bg-sunset-500 text-white" : "bg-navy-900 text-white",
                        )}
                      >
                        D{i + 1}
                      </span>
                      <div className={cn("rounded-2xl border bg-white transition", isOpen ? "border-lagoon-200 shadow-lg shadow-lagoon-500/5" : "border-slate-200")}>
                        <button
                          type="button"
                          onClick={() => toggleDay(i)}
                          aria-expanded={isOpen}
                          className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left"
                        >
                          <span>
                            <span className="block text-[11px] font-bold uppercase tracking-wider text-sunset-600">Day {i + 1}</span>
                            <span className="font-bold text-navy-900">{day.title}</span>
                          </span>
                          <ChevronDown className={cn("h-5 w-5 shrink-0 text-slate-400 transition", isOpen && "rotate-180")} />
                        </button>
                        <div className={cn("grid transition-[grid-template-rows] duration-300 print:grid-rows-[1fr]", isOpen ? "grid-rows-[1fr]" : "grid-rows-[0fr]")}>
                          <div className="overflow-hidden">
                            <p className="px-5 pb-5 text-sm leading-relaxed text-slate-600">{day.text}</p>
                          </div>
                        </div>
                      </div>
                    </li>
                  );
                })}
              </ol>
            </div>

            <div className="grid gap-6 sm:grid-cols-2">
              <div className="rounded-3xl bg-emerald-50/70 p-6 ring-1 ring-emerald-100">
                <h3 className="text-lg font-bold text-navy-900">What's included</h3>
                <ul className="mt-4 space-y-3">
                  {tour.includes.map((x) => (
                    <li key={x} className="flex items-start gap-2.5 text-sm text-slate-700">
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" strokeWidth={3} />
                      {x}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="rounded-3xl bg-rose-50/70 p-6 ring-1 ring-rose-100">
                <h3 className="text-lg font-bold text-navy-900">Not included</h3>
                <ul className="mt-4 space-y-3">
                  {tour.excludes.map((x) => (
                    <li key={x} className="flex items-start gap-2.5 text-sm text-slate-700">
                      <X className="mt-0.5 h-4 w-4 shrink-0 text-rose-500" strokeWidth={3} />
                      {x}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="flex gap-3 rounded-3xl bg-navy-50 p-6 text-sm leading-relaxed text-slate-600">
              <Info className="mt-0.5 h-5 w-5 shrink-0 text-navy-700" />
              <p>
                <span className="font-bold text-navy-900">Good to know: </span>
                {SETTINGS.priceNote} Itineraries may be adjusted for weather, local events or your preferences.
              </p>
            </div>

            <div className="print:hidden">
              <h2 className="text-2xl font-extrabold text-navy-900">Frequently asked questions</h2>
              <div className="mt-6">
                <Accordion items={TOUR_FAQS} />
              </div>
            </div>
          </div>

          <aside className="hidden lg:block print:hidden">
            <div className="sticky top-24">
              <BookingCard tour={tour} state={booking} setState={setBooking} idPrefix="d" />
            </div>
          </aside>
        </div>
      </section>

      <section className="bg-white py-16 sm:py-20 print:hidden">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-extrabold text-navy-900 sm:text-3xl">You may also like</h2>
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {related.map((t) => (
              <TourCard key={t.slug} tour={t} />
            ))}
          </div>
        </div>
      </section>

      <div className="pt-16 sm:pt-20">
        <CTABanner
          image={tour.images[1] ?? tour.images[0]}
          eyebrow="Make it yours"
          title="Want to tweak this itinerary?"
          text="Every tour is private and fully customisable — add days, upgrade hotels or combine destinations."
          preset={{ mode: "plan", service: "tour", destinations: tour.destinations, message: `I'd like a customised version of "${tour.title}".` }}
          button="Customise this tour"
        />
      </div>

      <Lightbox items={photos} index={lightbox} onClose={closeLightbox} onChange={setLightbox} />
    </>
  );
}
