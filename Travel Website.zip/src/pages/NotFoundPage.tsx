import { ArrowRight, Plane } from "lucide-react";
import { DESTINATIONS } from "@/config";
import { Link, useTitle } from "@/lib/router";
import { flagUrl } from "@/lib/utils";

export function NotFoundPage() {
  useTitle("Page not found");
  return (
    <section className="relative overflow-hidden py-24 sm:py-32">
      <div className="bg-grid absolute inset-0 -z-10 [mask-image:radial-gradient(ellipse_at_center,black,transparent_70%)]" />
      <div className="mx-auto max-w-2xl px-4 text-center">
        <div className="mx-auto grid h-28 w-28 place-items-center rounded-full bg-sunset-100 text-sunset-600">
          <Plane className="h-12 w-12 animate-float" />
        </div>
        <p className="mt-8 font-script text-3xl text-sunset-600">Oops! Wrong turn…</p>
        <h1 className="mt-2 text-4xl font-extrabold tracking-tight text-balance text-navy-900 sm:text-5xl">
          This page took a different flight
        </h1>
        <p className="mt-4 text-slate-500">The page you're looking for doesn't exist or may have moved. Let's get you back on track.</p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link
            to="/"
            className="inline-flex items-center gap-2 rounded-full bg-navy-900 px-6 py-3 text-sm font-bold text-white transition hover:bg-navy-800"
          >
            Back to home <ArrowRight className="h-4 w-4" />
          </Link>
          <Link to="/tours" className="rounded-full bg-sunset-500 px-6 py-3 text-sm font-bold text-white transition hover:bg-sunset-600">
            Browse tours
          </Link>
          <Link to="/contact" className="rounded-full border border-slate-200 bg-white px-6 py-3 text-sm font-bold text-navy-900 transition hover:border-navy-900">
            Contact us
          </Link>
        </div>
        <p className="mt-12 text-xs font-bold uppercase tracking-[0.2em] text-slate-400">Or explore a destination</p>
        <div className="mt-4 flex flex-wrap justify-center gap-2">
          {DESTINATIONS.map((d) => (
            <Link
              key={d.id}
              to={`/destinations/${d.id}`}
              className="inline-flex items-center gap-2 rounded-full bg-white px-3.5 py-1.5 text-sm font-semibold text-slate-600 ring-1 ring-slate-200 transition hover:text-navy-900 hover:ring-navy-900"
            >
              <img src={flagUrl(d.flag)} alt="" className="h-3.5 w-5 rounded-[2px] object-cover" />
              {d.name}
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
