import type { ComponentType } from "react";
import {
  ArrowRight,
  BadgeCheck,
  BedDouble,
  Compass,
  Eye,
  Headphones,
  HeartHandshake,
  Palmtree,
  PlaneTakeoff,
  ShieldCheck,
  Smile,
  Stamp,
  Target,
  Users,
} from "lucide-react";
import { CONTACT, PAYMENT_METHODS, SITE } from "@/config";
import { DESTINATION_INFO } from "@/data/destinations";
import { TOURS } from "@/data/tours";
import { openEnquiry, type EnquiryPreset } from "@/lib/enquiryBus";
import { Link, useTitle } from "@/lib/router";
import { pexels } from "@/lib/utils";
import { cn } from "@/utils/cn";
import { PageHero } from "@/components/ui/PageHero";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/primitives";
import { CountUp } from "@/components/ui/CountUp";
import { CTABanner } from "@/components/CTABanner";

type Icon = ComponentType<{ className?: string }>;

const OFFERINGS: { icon: Icon; label: string }[] = [
  { icon: Palmtree, label: "Holiday packages" },
  { icon: Stamp, label: "Visa assistance" },
  { icon: BedDouble, label: "Hotel bookings" },
  { icon: PlaneTakeoff, label: "Air tickets" },
  { icon: Users, label: "Group & corporate tours" },
  { icon: Compass, label: "Personalised travel solutions" },
];

const PILLARS: { icon: Icon; title: string; text: string }[] = [
  { icon: Target, title: "Our mission", text: "To make travel from Bangladesh seamless, memorable and affordable — for every kind of traveller." },
  { icon: Eye, title: "Our vision", text: "To be the most trusted travel partner for journeys across South Asia and beyond." },
  { icon: HeartHandshake, title: "Our promise", text: "Your Journey, Our Commitment — honest advice, reliable service and support at every step." },
];

const VALUES: { icon: Icon; title: string; text: string }[] = [
  { icon: ShieldCheck, title: "Reliability", text: "Confirmed bookings, clear communication and no unpleasant surprises." },
  { icon: HeartHandshake, title: "Personalised service", text: "No two travellers are alike — so no two itineraries are either." },
  { icon: Eye, title: "Transparency", text: "Honest advice and clear quotes that show exactly what's included." },
  { icon: Smile, title: "Customer satisfaction", text: "Your happiness before, during and after the trip is how we measure success." },
];

const DESKS: { icon: Icon; title: string; text: string; preset: EnquiryPreset }[] = [
  { icon: Palmtree, title: "Tour Planning", text: "Designs itineraries, books hotels and arranges guides & transport.", preset: { mode: "plan", service: "tour" } },
  { icon: Stamp, title: "Visa Desk", text: "Guides you through documents and handles your visa applications.", preset: { mode: "plan", service: "visa" } },
  { icon: PlaneTakeoff, title: "Ticketing & Hotels", text: "Finds the best fares and stays for your dates and budget.", preset: { mode: "plan", service: "air" } },
  { icon: Headphones, title: "Customer Care", text: "Answers your questions and supports you throughout your journey.", preset: { mode: "quick" } },
];

export function AboutPage() {
  useTitle("About Us", SITE.about);
  const stats = [
    { value: `${DESTINATION_INFO.length}`, label: "Destinations" },
    { value: `${TOURS.length}+`, label: "Curated tours" },
    { value: "3-in-1", label: "Visa offer" },
    { value: "TOAB", label: "Member agency" },
  ];

  return (
    <>
      <PageHero
        image={34775561}
        crumbs={[{ label: "Home", to: "/" }, { label: "About" }]}
        eyebrow={SITE.tagline}
        title="About SAARC Holiday"
        subtitle="A Dhaka-based travel and tourism agency creating seamless, memorable and affordable journeys for travellers from Bangladesh and beyond."
      />

      <section className="py-16 sm:py-24">
        <div className="mx-auto grid max-w-7xl items-center gap-14 px-4 sm:px-6 lg:grid-cols-2 lg:px-8">
          <Reveal>
            <div className="relative mx-auto grid max-w-lg grid-cols-2 gap-4">
              <img src={pexels(7658255, 500, 640)} alt="Travel consultants at work" loading="lazy" className="h-72 w-full rounded-3xl object-cover sm:h-80" />
              <img src={pexels(4173213, 500, 640)} alt="Family setting off on holiday" loading="lazy" className="mt-12 h-72 w-full rounded-3xl object-cover sm:h-80" />
              <div className="absolute -bottom-6 left-1/2 flex -translate-x-1/2 items-center gap-3 whitespace-nowrap rounded-2xl bg-white px-5 py-4 shadow-2xl shadow-navy-900/15">
                <BadgeCheck className="h-8 w-8 text-emerald-500" />
                <div>
                  <p className="text-sm font-bold text-navy-900">{SITE.membership}</p>
                  <p className="text-xs text-slate-500">Tour Operators Association of Bangladesh</p>
                </div>
              </div>
            </div>
          </Reveal>
          <div>
            <Reveal>
              <SectionHeading align="left" eyebrow="Who we are" title="Travel is more than visiting a destination" />
            </Reveal>
            <Reveal delay={80}>
              <div className="mt-6 space-y-4 text-[17px] leading-8 text-slate-600">
                {SITE.aboutLong.map((p) => (
                  <p key={p.slice(0, 30)}>{p}</p>
                ))}
              </div>
            </Reveal>
            <Reveal delay={140}>
              <ul className="mt-8 grid gap-3 sm:grid-cols-2">
                {OFFERINGS.map(({ icon: I, label }) => (
                  <li key={label} className="flex items-center gap-3 rounded-2xl bg-white p-3 text-sm font-semibold text-navy-900 ring-1 ring-slate-200/70">
                    <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-sunset-100 text-sunset-600">
                      <I className="h-4 w-4" />
                    </span>
                    {label}
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>
        </div>
      </section>

      <section className="bg-white py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-6 md:grid-cols-3">
            {PILLARS.map(({ icon: I, title, text }, i) => (
              <Reveal key={title} delay={i * 90} className="h-full">
                <div
                  className={cn(
                    "h-full rounded-3xl p-8",
                    i === 1 ? "bg-navy-900 text-white" : "bg-slate-50 ring-1 ring-slate-200/70",
                  )}
                >
                  <span className={cn("grid h-14 w-14 place-items-center rounded-2xl", i === 1 ? "bg-sunset-500 text-white" : "bg-sunset-100 text-sunset-600")}>
                    <I className="h-6 w-6" />
                  </span>
                  <h3 className={cn("mt-6 text-xl font-bold", i === 1 ? "text-white" : "text-navy-900")}>{title}</h3>
                  <p className={cn("mt-2 leading-relaxed", i === 1 ? "text-navy-100" : "text-slate-500")}>{text}</p>
                </div>
              </Reveal>
            ))}
          </div>
          <Reveal className="mt-10">
            <dl className="grid grid-cols-2 gap-4 rounded-3xl bg-linear-to-r from-sunset-500 to-sunset-600 p-8 text-white sm:grid-cols-4">
              {stats.map((s) => (
                <div key={s.label} className="text-center">
                  <dt className="sr-only">{s.label}</dt>
                  <dd className="text-4xl font-extrabold">
                    <CountUp value={s.value} />
                  </dd>
                  <p className="mt-1 text-sm font-medium text-white/85">{s.label}</p>
                </div>
              ))}
            </dl>
          </Reveal>
        </div>
      </section>

      <section className="py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <SectionHeading eyebrow="Our values" title="What guides everything we do" />
          </Reveal>
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {VALUES.map(({ icon: I, title, text }, i) => (
              <Reveal key={title} delay={i * 80} className="h-full">
                <div className="h-full rounded-3xl bg-white p-6 ring-1 ring-slate-200/70 transition hover:-translate-y-1 hover:shadow-xl hover:shadow-navy-900/5">
                  <I className="h-8 w-8 text-lagoon-600" />
                  <p className="mt-4 font-bold text-navy-900">{title}</p>
                  <p className="mt-1.5 text-sm leading-relaxed text-slate-500">{text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-white py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <SectionHeading eyebrow="Our team" title="Specialist desks, one friendly team" subtitle="Whatever you need, the right person is ready to help." />
          </Reveal>
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {DESKS.map(({ icon: I, title, text, preset }, i) => (
              <Reveal key={title} delay={i * 80} className="h-full">
                <button
                  type="button"
                  onClick={() => openEnquiry(preset)}
                  className="group flex h-full w-full flex-col rounded-3xl border border-slate-200/70 bg-slate-50/60 p-6 text-left transition hover:border-transparent hover:bg-navy-900 hover:shadow-2xl hover:shadow-navy-900/20"
                >
                  <span className="grid h-12 w-12 place-items-center rounded-2xl bg-navy-900 text-white transition group-hover:bg-sunset-500">
                    <I className="h-5 w-5" />
                  </span>
                  <p className="mt-5 font-bold text-navy-900 transition group-hover:text-white">{title}</p>
                  <p className="mt-1.5 flex-1 text-sm leading-relaxed text-slate-500 transition group-hover:text-navy-200">{text}</p>
                  <span className="mt-5 inline-flex items-center gap-1 text-sm font-bold text-sunset-600 group-hover:text-sunset-300">
                    Contact desk <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
                  </span>
                </button>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 sm:py-20">
        <div className="mx-auto grid max-w-7xl gap-6 px-4 sm:px-6 lg:grid-cols-2 lg:px-8">
          <Reveal className="h-full">
            <div className="flex h-full flex-col justify-between rounded-3xl bg-navy-900 p-8 text-white">
              <div>
                <BadgeCheck className="h-10 w-10 text-sunset-400" />
                <h3 className="mt-5 text-2xl font-extrabold">A registered member of TOAB</h3>
                <p className="mt-3 leading-relaxed text-navy-100">
                  SAARC Holiday is a member of the Tour Operators Association of Bangladesh — committed to professional standards, reliable service and customer satisfaction.
                </p>
              </div>
              <Link
                to="/contact"
                className="mt-8 inline-flex w-fit items-center gap-2 rounded-full bg-white px-5 py-3 text-sm font-bold text-navy-900 transition hover:bg-sunset-100"
              >
                Visit our office <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </Reveal>
          <Reveal className="h-full" delay={100}>
            <div className="flex h-full flex-col justify-between rounded-3xl bg-white p-8 ring-1 ring-slate-200/70">
              <div>
                <h3 className="text-2xl font-extrabold text-navy-900">Pay the way you like</h3>
                <p className="mt-3 leading-relaxed text-slate-500">
                  Secure, convenient payment options for every traveller — our team shares payment details once your booking is confirmed.
                </p>
                <ul className="mt-6 flex flex-wrap gap-2">
                  {PAYMENT_METHODS.map((p) => (
                    <li
                      key={p.name}
                      className={cn("rounded-xl bg-slate-50 px-4 py-2 text-sm font-extrabold ring-1 ring-slate-200", p.name === "VISA" && "italic tracking-wider")}
                      style={{ color: p.color }}
                    >
                      {p.name}
                    </li>
                  ))}
                </ul>
              </div>
              <p className="mt-8 text-sm text-slate-500">
                Office: <span className="font-semibold text-navy-900">{CONTACT.address.full}</span>
              </p>
            </div>
          </Reveal>
        </div>
      </section>

      <CTABanner />
    </>
  );
}
