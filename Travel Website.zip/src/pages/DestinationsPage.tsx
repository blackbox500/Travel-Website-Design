import { useState } from "react";
import { ArrowRight, Sparkles, X } from "lucide-react";
import { DESTINATION_INFO, REGIONS, type Region } from "@/data/destinations";
import { Link, useTitle } from "@/lib/router";
import { flagUrl } from "@/lib/utils";
import { cn } from "@/utils/cn";
import { PageHero } from "@/components/ui/PageHero";
import { Reveal } from "@/components/ui/Reveal";
import { SectionHeading } from "@/components/ui/primitives";
import { DestinationCard } from "@/components/cards/DestinationCard";
import { CTABanner } from "@/components/CTABanner";

const INTERESTS: Record<string, string[]> = {
  Mountains: ["bhutan", "nepal", "india", "china", "mongolia"],
  "Beaches & islands": ["thailand", "malaysia"],
  "City lights": ["singapore", "malaysia", "china", "thailand"],
  "Culture & heritage": ["bhutan", "nepal", "india", "china", "mongolia", "thailand"],
  Adventure: ["nepal", "mongolia", "bhutan"],
  "Family fun": ["singapore", "malaysia", "thailand"],
  Honeymoon: ["bhutan", "thailand", "nepal", "india", "malaysia"],
  "Short flight": ["bhutan", "nepal", "india", "thailand"],
};

export function DestinationsPage() {
  useTitle(
    "Destinations",
    "Explore Bhutan, Nepal, India, China, Mongolia, Thailand, Malaysia and Singapore with SAARC Holiday — travel guides, best time to visit and visa tips for Bangladeshi travellers.",
  );
  const [region, setRegion] = useState<"All" | Region>("All");
  const [interests, setInterests] = useState<string[]>([]);
  const toggle = (k: string) => setInterests((s) => (s.includes(k) ? s.filter((x) => x !== k) : [...s, k]));

  const scored = DESTINATION_INFO.filter((d) => region === "All" || d.region === region)
    .map((d) => ({ d, score: interests.filter((k) => INTERESTS[k].includes(d.id)).length }))
    .sort((a, b) => b.score - a.score);
  const best = scored.length ? scored[0].score : 0;

  return (
    <>
      <PageHero
        image={35159544}
        crumbs={[{ label: "Home", to: "/" }, { label: "Destinations" }]}
        eyebrow="Explore Asia with us"
        title="Our destinations"
        subtitle="Eight unforgettable countries, all within a few hours of Dhaka — with expert visa guidance for Bangladeshi travellers."
      />

      <section className="py-12 sm:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <div className="rounded-[2rem] bg-white p-6 shadow-xl shadow-navy-900/5 ring-1 ring-slate-200/70 sm:p-8">
              <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
                <div>
                  <p className="flex items-center gap-2 text-lg font-bold text-navy-900">
                    <Sparkles className="h-5 w-5 text-sunset-500" /> Destination finder
                  </p>
                  <p className="mt-1 text-sm text-slate-500">What are you in the mood for? Pick one or more and we'll rank destinations for you.</p>
                </div>
                <div role="tablist" aria-label="Filter by region" className="flex flex-wrap gap-2">
                  {(["All", ...REGIONS] as ("All" | Region)[]).map((r) => (
                    <button
                      key={r}
                      type="button"
                      role="tab"
                      aria-selected={region === r}
                      onClick={() => setRegion(r)}
                      className={cn(
                        "rounded-full px-4 py-2 text-sm font-semibold transition",
                        region === r ? "bg-navy-900 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200",
                      )}
                    >
                      {r}
                    </button>
                  ))}
                </div>
              </div>
              <div className="mt-5 flex flex-wrap items-center gap-2">
                {Object.keys(INTERESTS).map((k) => {
                  const on = interests.includes(k);
                  return (
                    <button
                      key={k}
                      type="button"
                      aria-pressed={on}
                      onClick={() => toggle(k)}
                      className={cn(
                        "rounded-full border px-4 py-2 text-sm font-semibold transition active:scale-95",
                        on ? "border-sunset-500 bg-sunset-500 text-white shadow-md shadow-sunset-500/25" : "border-slate-200 bg-white text-slate-600 hover:border-slate-300",
                      )}
                    >
                      {k}
                    </button>
                  );
                })}
                {interests.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setInterests([])}
                    className="inline-flex items-center gap-1 px-2 text-sm font-semibold text-slate-500 hover:text-rose-600"
                  >
                    <X className="h-4 w-4" /> Clear
                  </button>
                )}
              </div>
            </div>
          </Reveal>

          <div className="mt-10 grid auto-rows-[360px] gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {scored.map(({ d, score }) => (
              <DestinationCard
                key={d.id}
                d={d}
                className={cn("h-full animate-fade-up transition-opacity", interests.length > 0 && score === 0 && "opacity-50")}
                badge={
                  interests.length
                    ? score === best && best > 0
                      ? "Top match"
                      : score > 0
                        ? `${Math.round((score / interests.length) * 100)}% match`
                        : undefined
                    : undefined
                }
              />
            ))}
          </div>
        </div>
      </section>

      <section className="bg-white py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <SectionHeading eyebrow="At a glance" title="Compare destinations" subtitle="Best time to go, ideal trip length and visa basics for Bangladeshi travellers." />
          </Reveal>
          <Reveal className="mt-10">
            <div className="overflow-x-auto rounded-3xl ring-1 ring-slate-200">
              <table className="w-full min-w-[820px] text-left text-sm">
                <thead className="bg-navy-900 text-white">
                  <tr>
                    {["Destination", "Best time", "Ideal trip", "From Dhaka", "Visa for Bangladeshis", ""].map((h, i) => (
                      <th key={i} className="px-5 py-4 font-semibold">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {DESTINATION_INFO.map((d) => (
                    <tr key={d.id} className="transition hover:bg-sunset-50/50">
                      <td className="px-5 py-4">
                        <Link to={`/destinations/${d.id}`} className="flex items-center gap-3 font-bold text-navy-900 hover:text-sunset-600">
                          <img src={flagUrl(d.flag)} alt="" className="h-4 w-6 rounded-sm object-cover" />
                          {d.name}
                        </Link>
                      </td>
                      <td className="px-5 py-4 text-slate-600">{d.facts.bestTime}</td>
                      <td className="px-5 py-4 text-slate-600">{d.facts.duration}</td>
                      <td className="px-5 py-4 text-slate-600">{d.facts.flight}</td>
                      <td className="px-5 py-4 text-slate-600">{d.facts.visa}</td>
                      <td className="px-5 py-4 text-right">
                        <Link
                          to={`/tours?destination=${d.id}`}
                          className="inline-flex items-center gap-1 whitespace-nowrap text-xs font-bold text-sunset-600 hover:text-sunset-700"
                        >
                          View tours <ArrowRight className="h-3.5 w-3.5" />
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Reveal>
        </div>
      </section>

      <div className="pt-16 sm:pt-20">
        <CTABanner />
      </div>
    </>
  );
}
