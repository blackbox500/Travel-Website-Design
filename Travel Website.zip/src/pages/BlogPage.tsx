import { useState } from "react";
import { ArrowRight, CalendarDays, Clock, Search, SearchX } from "lucide-react";
import { CATEGORIES, POSTS, readingTime, type Category } from "@/data/blog";
import { Link, useTitle } from "@/lib/router";
import { formatDate, pexels } from "@/lib/utils";
import { cn } from "@/utils/cn";
import { PageHero } from "@/components/ui/PageHero";
import { BlogCard } from "@/components/cards/BlogCard";
import { Newsletter } from "@/components/ui/Newsletter";
import { Reveal } from "@/components/ui/Reveal";

export function BlogPage() {
  useTitle("Travel Blog", "Travel guides, visa tips, itineraries and offers from SAARC Holiday — written for travellers from Bangladesh.");
  const [cat, setCat] = useState<"All" | Category>("All");
  const [q, setQ] = useState("");
  const query = q.trim().toLowerCase();
  const featured = POSTS.find((p) => p.featured) ?? POSTS[0];
  const list = POSTS.filter(
    (p) => (cat === "All" || p.category === cat) && (!query || `${p.title} ${p.excerpt} ${p.tags.join(" ")}`.toLowerCase().includes(query)),
  );
  const showFeatured = cat === "All" && !query;
  const grid = showFeatured ? list.filter((p) => p.slug !== featured.slug) : list;
  const cats = CATEGORIES.filter((c) => POSTS.some((p) => p.category === c));

  return (
    <>
      <PageHero
        image={34775561}
        crumbs={[{ label: "Home", to: "/" }, { label: "Blog" }]}
        eyebrow="Stories & advice"
        title="The SAARC Holiday travel blog"
        subtitle="Destination guides, visa checklists, itineraries and the latest offers — written for travellers from Bangladesh."
      />

      <section className="py-12 sm:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div role="tablist" aria-label="Filter articles by category" className="flex gap-2 overflow-x-auto pb-1">
              {(["All", ...cats] as ("All" | Category)[]).map((c) => (
                <button
                  key={c}
                  type="button"
                  role="tab"
                  aria-selected={cat === c}
                  onClick={() => setCat(c)}
                  className={cn(
                    "shrink-0 rounded-full px-4 py-2 text-sm font-semibold transition",
                    cat === c ? "bg-navy-900 text-white shadow-md shadow-navy-900/20" : "bg-white text-slate-600 ring-1 ring-slate-200 hover:bg-slate-50",
                  )}
                >
                  {c}
                </button>
              ))}
            </div>
            <div className="relative w-full lg:w-80">
              <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                type="search"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search articles…"
                aria-label="Search articles"
                className="w-full rounded-full border border-slate-200 bg-white py-3 pl-11 pr-4 text-sm shadow-sm placeholder:text-slate-400 focus:border-lagoon-400 focus:outline-none focus:ring-4 focus:ring-lagoon-100"
              />
            </div>
          </div>

          {showFeatured && (
            <Reveal className="mt-10">
              <article className="group relative grid overflow-hidden rounded-[2rem] bg-white shadow-xl shadow-navy-900/5 ring-1 ring-slate-200/70 lg:grid-cols-2">
                <div className="relative aspect-[16/10] overflow-hidden lg:aspect-auto">
                  <img
                    src={pexels(featured.cover, 1000, 700)}
                    alt=""
                    className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
                  />
                  <span className="absolute left-5 top-5 rounded-full bg-sunset-500 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-white">
                    Featured
                  </span>
                </div>
                <div className="flex flex-col justify-center p-8 sm:p-10">
                  <p className="text-xs font-bold uppercase tracking-[0.18em] text-sunset-600">{featured.category}</p>
                  <h2 className="mt-3 text-2xl font-extrabold leading-tight text-navy-900 transition group-hover:text-sunset-600 sm:text-3xl">
                    <Link to={`/blog/${featured.slug}`} className="after:absolute after:inset-0">
                      {featured.title}
                    </Link>
                  </h2>
                  <p className="mt-4 leading-relaxed text-slate-500">{featured.excerpt}</p>
                  <p className="mt-6 flex flex-wrap items-center gap-4 text-sm text-slate-400">
                    <span className="inline-flex items-center gap-1.5">
                      <CalendarDays className="h-4 w-4" />
                      {formatDate(featured.date)}
                    </span>
                    <span className="inline-flex items-center gap-1.5">
                      <Clock className="h-4 w-4" />
                      {readingTime(featured)} min read
                    </span>
                  </p>
                  <span className="mt-6 inline-flex items-center gap-1.5 text-sm font-bold text-sunset-600">
                    Read the guide <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
                  </span>
                </div>
              </article>
            </Reveal>
          )}

          {grid.length > 0 ? (
            <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {grid.map((p) => (
                <BlogCard key={p.slug} post={p} className="animate-fade-up" />
              ))}
            </div>
          ) : (
            list.length === 0 && (
              <div className="mt-10 rounded-3xl border border-dashed border-slate-300 bg-white p-12 text-center">
                <SearchX className="mx-auto h-10 w-10 text-slate-300" />
                <p className="mt-4 font-bold text-navy-900">No articles found</p>
                <p className="mt-1 text-sm text-slate-500">Try a different search or category.</p>
              </div>
            )
          )}
        </div>
      </section>

      <section className="px-4 pb-20 sm:px-6 lg:px-8">
        <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-6 rounded-[2rem] bg-linear-to-r from-lagoon-50 via-white to-sunset-50 p-8 ring-1 ring-slate-200/70 sm:p-10 lg:flex-row lg:items-center">
          <div>
            <p className="text-2xl font-extrabold text-navy-900">Never miss a travel deal</p>
            <p className="mt-1 text-slate-500">New guides, visa updates and exclusive offers — straight to your inbox.</p>
          </div>
          <Newsletter className="w-full max-w-md" />
        </div>
      </section>
    </>
  );
}
