/**
 * ⚠️ SAMPLE REVIEWS – these are placeholders for layout purposes only.
 * Replace them with genuine reviews from your customers (with their permission)
 * before publishing, or hide the section via SETTINGS.showTestimonials in config.ts.
 */
export interface Testimonial {
  name: string;
  location: string;
  trip: string;
  text: string;
  rating: number;
}

export const TESTIMONIALS: Testimonial[] = [
  {
    name: "Farhana & Imran",
    location: "Dhaka",
    trip: "Bhutan Classic",
    text: "Everything was arranged perfectly — the hotels, the car and our guide in Bhutan. The Tiger's Nest hike was the highlight of our honeymoon!",
    rating: 5,
  },
  {
    name: "Mahmudul H.",
    location: "Chattogram",
    trip: "3-Country Visa Offer",
    text: "I applied for Thailand, Malaysia and Singapore with one set of documents. The team explained every step clearly and kept me updated.",
    rating: 5,
  },
  {
    name: "Nusrat J.",
    location: "Dhaka",
    trip: "Nepal Highlights",
    text: "Our family trip to Kathmandu and Pokhara was smooth from start to finish. The Sarangkot sunrise is something we'll never forget.",
    rating: 5,
  },
  {
    name: "Tanvir A.",
    location: "Sylhet",
    trip: "Thailand Fun",
    text: "Great value package for Bangkok and Pattaya, and quick replies on WhatsApp whenever we needed anything during the trip.",
    rating: 4,
  },
  {
    name: "Shirin S.",
    location: "Rajshahi",
    trip: "Singapore City & Sentosa",
    text: "The kids loved Universal Studios and Gardens by the Bay. Hotel location was excellent and every transfer was on time.",
    rating: 5,
  },
];
