import { DESTINATIONS, type Destination } from "@/config";

export type Region = "South Asia" | "East Asia" | "Southeast Asia";
export const REGIONS: Region[] = ["South Asia", "East Asia", "Southeast Asia"];

export interface Highlight {
  title: string;
  text: string;
  image: number;
}

export interface DestinationFacts {
  bestTime: string;
  duration: string;
  currency: string;
  language: string;
  flight: string;
  visa: string;
}

interface Details {
  region: Region;
  hero: number;
  summary: string;
  intro: string[];
  facts: DestinationFacts;
  visaNote: string;
  highlights: Highlight[];
  tips: string[];
  gallery: number[];
  faqs: { q: string; a: string }[];
}

export type DestinationInfo = Destination & Details;

const DETAILS: Record<string, Details> = {
  bhutan: {
    region: "South Asia",
    hero: 7806281,
    summary: "The last Himalayan kingdom — cliff-top monasteries, prayer-flag passes and Gross National Happiness.",
    intro: [
      "Tucked into the eastern Himalaya, Bhutan is the world's first carbon-negative country and the kingdom that famously measures progress in Gross National Happiness. Fortress-monasteries called dzongs guard emerald river valleys, prayer flags flutter over high mountain passes and daily life still moves at a gentle, unhurried pace.",
      "For Bangladeshi travellers it is also one of the easiest international holidays: a short direct flight lands you in Paro, Bangladeshi nationals enjoy a special reduced Sustainable Development Fee, and the clean air, quiet roads and warm hospitality make it ideal for families, honeymooners and first-time travellers alike.",
    ],
    facts: {
      bestTime: "Mar–May · Sep–Nov",
      duration: "5–7 days",
      currency: "Ngultrum (BTN)",
      language: "Dzongkha · English",
      flight: "≈ 1 hr direct to Paro",
      visa: "Visa online or on arrival",
    },
    visaNote:
      "Bangladeshi nationals can apply for a Bhutan visa (USD 40) in advance or on arrival at Paro. The first 15,000 Bangladeshi visitors each year pay a concessional Sustainable Development Fee of USD 15 per person per night (children under 6 are exempt); once the quota is filled the standard USD 100 rate applies. We arrange the paperwork for you.",
    highlights: [
      {
        title: "Paro Taktsang (Tiger's Nest)",
        text: "Bhutan's most iconic sight — a monastery clinging to a cliff 900 m above the Paro valley, reached by a rewarding half-day hike.",
        image: 39128859,
      },
      {
        title: "Punakha Dzong",
        text: "The 'Palace of Great Happiness' sits where the Pho Chhu and Mo Chhu rivers meet — arguably the most beautiful dzong in the kingdom.",
        image: 37747845,
      },
      {
        title: "Buddha Dordenma, Thimphu",
        text: "A giant gilded Buddha overlooking the capital, housing more than 100,000 smaller Buddha statues inside.",
        image: 2810269,
      },
      {
        title: "Dochula Pass",
        text: "108 memorial chortens and, on clear days, a sweeping panorama of snow-capped Himalayan peaks at 3,100 m.",
        image: 18718814,
      },
    ],
    tips: [
      "Dress modestly when visiting dzongs and temples — long sleeves, long trousers or skirts, and no hats inside.",
      "Carry some US dollars in clean, newer notes; Indian rupees are also widely accepted.",
      "Always walk clockwise around chortens, prayer wheels and temples.",
      "The Tiger's Nest hike takes 4–6 hours return — wear good shoes and start early.",
      "Ask before photographing people; photography is not allowed inside most temples.",
    ],
    gallery: [35402324, 37747857, 5011717, 15584957, 18695377, 6904727, 39128857, 3823266],
    faqs: [
      {
        q: "Do Bangladeshi citizens need a visa for Bhutan?",
        a: "Yes. Bangladeshi passport holders need a Bhutan visa (USD 40), which can be applied for online in advance or obtained on arrival at Paro International Airport. We handle the application as part of your package.",
      },
      {
        q: "How much is the Sustainable Development Fee (SDF) for Bangladeshis?",
        a: "The first 15,000 Bangladeshi visitors each year pay a concessional SDF of USD 15 per person per night, and children under 6 are exempt. Once the annual quota is filled, the standard rate of USD 100 per night applies. Fees are set by the Government of Bhutan and may change.",
      },
      {
        q: "What is the best time to visit Bhutan?",
        a: "Spring (March–May) brings blooming rhododendrons and pleasant days, while autumn (September–November) offers the clearest mountain views and colourful festivals such as the Thimphu Tshechu. Winters are cold but clear; June–August is the monsoon season.",
      },
      {
        q: "Is Bhutan suitable for families and older travellers?",
        a: "Absolutely. Distances are short, roads are quiet and every itinerary includes a private vehicle and guide. The Tiger's Nest hike is optional — ponies can take you part of the way, or you can enjoy the view from the halfway cafeteria.",
      },
    ],
  },
  nepal: {
    region: "South Asia",
    hero: 34775561,
    summary: "Home of Everest — ancient temples, lakeside Pokhara and sunrise over the Annapurnas.",
    intro: [
      "Nepal packs eight of the world's ten highest mountains, medieval temple squares and steamy jungle into one small, friendly country. Kathmandu's UNESCO-listed heritage sites hum with incense and prayer, while lakeside Pokhara wakes up to the Annapurna range glowing pink at sunrise.",
      "Just over an hour's flight from Dhaka, and with a free 30-day visa on arrival for Bangladeshi nationals (first visit each year), Nepal is perfect for a quick getaway, a honeymoon in the hills or a first taste of Himalayan adventure — from paragliding and rafting to jungle safaris in Chitwan.",
    ],
    facts: {
      bestTime: "Oct–Nov · Mar–Apr",
      duration: "5–8 days",
      currency: "Nepalese Rupee (NPR)",
      language: "Nepali · English",
      flight: "≈ 1.5 hr to Kathmandu",
      visa: "Free 30-day visa on arrival",
    },
    visaNote:
      "Bangladeshi citizens receive a free 30-day tourist visa on arrival for their first visit in each calendar year (January–December). Further visits in the same year are charged at the standard fees. Bring a passport valid for at least six months and a passport photo.",
    highlights: [
      {
        title: "Pokhara & Phewa Lake",
        text: "Row across the mirror-calm lake to Tal Barahi temple, then watch the Annapurnas light up from Sarangkot at dawn.",
        image: 15846574,
      },
      {
        title: "Boudhanath Stupa",
        text: "One of the largest stupas in the world and the heart of Tibetan Buddhist culture in Kathmandu.",
        image: 11505263,
      },
      {
        title: "Himalayan sunrise",
        text: "From Nagarkot or Sarangkot, watch first light spill across a wall of 7,000- and 8,000-metre peaks.",
        image: 35408915,
      },
      {
        title: "Chitwan National Park",
        text: "Jeep safaris and canoe rides in search of one-horned rhinos, crocodiles and — if you're lucky — a Bengal tiger.",
        image: 38267708,
      },
    ],
    tips: [
      "Carry US dollars or exchange money on arrival — Bangladeshi Taka is hard to exchange in Nepal.",
      "Kathmandu to Pokhara is about 200 km: 6–8 hours by road or a 25-minute flight.",
      "Pack layers — mornings and evenings in the hills are cool even in spring and autumn.",
      "Bargaining is expected in Thamel and Pokhara Lakeside markets, always with a smile.",
      "Drink bottled or filtered water — and don't leave without trying momos!",
    ],
    gallery: [32225790, 37836764, 15534873, 38532251, 11824355, 10965830, 35159544],
    faqs: [
      {
        q: "Is the Nepal visa really free for Bangladeshis?",
        a: "Yes — as SAARC nationals, Bangladeshi citizens get a free (gratis) 30-day tourist visa on arrival for their first visit in each visa year (January–December). Subsequent visits in the same year are subject to the standard visa fees.",
      },
      {
        q: "When is the best time to visit Nepal?",
        a: "October–November offers crystal-clear mountain views after the monsoon, while March–April brings warm days and blooming rhododendrons. June–September is monsoon season, when mountain views are often hidden by cloud.",
      },
      {
        q: "Do I need to be fit for a Nepal tour?",
        a: "Not at all. Our sightseeing tours involve only short, easy walks. If you'd like adventure, we can add optional activities such as paragliding in Pokhara, white-water rafting or short treks.",
      },
    ],
  },
  india: {
    region: "South Asia",
    hero: 17423832,
    summary: "Marble wonders, pink cities and the shikaras of Kashmir — a world of experiences next door.",
    intro: [
      "India is less a destination than a collection of worlds: the Mughal grandeur of Delhi and Agra, the rose-pink palaces of Jaipur and the snow-dusted meadows of Kashmir. Few places offer as much history, colour and flavour within a single trip.",
      "Whether you dream of seeing the Taj Mahal at sunrise, gliding across Dal Lake in a shikara or shopping for handicrafts in a Rajasthani bazaar, we design itineraries that balance must-see sights with comfortable hotels and private transport.",
    ],
    facts: {
      bestTime: "Oct–Mar",
      duration: "6–9 days",
      currency: "Indian Rupee (INR)",
      language: "Hindi · English",
      flight: "≈ 2 hr to Delhi",
      visa: "Tourist visa — ask for status",
    },
    visaNote:
      "Indian visa availability, appointment slots and requirements for Bangladeshi applicants change from time to time. Please contact us for the latest status before planning — we'll advise on documents and timelines.",
    highlights: [
      {
        title: "Taj Mahal, Agra",
        text: "The world's most famous monument to love — best seen at sunrise, when the white marble glows pink and gold.",
        image: 11948442,
      },
      {
        title: "Hawa Mahal, Jaipur",
        text: "The honeycomb 'Palace of Winds', with its 953 windows, is the symbol of Rajasthan's Pink City.",
        image: 17911339,
      },
      {
        title: "Dal Lake, Srinagar",
        text: "Stay on a carved-wood houseboat and drift past floating gardens in a traditional shikara.",
        image: 40348598,
      },
      {
        title: "Kashmir's valleys",
        text: "Gulmarg, Pahalgam and Sonamarg — alpine meadows, pine forests and snow-capped peaks.",
        image: 33054187,
      },
    ],
    tips: [
      "Carry printed copies of your visa and hotel bookings for immigration.",
      "Dress modestly at temples, mosques and gurdwaras — shoes are removed at the entrance.",
      "The Taj Mahal is closed to visitors on Fridays.",
      "Use prepaid taxis or app-based cabs in the big cities.",
      "Pack warm clothes for Kashmir from November to March.",
    ],
    gallery: [17423832, 19521546, 34452407, 6739193],
    faqs: [
      {
        q: "Can Bangladeshi citizens get an Indian tourist visa?",
        a: "Indian visa services for Bangladeshi applicants have changed several times in recent years. Please contact us for the current situation, required documents and expected timelines before you plan your trip.",
      },
      {
        q: "What is the best time to visit India?",
        a: "October to March is ideal for Delhi, Agra and Rajasthan, with pleasant days and cool nights. Kashmir is lovely from April to October, and magical under snow from December to February.",
      },
      {
        q: "Is the Golden Triangle tour suitable for families?",
        a: "Yes — it's one of our most family-friendly tours, with comfortable drives between Delhi, Agra and Jaipur and plenty of time at each stop.",
      },
    ],
  },
  china: {
    region: "East Asia",
    hero: 5504688,
    summary: "The Great Wall, imperial palaces, futuristic skylines and the misty old towns of Yunnan.",
    intro: [
      "From the imperial grandeur of Beijing's Forbidden City to the glittering skyline of Shanghai's Bund, China is a country of breathtaking contrasts. Walk a restored section of the Great Wall, ride a bullet train at over 300 km/h and taste regional cuisines you'll never forget.",
      "Closer to home, Yunnan province — just a short flight from Dhaka to Kunming — offers snow mountains, lakes and beautifully preserved old towns such as Dali and Lijiang. We take care of visas, hotels, guides and train tickets so you can simply enjoy the journey.",
    ],
    facts: {
      bestTime: "Apr–May · Sep–Oct",
      duration: "6–10 days",
      currency: "Renminbi (CNY)",
      language: "Mandarin",
      flight: "≈ 2 hr to Kunming",
      visa: "Tourist (L) visa",
    },
    visaNote:
      "Bangladeshi passport holders need a Chinese tourist (L) visa, applied for through the Chinese Visa Application Service Center in Dhaka. We prepare your application, hotel bookings and itinerary to support it.",
    highlights: [
      {
        title: "The Great Wall",
        text: "Walk the ramparts at Mutianyu, where the wall snakes over forested ridges as far as the eye can see.",
        image: 19031655,
      },
      {
        title: "Forbidden City, Beijing",
        text: "Explore the vast palace complex that was home to 24 emperors over nearly 500 years.",
        image: 20694743,
      },
      {
        title: "The Bund, Shanghai",
        text: "A colonial-era waterfront facing the futuristic Pudong skyline — spectacular after dark.",
        image: 30221299,
      },
      {
        title: "Lijiang Old Town",
        text: "Cobbled lanes, canals and Naxi wooden houses beneath Jade Dragon Snow Mountain.",
        image: 8936979,
      },
    ],
    tips: [
      "Set up Alipay or WeChat Pay before you go — mobile payments are used almost everywhere.",
      "Many Google services and social apps don't work in China; download offline maps and a translation app in advance.",
      "Carry your passport at all times — it's needed for trains, hotels and many attractions.",
      "Learn a few words: 'nǐ hǎo' (hello) and 'xièxie' (thank you) go a long way.",
    ],
    gallery: [5504688, 20683315, 345162, 10836079, 38690155],
    faqs: [
      {
        q: "How long does a Chinese tourist visa take?",
        a: "Processing times vary by season and workload. We recommend applying at least 3–4 weeks before travel; contact us for current timelines and document requirements.",
      },
      {
        q: "Is it easy to pay in China?",
        a: "China is largely cashless. Alipay and WeChat Pay now accept many international cards, and we also suggest carrying some Chinese yuan in cash for small purchases.",
      },
      {
        q: "Beijing & Shanghai or Yunnan — which is better for a first trip?",
        a: "Choose Beijing & Shanghai for iconic landmarks and modern cities, or Yunnan for mountains, lakes and old towns — with a much shorter flight from Dhaka.",
      },
    ],
  },
  mongolia: {
    region: "East Asia",
    hero: 39839229,
    summary: "Endless steppe, nomadic gers and the freedom of the open sky — true adventure.",
    intro: [
      "Mongolia is one of the last great wildernesses on earth — a land of rolling grasslands, granite mountains, sand dunes and an endless blue sky. Nomadic herders still move with the seasons, welcoming travellers into their gers with salty milk tea and warm hospitality.",
      "Our Mongolia journeys combine the capital, Ulaanbaatar, with nights in comfortable ger camps, horse riding in Gorkhi-Terelj National Park and a visit to the giant Genghis Khan Equestrian Statue. Summer (June–September) is the season, with the colourful Naadam Festival held every July.",
    ],
    facts: {
      bestTime: "Jun–Sep",
      duration: "6–9 days",
      currency: "Tögrög (MNT)",
      language: "Mongolian",
      flight: "Via Bangkok, Beijing or Seoul",
      visa: "Tourist visa required",
    },
    visaNote:
      "Bangladeshi citizens need a tourist visa for Mongolia. Requirements and the application route can change, so contact us — we'll guide you through the documents and any invitation letter required.",
    highlights: [
      {
        title: "Gorkhi-Terelj National Park",
        text: "Granite rock formations, alpine meadows and ger camps, about 1.5 hours from Ulaanbaatar.",
        image: 31427424,
      },
      {
        title: "Nomadic life",
        text: "Visit a herder family, share milk tea and learn how a traditional ger is built.",
        image: 4321506,
      },
      {
        title: "Gers under the stars",
        text: "Sleep in a traditional felt tent and wake up to silence and endless horizons.",
        image: 4321589,
      },
      {
        title: "Horseback adventures",
        text: "Ride sturdy Mongolian horses across the open steppe with experienced local guides.",
        image: 4321590,
      },
    ],
    tips: [
      "Pack warm layers even in summer — nights on the steppe can be chilly.",
      "Carry cash (tögrög) for countryside areas where cards aren't accepted.",
      "Accept food or drink with your right hand (or both hands) as a sign of respect.",
      "Expect long drives on rough roads outside the city — motion-sickness tablets help.",
    ],
    gallery: [39839229, 4321590, 31427424],
    faqs: [
      {
        q: "When is the best time to visit Mongolia?",
        a: "June to September, when days are warm and the steppe is green. July is the busiest month because of the Naadam Festival — book early if you'd like to see it.",
      },
      {
        q: "Are ger camps comfortable?",
        a: "Tourist ger camps have proper beds, heating stoves and shared (sometimes private) bathrooms with hot showers. They're cosy, clean and a highlight for most travellers.",
      },
    ],
  },
  thailand: {
    region: "Southeast Asia",
    hero: 33053824,
    summary: "Golden temples, street-food heaven and island-hopping on turquoise seas.",
    intro: [
      "Thailand has it all: the gilded temples and buzzing night markets of Bangkok, the beach energy of Pattaya and the limestone cliffs and turquoise waters of Phuket, Krabi and the Phi Phi Islands. Add world-famous food, great-value shopping and the legendary Thai smile.",
      "Only about two hours from Dhaka, Thailand is one of the most popular short-haul getaways — and with our 3-country visa offer you can combine it with Malaysia and Singapore using one set of documents.",
    ],
    facts: {
      bestTime: "Nov–Apr",
      duration: "4–7 days",
      currency: "Thai Baht (THB)",
      language: "Thai",
      flight: "≈ 2 hr to Bangkok",
      visa: "e-Visa · 3-country offer",
    },
    visaNote:
      "Bangladeshi passport holders need a Thai tourist visa, applied for online through the official Thai e-Visa system. It's included in our 3-country visa offer (Thailand, Malaysia & Singapore) for BDT 16,780.",
    highlights: [
      {
        title: "Phi Phi Islands",
        text: "Snorkel in impossibly clear water and visit Maya Bay on a speedboat day trip from Phuket or Krabi.",
        image: 33053824,
      },
      {
        title: "Wat Arun & the Grand Palace",
        text: "Bangkok's riverside 'Temple of Dawn' and the dazzling royal palace complex.",
        image: 5264308,
      },
      {
        title: "Krabi's limestone coast",
        text: "Railay beach, Four Islands tours and sunsets framed by towering karst cliffs.",
        image: 32076924,
      },
      {
        title: "Bangkok by night",
        text: "Rooftop views, river cruises and night markets overflowing with street food.",
        image: 30540817,
      },
    ],
    tips: [
      "Dress modestly for temples — shoulders and knees must be covered.",
      "Never speak disrespectfully about the Thai royal family; it's taken very seriously.",
      "Use metered taxis or ride-hailing apps such as Grab and Bolt.",
      "Carry some cash for street food and markets; cards work in malls and hotels.",
      "Use sunscreen and drink plenty of water — it's hot all year round.",
    ],
    gallery: [28544989, 35126787, 37691587],
    faqs: [
      {
        q: "Do Bangladeshis need a visa for Thailand?",
        a: "Yes. Bangladeshi passport holders must obtain a tourist visa before travel through the Thai e-Visa system. We prepare and submit the application — it's also part of our 3-country visa offer.",
      },
      {
        q: "Bangkok & Pattaya or Phuket & Krabi?",
        a: "Bangkok & Pattaya is great for first-timers, families and shoppers. Phuket & Krabi is ideal for beaches, island-hopping and honeymoons. Can't decide? We can combine both.",
      },
      {
        q: "When is the best time to visit Thailand?",
        a: "November to April is the dry season and the most comfortable time to visit. May to October brings tropical showers, but also lower prices and fewer crowds.",
      },
    ],
  },
  malaysia: {
    region: "Southeast Asia",
    hero: 9395978,
    summary: "Twin towers, cool highlands and island paradise — truly Asia.",
    intro: [
      "Malaysia blends Malay, Chinese and Indian cultures into one of Asia's most welcoming countries. Kuala Lumpur dazzles with the Petronas Twin Towers and Batu Caves, Genting Highlands offers cool air and theme-park thrills, and Langkawi tempts with duty-free shopping, mangroves and white-sand beaches.",
      "With halal food everywhere, excellent infrastructure and plenty of family-friendly attractions, Malaysia is a favourite with Bangladeshi travellers — and it's part of our 3-country visa offer.",
    ],
    facts: {
      bestTime: "Dec–Apr (west coast)",
      duration: "5–7 days",
      currency: "Ringgit (MYR)",
      language: "Malay · English",
      flight: "≈ 3.5 hr to Kuala Lumpur",
      visa: "eVisa · 3-country offer",
    },
    visaNote:
      "Bangladeshi citizens need a Malaysian visa, applied for online through the official eVisa system. It's included in our 3-country visa offer (Thailand, Malaysia & Singapore) for BDT 16,780.",
    highlights: [
      {
        title: "Petronas Twin Towers",
        text: "Walk the Skybridge linking the iconic 88-storey towers, then watch the fountain show in KLCC Park.",
        image: 11719269,
      },
      {
        title: "Batu Caves",
        text: "Climb 272 rainbow-painted steps to a vast limestone cave temple guarded by a giant golden statue.",
        image: 35445967,
      },
      {
        title: "Langkawi",
        text: "Ride the SkyCab cable car, cruise the mangroves and relax on Pantai Cenang beach.",
        image: 17939735,
      },
      {
        title: "KL by night",
        text: "Bukit Bintang's food streets, rooftop views and glittering shopping malls.",
        image: 9395978,
      },
    ],
    tips: [
      "Halal food is available almost everywhere — a big plus for Muslim travellers.",
      "Use Grab for affordable, reliable rides in the cities.",
      "Bring a light jacket for Genting Highlands, which is noticeably cooler than KL.",
      "Langkawi is duty-free — great for chocolates and souvenirs.",
    ],
    gallery: [19492620],
    faqs: [
      {
        q: "Is Malaysia good for a family holiday?",
        a: "Very. Kuala Lumpur and Genting Highlands have theme parks, aquariums and malls, halal food is everywhere and getting around is easy.",
      },
      {
        q: "Can I combine Malaysia with Singapore and Thailand?",
        a: "Yes — our Southeast Asia Trio tour covers all three, and our 3-country visa offer lets you apply for all three visas with one set of documents.",
      },
    ],
  },
  singapore: {
    region: "Southeast Asia",
    hero: 37009220,
    summary: "Garden city of the future — Marina Bay, Sentosa and world-class attractions.",
    intro: [
      "Singapore feels like the future: sky-high gardens, gleaming architecture and some of the world's best attractions — all in a spotlessly clean, safe and easy-to-navigate island nation. Gardens by the Bay, Marina Bay Sands, Sentosa Island and Universal Studios make it a dream for families.",
      "Food lovers will find heaven in its hawker centres, and shoppers on Orchard Road. A Singapore visa for Bangladeshi passport holders is processed through an authorised agent — and it's included in our 3-country visa offer.",
    ],
    facts: {
      bestTime: "Feb–Apr (year-round)",
      duration: "3–5 days",
      currency: "Singapore Dollar (SGD)",
      language: "English · Malay · Mandarin · Tamil",
      flight: "≈ 4 hr to Singapore",
      visa: "Visa via agent · 3-country offer",
    },
    visaNote:
      "Bangladeshi passport holders need a Singapore visa, submitted through an authorised visa agent or a local contact. We handle the full application — and it's part of our 3-country visa offer for BDT 16,780.",
    highlights: [
      {
        title: "Marina Bay Sands",
        text: "The city's skyline icon — catch the free Spectra light-and-water show on the waterfront every evening.",
        image: 15480459,
      },
      {
        title: "Gardens by the Bay",
        text: "Futuristic Supertrees, the Cloud Forest and the Flower Dome in the heart of the city.",
        image: 4239738,
      },
      {
        title: "Garden Rhapsody",
        text: "Every evening the Supertree Grove comes alive with a free music and light show.",
        image: 37009220,
      },
      {
        title: "Marina Bay by night",
        text: "Stroll the waterfront promenade past the Merlion and the glittering skyline.",
        image: 18662417,
      },
    ],
    tips: [
      "Singapore is strict — no littering, and no eating or drinking on the MRT.",
      "Tap a contactless bank card or use an EZ-Link card for buses and the MRT.",
      "Eat at hawker centres such as Lau Pa Sat or Maxwell for delicious, affordable meals.",
      "Book Universal Studios and Gardens by the Bay tickets in advance during school holidays.",
    ],
    gallery: [5987044],
    faqs: [
      {
        q: "How do Bangladeshis apply for a Singapore visa?",
        a: "Singapore visas for Bangladeshi passport holders are submitted through an authorised visa agent or a local contact in Singapore. We handle the whole process — including the application form and supporting documents.",
      },
      {
        q: "How many days are enough for Singapore?",
        a: "Three to four full days covers the highlights — Marina Bay, Gardens by the Bay, Sentosa and Universal Studios — at a relaxed pace. Many travellers combine Singapore with Malaysia.",
      },
    ],
  },
};

export const DESTINATION_INFO: DestinationInfo[] = DESTINATIONS.map((d) => ({ ...d, ...DETAILS[d.id] }));

export const getDestination = (id: string) => DESTINATION_INFO.find((d) => d.id === id);
