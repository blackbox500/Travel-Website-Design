/**
 * ============================================================================
 *  TOUR PACKAGES
 *  ⚠️ Prices are indicative examples (BDT per person, twin sharing, land only).
 *     Please replace them with your real prices — or hide prices in config.ts
 *     (SETTINGS.showPrices = false).
 * ============================================================================
 */

export type TourStyle = "Family" | "Honeymoon" | "Culture" | "Nature" | "Adventure" | "Beach" | "City";
export const TOUR_STYLES: TourStyle[] = ["Family", "Honeymoon", "Culture", "Nature", "Adventure", "Beach", "City"];

export interface ItineraryDay {
  title: string;
  text: string;
}

export interface Tour {
  slug: string;
  title: string;
  destinations: string[];
  nights: number;
  price: number;
  oldPrice?: number;
  badge?: string;
  featured?: boolean;
  styles: TourStyle[];
  images: number[];
  route: string[];
  summary: string;
  highlights: string[];
  itinerary: ItineraryDay[];
  includes: string[];
  excludes: string[];
}

const stay = (nights: number, kind = "3-star hotels") => `${nights} nights in hand-picked ${kind} (twin sharing)`;
const SUPPORT = "On-trip support from the SAARC Holiday team";
const PRIVATE_CAR = "Airport transfers & sightseeing by private air-conditioned vehicle";
const EXCLUDES = [
  "International airfare (we can book it for you)",
  "Visa fees (visa processing assistance available)",
  "Entrance fees not mentioned above",
  "Meals not mentioned above & personal expenses",
  "Travel insurance",
  "Tips for guides and drivers",
];
const BHUTAN_EXCLUDES = [
  "International airfare (we can book it for you)",
  "Bhutan visa fee (USD 40) & Sustainable Development Fee (USD 15/night under the Bangladesh quota)",
  "Monument entrance fees",
  "Lunch, drinks & personal expenses",
  "Travel insurance",
  "Tips for guide and driver",
];

export const TOURS: Tour[] = [
  {
    slug: "bhutan-classic-thimphu-punakha-paro",
    title: "Bhutan Classic: Thimphu, Punakha & Paro",
    destinations: ["bhutan"],
    nights: 5,
    price: 42500,
    oldPrice: 46900,
    badge: "Best seller",
    featured: true,
    styles: ["Culture", "Nature", "Family", "Honeymoon"],
    images: [39128859, 37747845, 2810269, 18718814],
    route: ["Paro", "Thimphu", "Punakha"],
    summary:
      "Our most-loved Bhutan journey covers the capital Thimphu, the riverside dzong of Punakha via the Dochula Pass, and the legendary hike to Tiger's Nest above the Paro valley.",
    highlights: [
      "Hike to the cliff-top Paro Taktsang (Tiger's Nest)",
      "Punakha Dzong at the meeting of two rivers",
      "108 chortens and Himalayan views at Dochula Pass",
      "Giant Buddha Dordenma overlooking Thimphu",
      "Private car with a licensed English-speaking guide",
    ],
    itinerary: [
      {
        title: "Arrive Paro · Drive to Thimphu",
        text: "Welcome to Bhutan! Our representative meets you at Paro International Airport for the scenic 1.5-hour drive along the river to Thimphu. Evening at leisure around Clock Tower Square.",
      },
      {
        title: "Thimphu sightseeing",
        text: "Visit the Buddha Dordenma, the National Memorial Chorten, the Folk Heritage Museum, the Motithang Takin Preserve and the majestic Tashichho Dzong.",
      },
      {
        title: "Thimphu → Punakha via Dochula Pass",
        text: "Cross the 3,100 m Dochula Pass with its 108 chortens, then descend to Punakha to explore Punakha Dzong and walk across the long suspension bridge.",
      },
      {
        title: "Punakha → Paro",
        text: "Walk through rice fields to Chimi Lhakhang, then drive to Paro. Visit Rinpung Dzong and enjoy an evening stroll in Paro town.",
      },
      {
        title: "Tiger's Nest hike",
        text: "Hike to the iconic Paro Taktsang monastery (4–6 hours return). Ponies are available for part of the ascent. Optional traditional hot-stone bath in the evening.",
      },
      {
        title: "Depart Paro",
        text: "After breakfast, transfer to Paro International Airport for your flight home — with memories to last a lifetime.",
      },
    ],
    includes: [
      stay(5),
      "Daily breakfast & dinner",
      "Private vehicle with driver for all transfers & sightseeing",
      "Licensed English-speaking guide",
      "Bhutan visa processing",
      SUPPORT,
    ],
    excludes: BHUTAN_EXCLUDES,
  },
  {
    slug: "bhutan-short-escape-thimphu-paro",
    title: "Bhutan Short Escape: Thimphu & Paro",
    destinations: ["bhutan"],
    nights: 3,
    price: 31900,
    styles: ["Culture", "Nature", "Honeymoon"],
    images: [7806281, 15584957, 6904727],
    route: ["Paro", "Thimphu"],
    summary:
      "Short on time? This compact break captures the essence of Bhutan — Thimphu's landmarks, the Paro valley and an optional hike to Tiger's Nest.",
    highlights: [
      "Ideal long-weekend getaway",
      "Buddha Dordenma & Tashichho Dzong",
      "Optional Tiger's Nest hike",
      "Chele La Pass excursion (weather permitting)",
    ],
    itinerary: [
      {
        title: "Arrive Paro · Thimphu",
        text: "Meet our representative at Paro airport and drive to Thimphu. Visit the National Memorial Chorten and Tashichho Dzong in the evening.",
      },
      {
        title: "Thimphu → Paro",
        text: "Morning at the Buddha Dordenma and the Folk Heritage Museum, then return to Paro to visit Rinpung Dzong and the ancient Kyichu Lhakhang.",
      },
      {
        title: "Tiger's Nest or Chele La",
        text: "Hike to the legendary Tiger's Nest monastery, or take a scenic drive up to Chele La Pass (3,988 m) for sweeping Himalayan views.",
      },
      { title: "Depart Paro", text: "Transfer to Paro International Airport for your onward flight." },
    ],
    includes: [
      stay(3),
      "Daily breakfast & dinner",
      "Private vehicle with driver for all transfers & sightseeing",
      "Licensed English-speaking guide",
      "Bhutan visa processing",
      SUPPORT,
    ],
    excludes: BHUTAN_EXCLUDES,
  },
  {
    slug: "nepal-highlights-kathmandu-pokhara",
    title: "Nepal Highlights: Kathmandu & Pokhara",
    destinations: ["nepal"],
    nights: 5,
    price: 33500,
    badge: "Popular",
    featured: true,
    styles: ["Culture", "Nature", "Family", "Honeymoon"],
    images: [15846574, 11505263, 32225790, 37836764],
    route: ["Kathmandu", "Pokhara"],
    summary:
      "Temples, stupas and Himalayan sunrises — the perfect first trip to Nepal, with a free visa on arrival for Bangladeshi travellers.",
    highlights: [
      "UNESCO heritage sites of the Kathmandu valley",
      "Sunrise over the Annapurnas from Sarangkot",
      "Boating on Phewa Lake",
      "Free 30-day visa on arrival for Bangladeshis",
    ],
    itinerary: [
      {
        title: "Arrive Kathmandu",
        text: "Meet & greet at Tribhuvan International Airport and transfer to your hotel. Evening free to explore the lively lanes of Thamel.",
      },
      {
        title: "Kathmandu heritage tour",
        text: "Visit Swayambhunath (the Monkey Temple), Kathmandu Durbar Square, Pashupatinath Temple and the great Boudhanath Stupa.",
      },
      {
        title: "Kathmandu → Pokhara",
        text: "A scenic 6–7 hour drive along the Trishuli river to Pokhara (or fly in 25 minutes at extra cost). Relaxing evening at Lakeside.",
      },
      {
        title: "Pokhara sightseeing",
        text: "Early drive to Sarangkot for sunrise over Machhapuchhre and the Annapurnas. Later visit Davis Falls, Gupteshwor Cave and the World Peace Pagoda, and go boating on Phewa Lake.",
      },
      {
        title: "Pokhara → Kathmandu",
        text: "Drive back to Kathmandu. Afternoon visit to Patan Durbar Square, followed by a farewell Nepali dinner.",
      },
      { title: "Depart Kathmandu", text: "Transfer to the airport for your flight home." },
    ],
    includes: [stay(5), "Daily breakfast", PRIVATE_CAR, "English-speaking city guide in Kathmandu", "Boating on Phewa Lake", SUPPORT],
    excludes: EXCLUDES,
  },
  {
    slug: "nepal-adventure-chitwan-pokhara-nagarkot",
    title: "Nepal Adventure: Chitwan, Pokhara & Nagarkot",
    destinations: ["nepal"],
    nights: 6,
    price: 46900,
    styles: ["Adventure", "Nature", "Family"],
    images: [38267708, 35408915, 10965830, 15534873],
    route: ["Kathmandu", "Chitwan", "Pokhara", "Nagarkot"],
    summary:
      "Jungle safaris, mountain sunrises and optional paragliding — a week of Himalayan adventure for active families and friends.",
    highlights: [
      "Jeep safari & canoe ride in Chitwan National Park",
      "Optional tandem paragliding over Phewa Lake",
      "Himalayan sunrise at Nagarkot",
      "Tharu cultural dance evening",
    ],
    itinerary: [
      { title: "Arrive Kathmandu", text: "Airport pick-up and transfer to your hotel. Evening briefing and welcome dinner." },
      {
        title: "Kathmandu → Chitwan",
        text: "Drive to Chitwan National Park (≈5 hours). Afternoon village walk and a Tharu cultural dance in the evening.",
      },
      {
        title: "Chitwan jungle safari",
        text: "Canoe along the Rapti river spotting crocodiles and birds, followed by a jeep safari in search of one-horned rhinos and deer.",
      },
      { title: "Chitwan → Pokhara", text: "Drive to Pokhara (≈5 hours) and spend a relaxing evening by Phewa Lake." },
      {
        title: "Pokhara adventure day",
        text: "Sarangkot sunrise, then optional tandem paragliding, zip-lining or boating. Afternoon visit to Davis Falls and the Peace Pagoda.",
      },
      { title: "Pokhara → Nagarkot", text: "Drive to Nagarkot on the rim of the Kathmandu valley for sunset views over the Himalaya." },
      {
        title: "Nagarkot sunrise · Depart",
        text: "Wake up for a spectacular Himalayan sunrise, then visit Bhaktapur Durbar Square on the way to the airport.",
      },
    ],
    includes: [
      "6 nights in hand-picked hotels & a jungle resort (twin sharing)",
      "Daily breakfast; all meals in Chitwan",
      PRIVATE_CAR,
      "Chitwan activities: jeep safari, canoe ride, village walk & cultural show",
      SUPPORT,
    ],
    excludes: [...EXCLUDES, "Paragliding & other optional activities"],
  },
  {
    slug: "india-golden-triangle-delhi-agra-jaipur",
    title: "India Golden Triangle: Delhi, Agra & Jaipur",
    destinations: ["india"],
    nights: 5,
    price: 34900,
    styles: ["Culture", "Family", "City"],
    images: [11948442, 17911339, 17423832, 19521546],
    route: ["Delhi", "Agra", "Jaipur"],
    summary:
      "India's classic circuit — Mughal monuments, the Taj Mahal at sunrise and the palaces and bazaars of Jaipur, the Pink City.",
    highlights: [
      "Sunrise visit to the Taj Mahal",
      "Amber Fort & Hawa Mahal in Jaipur",
      "Qutub Minar, India Gate & Old Delhi",
      "Agra Fort and Fatehpur Sikri",
    ],
    itinerary: [
      { title: "Arrive Delhi", text: "Meet & greet at Delhi airport and transfer to your hotel. Evening visit to India Gate." },
      {
        title: "Delhi sightseeing",
        text: "Explore Old Delhi's Jama Masjid and Chandni Chowk by rickshaw, then Qutub Minar, Humayun's Tomb and the Lotus Temple.",
      },
      {
        title: "Delhi → Agra",
        text: "Drive to Agra on the expressway (≈4 hours). Visit Agra Fort and watch the sunset over the Taj from Mehtab Bagh.",
      },
      {
        title: "Taj Mahal · Agra → Jaipur",
        text: "Sunrise visit to the Taj Mahal. Drive to Jaipur via the abandoned Mughal city of Fatehpur Sikri.",
      },
      {
        title: "Jaipur sightseeing",
        text: "Amber Fort, Hawa Mahal, City Palace and Jantar Mantar, with time to shop in Jaipur's colourful bazaars.",
      },
      { title: "Jaipur → Delhi · Depart", text: "Drive back to Delhi for your flight home." },
    ],
    includes: [stay(5), "Daily breakfast", PRIVATE_CAR, "English-speaking guides for sightseeing", "Rickshaw ride in Old Delhi", SUPPORT],
    excludes: EXCLUDES,
  },
  {
    slug: "kashmir-srinagar-gulmarg-pahalgam",
    title: "Kashmir: Srinagar, Gulmarg & Pahalgam",
    destinations: ["india"],
    nights: 5,
    price: 38900,
    styles: ["Nature", "Honeymoon", "Family"],
    images: [40348598, 6739193, 33054187],
    route: ["Srinagar", "Gulmarg", "Pahalgam"],
    summary:
      "Houseboats on Dal Lake, the Gulmarg Gondola and the pine-scented valleys of Pahalgam — Kashmir is called paradise on earth for good reason.",
    highlights: [
      "A night on a traditional Dal Lake houseboat",
      "Shikara ride past floating gardens",
      "Gulmarg Gondola cable car",
      "Betaab Valley & Aru Valley in Pahalgam",
    ],
    itinerary: [
      {
        title: "Arrive Srinagar",
        text: "Transfer to a deluxe houseboat on Dal Lake. Sunset shikara ride past floating gardens and markets.",
      },
      {
        title: "Srinagar sightseeing",
        text: "Visit the Mughal Gardens — Nishat Bagh, Shalimar Bagh and Chashme Shahi — and the Hazratbal Shrine.",
      },
      {
        title: "Day trip to Gulmarg",
        text: "Drive to the alpine meadows of Gulmarg and ride the Gulmarg Gondola, one of the highest cable cars in the world.",
      },
      { title: "Srinagar → Pahalgam", text: "Drive through saffron fields and apple orchards to Pahalgam in the Lidder valley." },
      {
        title: "Pahalgam valleys",
        text: "Explore Betaab Valley, Aru Valley and Chandanwari by local vehicle, or try pony riding in the meadows.",
      },
      { title: "Depart Srinagar", text: "Return to Srinagar airport for your flight." },
    ],
    includes: [
      "1 night on a deluxe Dal Lake houseboat + 4 nights in hotels (twin sharing)",
      "Daily breakfast & dinner",
      PRIVATE_CAR,
      "Shikara ride on Dal Lake",
      SUPPORT,
    ],
    excludes: [...EXCLUDES, "Gulmarg Gondola tickets & local union vehicles in Pahalgam"],
  },
  {
    slug: "china-highlights-beijing-shanghai",
    title: "China Highlights: Beijing & Shanghai",
    destinations: ["china"],
    nights: 6,
    price: 98500,
    styles: ["City", "Culture", "Family"],
    images: [19031655, 20694743, 30221299, 345162],
    route: ["Beijing", "Shanghai"],
    summary:
      "The Great Wall, the Forbidden City and a bullet-train ride to Shanghai's dazzling skyline — China's two great cities in one week.",
    highlights: [
      "Great Wall at Mutianyu with cable car",
      "Forbidden City & Tiananmen Square",
      "High-speed train Beijing → Shanghai",
      "Huangpu river cruise along the Bund",
    ],
    itinerary: [
      { title: "Arrive Beijing", text: "Meet our guide at the airport and transfer to your hotel. Evening walk around Wangfujing." },
      {
        title: "Forbidden City & Temple of Heaven",
        text: "Tiananmen Square, the Forbidden City and the Temple of Heaven, followed by dinner (halal options available).",
      },
      {
        title: "The Great Wall",
        text: "Ride the cable car up to the Mutianyu section of the Great Wall and walk the ramparts. Afternoon at the Summer Palace.",
      },
      {
        title: "Bullet train to Shanghai",
        text: "Board a high-speed train to Shanghai (≈4.5 hours) at speeds above 300 km/h. Evening stroll along the Bund.",
      },
      { title: "Shanghai sightseeing", text: "Yu Garden, the old town bazaar, Nanjing Road and the Shanghai Tower observation deck." },
      {
        title: "Shanghai at leisure",
        text: "Free day for shopping, Shanghai Disneyland (optional) or a trip to the water town of Zhujiajiao. Evening Huangpu river cruise.",
      },
      { title: "Depart Shanghai", text: "Transfer to Pudong airport for your flight home." },
    ],
    includes: [
      stay(6, "4-star hotels"),
      "Daily breakfast",
      "Private transfers & sightseeing with an English-speaking guide",
      "High-speed train ticket Beijing → Shanghai (2nd class)",
      "Mutianyu Great Wall cable car",
      SUPPORT,
    ],
    excludes: EXCLUDES,
  },
  {
    slug: "yunnan-discovery-kunming-dali-lijiang",
    title: "Yunnan Discovery: Kunming, Dali & Lijiang",
    destinations: ["china"],
    nights: 6,
    price: 74900,
    badge: "Short flight",
    styles: ["Nature", "Culture", "Honeymoon"],
    images: [8936979, 10836079, 38690155],
    route: ["Kunming", "Dali", "Lijiang"],
    summary:
      "China's 'Land of Eternal Spring' — the Stone Forest, lakeside Dali and the UNESCO-listed old town of Lijiang beneath Jade Dragon Snow Mountain.",
    highlights: [
      "Stone Forest (Shilin) UNESCO World Heritage Site",
      "Erhai Lake & Dali Ancient Town",
      "Lijiang Old Town & Black Dragon Pool",
      "Jade Dragon Snow Mountain cable car (weather permitting)",
    ],
    itinerary: [
      { title: "Arrive Kunming", text: "Short flight from Dhaka to Kunming. Transfer to your hotel and visit Green Lake Park in the evening." },
      { title: "Stone Forest excursion", text: "Day trip to the spectacular limestone pillars of the Shilin Stone Forest." },
      { title: "Kunming → Dali", text: "Bullet train to Dali (≈2 hours). Explore Dali Ancient Town and the Three Pagodas." },
      {
        title: "Erhai Lake · Dali → Lijiang",
        text: "Cycle or drive along Erhai Lake and visit Xizhou village, then take the train to Lijiang.",
      },
      {
        title: "Jade Dragon Snow Mountain",
        text: "Ride the cable car up Jade Dragon Snow Mountain and visit Blue Moon Valley. Evening in Lijiang Old Town.",
      },
      { title: "Lijiang → Kunming", text: "Morning at Black Dragon Pool and Mufu Palace, then train back to Kunming." },
      { title: "Depart Kunming", text: "Transfer to the airport for your flight to Dhaka." },
    ],
    includes: [
      stay(6),
      "Daily breakfast",
      "Private transfers & sightseeing with an English-speaking guide",
      "Bullet-train tickets Kunming → Dali → Lijiang → Kunming",
      SUPPORT,
    ],
    excludes: [...EXCLUDES, "Jade Dragon Snow Mountain cable car & oxygen canister"],
  },
  {
    slug: "mongolia-nomad-experience-ulaanbaatar-terelj",
    title: "Mongolia Nomad Experience: Ulaanbaatar & Terelj",
    destinations: ["mongolia"],
    nights: 5,
    price: 89500,
    badge: "Unique",
    styles: ["Adventure", "Nature", "Culture"],
    images: [4321589, 31427424, 4321590, 39839229],
    route: ["Ulaanbaatar", "Terelj", "Hustai"],
    summary:
      "Sleep in a ger, ride across the steppe and meet nomadic families — an unforgettable journey into the land of Genghis Khan.",
    highlights: [
      "Two nights in a ger camp in Gorkhi-Terelj National Park",
      "Horse riding with local herders",
      "Genghis Khan Equestrian Statue",
      "Wild Przewalski's horses in Hustai National Park",
    ],
    itinerary: [
      { title: "Arrive Ulaanbaatar", text: "Airport pick-up and transfer to your hotel. Visit Sükhbaatar Square in the evening." },
      {
        title: "Ulaanbaatar city tour",
        text: "Gandan Monastery, the National Museum of Mongolia and Zaisan Memorial for views over the city. Evening traditional music and throat-singing show.",
      },
      {
        title: "To Terelj via the Genghis Khan Statue",
        text: "Visit the 40-metre Genghis Khan Equestrian Statue, then continue to a ger camp in Gorkhi-Terelj National Park.",
      },
      {
        title: "Life on the steppe",
        text: "Horse riding, a walk to Aryabal Meditation Temple and a visit to a nomadic family for milk tea and fresh dairy treats.",
      },
      {
        title: "Hustai National Park",
        text: "Drive to Hustai to spot wild Przewalski's horses (takhi) at dusk, then return to Ulaanbaatar.",
      },
      { title: "Depart Ulaanbaatar", text: "Transfer to Chinggis Khaan International Airport." },
    ],
    includes: [
      "3 nights in a 4-star hotel in Ulaanbaatar + 2 nights in a ger camp",
      "Breakfast in the city; all meals outside Ulaanbaatar",
      "Private vehicle with an English-speaking guide",
      "Horse riding & nomadic family visit",
      "Traditional music & throat-singing show",
      SUPPORT,
    ],
    excludes: EXCLUDES,
  },
  {
    slug: "thailand-bangkok-pattaya",
    title: "Thailand Fun: Bangkok & Pattaya",
    destinations: ["thailand"],
    nights: 4,
    price: 24500,
    badge: "Great value",
    featured: true,
    styles: ["City", "Beach", "Family"],
    images: [30540817, 5264308, 28544989],
    route: ["Bangkok", "Pattaya"],
    summary:
      "Temples, shopping and beaches — our best-value getaway combines Bangkok's sights with the sea and Coral Island in Pattaya.",
    highlights: [
      "Coral Island speedboat trip",
      "Grand Palace & Wat Arun",
      "Chao Phraya dinner cruise (optional)",
      "Shopping at Pratunam, Platinum & MBK",
    ],
    itinerary: [
      {
        title: "Arrive Bangkok · Pattaya",
        text: "Meet our representative at Suvarnabhumi Airport and transfer to Pattaya (≈2 hours). Evening free on the beach road.",
      },
      {
        title: "Coral Island",
        text: "Speedboat to Koh Larn (Coral Island) for white-sand beaches and optional water sports such as parasailing and sea walking.",
      },
      {
        title: "Pattaya → Bangkok",
        text: "Transfer to Bangkok. Afternoon free for shopping at Pratunam, Platinum Fashion Mall or MBK.",
      },
      {
        title: "Bangkok city & temple tour",
        text: "Visit the Grand Palace, Wat Pho with its reclining Buddha and Wat Arun on the river. Optional Chao Phraya dinner cruise.",
      },
      { title: "Depart Bangkok", text: "Transfer to the airport for your flight home." },
    ],
    includes: [
      stay(4),
      "Daily breakfast",
      "Private airport & intercity transfers",
      "Coral Island speedboat tour with lunch",
      "Bangkok city & temple tour",
      SUPPORT,
    ],
    excludes: EXCLUDES,
  },
  {
    slug: "thailand-islands-phuket-krabi",
    title: "Thailand Islands: Phuket & Krabi",
    destinations: ["thailand"],
    nights: 5,
    price: 36900,
    featured: true,
    styles: ["Beach", "Honeymoon", "Adventure"],
    images: [33053824, 32076924, 35126787, 37691587],
    route: ["Phuket", "Phi Phi", "Krabi"],
    summary:
      "Turquoise seas, limestone cliffs and island-hopping by speedboat — Thailand's Andaman coast is made for honeymoons and beach lovers.",
    highlights: [
      "Phi Phi Islands & Maya Bay speedboat tour",
      "Krabi Four Islands tour",
      "Phuket Big Buddha & Old Town",
      "Sunset at Promthep Cape",
    ],
    itinerary: [
      { title: "Arrive Phuket", text: "Transfer to your beach hotel in Patong or Kata. Evening at leisure." },
      {
        title: "Phi Phi Islands tour",
        text: "Full-day speedboat trip to Phi Phi Don, Maya Bay, Pileh Lagoon and Bamboo Island with snorkelling and lunch.",
      },
      { title: "Phuket city tour", text: "Big Buddha, Wat Chalong, Phuket Old Town and sunset at Promthep Cape." },
      { title: "Phuket → Krabi", text: "Transfer to Krabi (≈3 hours). Relax at Ao Nang beach in the evening." },
      {
        title: "Four Islands tour",
        text: "Longtail boat tour to Phra Nang Cave Beach, Chicken Island, Tup Island and Poda Island.",
      },
      { title: "Depart Krabi", text: "Transfer to Krabi airport for your flight home via Bangkok." },
    ],
    includes: [
      stay(5, "3-star beach hotels"),
      "Daily breakfast",
      "Private transfers including Phuket → Krabi",
      "Phi Phi Islands speedboat tour with lunch",
      "Krabi Four Islands longtail tour",
      "Phuket city tour",
      SUPPORT,
    ],
    excludes: [...EXCLUDES, "National park fees for island tours"],
  },
  {
    slug: "malaysia-kuala-lumpur-genting-langkawi",
    title: "Malaysia Delight: Kuala Lumpur, Genting & Langkawi",
    destinations: ["malaysia"],
    nights: 5,
    price: 34500,
    styles: ["Family", "City", "Beach"],
    images: [11719269, 35445967, 17939735, 19492620],
    route: ["Kuala Lumpur", "Genting Highlands", "Langkawi"],
    summary: "City lights, cool highlands and island beaches — a perfect family holiday with halal food everywhere.",
    highlights: [
      "Petronas Twin Towers & KLCC Park",
      "Batu Caves & Genting Highlands cable car",
      "Langkawi SkyCab & mangrove tour",
      "Duty-free shopping in Langkawi",
    ],
    itinerary: [
      { title: "Arrive Kuala Lumpur", text: "Meet & greet at KLIA and transfer to your city hotel. Evening at Bukit Bintang." },
      {
        title: "Kuala Lumpur city tour",
        text: "Petronas Twin Towers, the King's Palace, the National Mosque, Independence Square and KL Tower.",
      },
      {
        title: "Batu Caves & Genting Highlands",
        text: "Climb the steps of Batu Caves, then ride the Awana SkyWay cable car up to Genting Highlands for theme parks and cool mountain air.",
      },
      { title: "Fly to Langkawi", text: "Short flight to Langkawi. Afternoon at Pantai Cenang beach." },
      {
        title: "Langkawi island tour",
        text: "SkyCab cable car and Sky Bridge, Eagle Square and a mangrove boat tour with eagle watching.",
      },
      { title: "Depart Langkawi", text: "Transfer to Langkawi airport for your flight home via Kuala Lumpur." },
    ],
    includes: [
      stay(5),
      "Daily breakfast",
      PRIVATE_CAR,
      "KL city tour, Batu Caves & Genting Highlands (cable car included)",
      "Langkawi island tour with mangrove cruise",
      SUPPORT,
    ],
    excludes: [...EXCLUDES, "Domestic flight Kuala Lumpur ↔ Langkawi (we can book it)"],
  },
  {
    slug: "singapore-city-sentosa",
    title: "Singapore City & Sentosa",
    destinations: ["singapore"],
    nights: 4,
    price: 39900,
    featured: true,
    styles: ["Family", "City"],
    images: [15480459, 4239738, 37009220, 18662417],
    route: ["Singapore", "Sentosa"],
    summary:
      "Marina Bay, Gardens by the Bay and a full day of thrills on Sentosa — a fun-packed family holiday in the Lion City.",
    highlights: [
      "Gardens by the Bay — Flower Dome & Cloud Forest",
      "Universal Studios Singapore or S.E.A. Aquarium",
      "Night Safari (optional)",
      "Marina Bay light shows",
    ],
    itinerary: [
      { title: "Arrive Singapore", text: "Transfer from Changi Airport to your hotel. Evening Spectra light & water show at Marina Bay." },
      {
        title: "City tour & Gardens by the Bay",
        text: "Merlion Park, Chinatown, Little India and the Esplanade, followed by the Flower Dome and Cloud Forest at Gardens by the Bay.",
      },
      {
        title: "Sentosa Island",
        text: "Full day on Sentosa — Universal Studios Singapore or S.E.A. Aquarium, plus the Sentosa cable car.",
      },
      { title: "Leisure & shopping", text: "Free day for Orchard Road, Mustafa Centre or an optional Night Safari visit." },
      { title: "Depart Singapore", text: "Transfer to Changi Airport — don't miss the Jewel waterfall before you fly!" },
    ],
    includes: [
      stay(4),
      "Daily breakfast",
      "Private airport transfers",
      "Singapore city tour",
      "Gardens by the Bay (Flower Dome & Cloud Forest) tickets",
      "Sentosa: Universal Studios or S.E.A. Aquarium ticket + cable car",
      SUPPORT,
    ],
    excludes: EXCLUDES,
  },
  {
    slug: "southeast-asia-trio-singapore-malaysia-thailand",
    title: "Southeast Asia Trio: Singapore, Malaysia & Thailand",
    destinations: ["singapore", "malaysia", "thailand"],
    nights: 8,
    price: 82900,
    oldPrice: 89900,
    badge: "3 countries",
    featured: true,
    styles: ["Family", "City", "Beach"],
    images: [18662417, 11719269, 5264308, 4239738],
    route: ["Singapore", "Kuala Lumpur", "Bangkok", "Pattaya"],
    summary:
      "Three countries, one trip — and one set of visa documents with our 3-country visa offer. The ultimate Southeast Asia holiday.",
    highlights: [
      "Pairs perfectly with our 3-country visa offer",
      "Gardens by the Bay & Sentosa",
      "Petronas Towers & Genting Highlands",
      "Bangkok temples & Pattaya's Coral Island",
    ],
    itinerary: [
      { title: "Arrive Singapore", text: "Transfer to your hotel. Evening at Marina Bay for the Spectra show." },
      { title: "Singapore city & Gardens by the Bay", text: "City highlights tour followed by the Flower Dome and Cloud Forest." },
      { title: "Sentosa Island", text: "Universal Studios or S.E.A. Aquarium, the cable car and Sentosa's beaches." },
      { title: "Singapore → Kuala Lumpur", text: "Coach or flight to Kuala Lumpur. Evening at the Petronas Twin Towers." },
      { title: "Batu Caves & Genting Highlands", text: "Morning at Batu Caves, afternoon cable car up to Genting Highlands." },
      { title: "Kuala Lumpur → Bangkok → Pattaya", text: "Fly to Bangkok and transfer to Pattaya." },
      { title: "Coral Island", text: "Speedboat to Koh Larn for beaches and water sports." },
      { title: "Pattaya → Bangkok", text: "Bangkok temple tour — the Grand Palace and Wat Arun — plus shopping time." },
      { title: "Depart Bangkok", text: "Transfer to the airport for your flight to Dhaka." },
    ],
    includes: [
      stay(8),
      "Daily breakfast",
      "Airport & intercity transfers",
      "Singapore city tour, Gardens by the Bay & Sentosa",
      "KL city tour, Batu Caves & Genting Highlands",
      "Coral Island tour & Bangkok temple tour",
      SUPPORT,
    ],
    excludes: [...EXCLUDES, "Flights between Singapore, Kuala Lumpur & Bangkok (we can book them)"],
  },
];

export const getTour = (slug: string) => TOURS.find((t) => t.slug === slug);

export const TOUR_FAQS = [
  {
    q: "Is the price per person?",
    a: "Yes. Prices are per person, based on two people sharing a room, for the land package. Single rooms, peak-season dates and hotel upgrades may cost extra — we'll confirm the exact price for your dates.",
  },
  {
    q: "Are flights included?",
    a: "International flights are not included, so you can choose the airline and timing that suits you best. We'd be happy to book your air tickets at competitive fares.",
  },
  {
    q: "Can I customise this itinerary?",
    a: "Of course. Every tour is private, so you can add or remove days, upgrade hotels or include extra activities. Just tell us what you'd like when you enquire.",
  },
  {
    q: "How do I confirm and pay?",
    a: "Once you're happy with the final quote, our team will share the payment details and schedule. You can pay via bKash, Nagad, Rocket, Visa card or Bangla QR.",
  },
];
