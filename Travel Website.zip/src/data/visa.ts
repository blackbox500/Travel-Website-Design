/**
 * Visa checklist data. Requirements change frequently – review regularly.
 */

export type ApplicantType = "employee" | "business" | "student" | "other";

export const APPLICANT_TYPES: { id: ApplicantType; label: string }[] = [
  { id: "employee", label: "Job holder" },
  { id: "business", label: "Business owner" },
  { id: "student", label: "Student" },
  { id: "other", label: "Homemaker / Retired" },
];

export const COMMON_DOCS = [
  "Passport valid for 6+ months with 2 blank pages",
  "Previous passports (if any)",
  "Recent photos to embassy specification",
  "NID card or birth certificate copy",
  "Bank statement (last 6 months) + solvency certificate",
  "Hotel booking & travel itinerary",
  "Return air ticket reservation",
];

export const BASIC_DOCS = [
  "Passport valid for 6+ months",
  "Recent passport-size photo",
  "Hotel booking & itinerary",
  "Return air ticket",
];

export const TYPE_DOCS: Record<ApplicantType, string[]> = {
  employee: ["NOC / leave letter from employer", "Office ID & visiting card", "Salary certificate or recent pay slips"],
  business: ["Trade licence (with English translation)", "Company letterhead pad & visiting card", "TIN certificate / tax return"],
  student: ["Student ID card", "NOC / leave letter from institution", "Sponsor's bank statement & NOC (parent)"],
  other: ["Sponsor letter & sponsor's documents", "Marriage certificate (if sponsored by spouse)", "Pension papers / proof of income (retired)"],
};

export interface VisaCountry {
  id: string;
  name: string;
  flag: string;
  type: string;
  method: string;
  note?: string;
  inOffer?: boolean;
  docs: "full" | "basic";
  extras: string[];
}

export const VISA_COUNTRIES: VisaCountry[] = [
  {
    id: "thailand",
    name: "Thailand",
    flag: "th",
    type: "Tourist e-Visa",
    method: "Applied online through the official Thai e-Visa system — we prepare and submit the application for you.",
    inOffer: true,
    docs: "full",
    extras: ["Clear colour scans of all documents"],
  },
  {
    id: "malaysia",
    name: "Malaysia",
    flag: "my",
    type: "eVisa",
    method: "Applied online through Malaysia's official eVisa system with your scanned documents.",
    inOffer: true,
    docs: "full",
    extras: ["Digital passport photo with a white background"],
  },
  {
    id: "singapore",
    name: "Singapore",
    flag: "sg",
    type: "Tourist visa (via agent)",
    method: "Submitted through an authorised visa agent or a local contact in Singapore — we handle the full process.",
    inOffer: true,
    docs: "full",
    extras: ["Completed Form 14A (we fill it in with you)"],
  },
  {
    id: "china",
    name: "China",
    flag: "cn",
    type: "Tourist (L) visa",
    method: "Submitted at the Chinese Visa Application Service Center in Dhaka with a completed online application form.",
    docs: "full",
    extras: ["Completed online visa application form", "Day-by-day itinerary with hotel bookings"],
  },
  {
    id: "bhutan",
    name: "Bhutan",
    flag: "bt",
    type: "Visa (online or on arrival)",
    method: "Applied online in advance or obtained on arrival at Paro. Visa fee USD 40 plus the Sustainable Development Fee.",
    note: "First 15,000 Bangladeshi visitors each year pay a concessional SDF of USD 15/night (children under 6 exempt). We process your visa together with your tour.",
    docs: "basic",
    extras: ["Confirmed hotel bookings in Bhutan", "SDF payment (handled with your booking)"],
  },
  {
    id: "nepal",
    name: "Nepal",
    flag: "np",
    type: "Free visa on arrival",
    method: "Free 30-day tourist visa on arrival for Bangladeshi citizens — first visit in each calendar year.",
    note: "Further visits in the same calendar year are charged at the standard visa fees.",
    docs: "basic",
    extras: [],
  },
  {
    id: "india",
    name: "India",
    flag: "in",
    type: "Tourist visa",
    method: "Availability, appointment slots and requirements for Bangladeshi applicants change from time to time — ask us for the current status.",
    docs: "full",
    extras: ["Proof of address (recent utility bill)", "Copies of previous Indian visas (if any)"],
  },
  {
    id: "mongolia",
    name: "Mongolia",
    flag: "mn",
    type: "Tourist visa",
    method: "Requirements and the application route vary — our visa desk will guide you through each step.",
    docs: "full",
    extras: ["Invitation letter or tour confirmation (if required)"],
  },
];

export const VISA_OFFER = {
  price: "BDT 16,780",
  countries: ["thailand", "malaysia", "singapore"],
  points: [
    "Visa processing assistance for three destinations",
    "One set of documents for all three",
    "Guidance on required documents",
    "Professional travel support from our team",
  ],
  notice:
    "The BDT 16,780 offer is subject to applicable terms and conditions. Please contact us to confirm what charges are included. Visa approval is solely at the discretion of the respective embassy or immigration authority. Visa processing assistance does not guarantee visa approval.",
};

export const VISA_FAQS = [
  {
    q: "Does visa processing assistance guarantee approval?",
    a: "No. We make sure your application is complete and well-prepared, but visa approval is solely at the discretion of the respective embassy or immigration authority.",
  },
  {
    q: "How early should I apply?",
    a: "We recommend starting at least 3–4 weeks before travel, and earlier during peak seasons such as Eid, Durga Puja and the December holidays.",
  },
  {
    q: "What does the BDT 16,780 3-country offer include?",
    a: "Visa processing assistance for Thailand, Malaysia and Singapore using one set of documents. It's a limited-time offer subject to terms and conditions — contact us to confirm exactly which charges are included.",
  },
  {
    q: "Can you check my documents before I apply?",
    a: "Yes. Send clear scans or photos of your documents on WhatsApp, or visit our office in West Agargaon, and our visa desk will let you know if anything is missing.",
  },
  {
    q: "Can you arrange the hotel booking and air ticket reservation for my application?",
    a: "Yes — we can arrange hotel bookings and flight reservations to support your visa application, and convert them into a full holiday package if you wish.",
  },
];
