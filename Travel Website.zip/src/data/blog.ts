import { CONTACT } from "@/config";
import type { EnquiryPreset } from "@/lib/enquiryBus";

export type Category =
  | "Destination Guides"
  | "Visa & Documents"
  | "Itineraries"
  | "Travel Tips"
  | "Offers & News"
  | "Inspiration";

export const CATEGORIES: Category[] = [
  "Destination Guides",
  "Visa & Documents",
  "Itineraries",
  "Travel Tips",
  "Offers & News",
  "Inspiration",
];

/** Article content blocks. Use **double asterisks** for bold text inside strings. */
export type Block =
  | { type: "p"; text: string }
  | { type: "h2"; text: string }
  | { type: "h3"; text: string }
  | { type: "ul"; items: string[] }
  | { type: "ol"; items: string[]; start?: number }
  | { type: "tip"; title: string; text: string }
  | { type: "image"; image: number; caption?: string }
  | { type: "table"; head: string[]; rows: string[][] };

export interface Post {
  slug: string;
  title: string;
  excerpt: string;
  category: Category;
  date: string;
  cover: number;
  tags: string[];
  featured?: boolean;
  relatedTour?: string;
  cta?: { label: string; preset: EnquiryPreset };
  content: Block[];
}

export const AUTHOR = { name: "SAARC Holiday Travel Desk", role: "Travel experts based in Dhaka" };

const phones = CONTACT.phones.map((p) => p.display).join(", ");

const UNSORTED: Post[] = [
  {
    slug: "bhutan-travel-guide-for-bangladeshi-travellers",
    title: "Bhutan Travel Guide 2026: Everything Bangladeshi Travellers Need to Know",
    excerpt:
      "Visa, the Sustainable Development Fee, the best time to go, money tips and a sample itinerary — all you need to plan a trip to the Land of the Thunder Dragon from Bangladesh.",
    category: "Destination Guides",
    date: "2026-10-20",
    cover: 39128859,
    tags: ["bhutan", "visa", "guide"],
    featured: true,
    relatedTour: "bhutan-classic-thimphu-punakha-paro",
    cta: { label: "Plan my Bhutan trip", preset: { mode: "plan", service: "tour", destinations: ["bhutan"] } },
    content: [
      {
        type: "p",
        text: "Bhutan has become one of the most popular foreign holidays for Bangladeshi travellers — and it's easy to see why. It's about an hour away by air, wonderfully peaceful, safe for families and full of jaw-dropping Himalayan scenery. Since June 2024 it has also become much more affordable for Bangladeshis, thanks to a special reduced Sustainable Development Fee.",
      },
      { type: "p", text: "Here's everything you need to know before you go." },
      { type: "h2", text: "Do Bangladeshis need a visa for Bhutan?" },
      {
        type: "p",
        text: "Yes. Bangladeshi passport holders need a Bhutan tourist visa. The visa fee is **USD 40** per person, and you can apply online in advance or on arrival at Paro International Airport. Most travellers let their tour operator handle the application together with the hotel bookings — which is exactly what we do for our guests.",
      },
      {
        type: "ul",
        items: [
          "Passport valid for at least 6 months from your date of travel",
          "A recent passport-size photograph (a digital copy for online applications)",
          "Confirmed hotel bookings and itinerary",
          "Travel insurance (strongly recommended)",
        ],
      },
      { type: "h2", text: "The Sustainable Development Fee (SDF) explained" },
      {
        type: "p",
        text: "Every visitor to Bhutan pays a daily Sustainable Development Fee, which funds free healthcare, education and conservation in the kingdom. The standard rate for international visitors is USD 100 per person per night, fixed until 31 August 2027.",
      },
      {
        type: "p",
        text: "The good news for Bangladeshis: **the first 15,000 Bangladeshi visitors each year pay a concessional SDF of just USD 15 per person per night**. Children under 6 are exempt. Once the annual quota is filled the standard rate applies — so it pays to book early.",
      },
      {
        type: "tip",
        title: "Good to know",
        text: "The SDF is a government levy, so no tour operator can discount it. Since January 2026 a 5% GST applies to tour services such as hotels, guides and transport — but not to the SDF itself.",
      },
      { type: "h2", text: "When is the best time to visit?" },
      {
        type: "table",
        head: ["Season", "Months", "What to expect"],
        rows: [
          ["Spring", "March – May", "Pleasant days, blooming rhododendrons, Paro Tshechu festival"],
          ["Monsoon", "June – August", "Lush green valleys, afternoon rain, fewer tourists"],
          ["Autumn", "September – November", "Clear skies, the best mountain views, Thimphu Tshechu festival"],
          ["Winter", "December – February", "Cold nights, crisp clear days, very quiet"],
        ],
      },
      { type: "h2", text: "How many days do you need?" },
      {
        type: "p",
        text: "Five to seven days is ideal for a first visit. With 5 nights you can comfortably cover Thimphu, Punakha and Paro, including the famous Tiger's Nest hike. Short on time? A 3-night Thimphu & Paro break still captures the essence of Bhutan.",
      },
      { type: "h3", text: "A sample 6-day itinerary" },
      {
        type: "ol",
        items: [
          "Arrive in Paro and drive to Thimphu",
          "Thimphu: Buddha Dordenma, Memorial Chorten and Tashichho Dzong",
          "Cross the Dochula Pass to Punakha and visit Punakha Dzong",
          "Walk to Chimi Lhakhang, then drive to Paro",
          "Hike to Tiger's Nest",
          "Fly home",
        ],
      },
      { type: "image", image: 37747845, caption: "Punakha Dzong sits where the Pho Chhu and Mo Chhu rivers meet." },
      { type: "h2", text: "Money, SIM cards and connectivity" },
      {
        type: "ul",
        items: [
          "The local currency is the Ngultrum (BTN), pegged 1:1 to the Indian Rupee, which is also widely accepted.",
          "Carry US dollars in clean, newer notes for exchange; ATMs are available in Thimphu and Paro.",
          "Local SIM cards are cheap and easy to buy with your passport.",
          "Most hotels offer free Wi-Fi, although speeds can vary in rural areas.",
        ],
      },
      { type: "h2", text: "Etiquette tips" },
      {
        type: "ul",
        items: [
          "Dress modestly at dzongs and temples — long sleeves, long trousers or skirts, and no hats.",
          "Always walk clockwise around chortens and prayer wheels.",
          "Photography is generally not allowed inside temples.",
          "Ask permission before photographing people, especially monks.",
        ],
      },
      {
        type: "p",
        text: "Ready to experience the kingdom of happiness? Our **Bhutan Classic** package covers Thimphu, Punakha and Paro with a private car and guide — and we take care of your visa paperwork from start to finish.",
      },
    ],
  },
  {
    slug: "three-country-visa-offer",
    title: "Exclusive Visa Offer: Visit 3 Countries with One Set of Documents!",
    excerpt:
      "Explore Thailand, Malaysia and Singapore with SAARC Holiday Tour & Travel — visa processing for all three destinations for just BDT 16,780.",
    category: "Offers & News",
    date: "2026-10-27",
    cover: 15480459,
    tags: ["visa", "offer", "thailand", "malaysia", "singapore"],
    relatedTour: "southeast-asia-trio-singapore-malaysia-thailand",
    cta: {
      label: "Ask about the visa offer",
      preset: {
        mode: "plan",
        service: "visa",
        destinations: ["thailand", "malaysia", "singapore"],
        message:
          "I'm interested in the 3-Country Visa Offer (Thailand, Malaysia & Singapore – BDT 16,780). Please share the required documents and processing details.",
      },
    },
    content: [
      {
        type: "p",
        text: "Planning your next international trip? SAARC Holiday Tour & Travel brings you an exclusive visa processing offer designed to make your travel planning easier and more convenient.",
      },
      {
        type: "p",
        text: "With **one set of documents**, you can apply for visa processing for three exciting destinations — **Thailand, Malaysia and Singapore** — all for just **BDT 16,780**.",
      },
      { type: "h2", text: "Destinations included" },
      {
        type: "ul",
        items: [
          "**Thailand** – Discover beautiful beaches, vibrant cities and rich cultural heritage.",
          "**Malaysia** – Experience modern attractions, shopping destinations and stunning natural scenery.",
          "**Singapore** – Explore iconic landmarks, world-class attractions and a unique urban experience.",
        ],
      },
      { type: "image", image: 18662417, caption: "Singapore's Marina Bay — one of the three destinations in the offer." },
      { type: "h2", text: "Why choose SAARC Holiday?" },
      {
        type: "ul",
        items: [
          "Visa processing assistance for three destinations",
          "Guidance on required documents",
          "Professional travel support",
          "Convenient communication with our team",
        ],
      },
      { type: "h2", text: "Limited-time offer" },
      {
        type: "p",
        text: "This special offer is available for a limited time. Contact us today to learn more about the offer, required documents, applicable conditions and processing details.",
      },
      { type: "h2", text: "Contact SAARC Holiday Tour & Travel" },
      {
        type: "ul",
        items: [
          `**Phone:** ${phones}`,
          `**Email:** ${CONTACT.emails[0].value}`,
          `**Office:** ${CONTACT.address.full}`,
          "**Website:** saarcholiday.com",
        ],
      },
      { type: "p", text: "Make your travel plans with SAARC Holiday Tour & Travel — **Your Dream, Our Mission!**" },
      {
        type: "tip",
        title: "Important notice",
        text: "The BDT 16,780 offer is subject to applicable terms and conditions. Please contact us to confirm what charges are included. Visa approval is solely at the discretion of the respective embassy or immigration authority. Visa processing assistance does not guarantee visa approval.",
      },
    ],
  },
  {
    slug: "bhutan-hotel-special-offer",
    title: "Bhutan Hotel Special Offer: Comfortable Stays at Special Rates",
    excerpt:
      "Discover Bhutan with comfort and convenience — special hotel rates with free Wi-Fi, room service, a restaurant & bar and great-value meal plans.",
    category: "Offers & News",
    date: "2026-10-27",
    cover: 37747857,
    tags: ["bhutan", "offer", "hotel"],
    relatedTour: "bhutan-short-escape-thimphu-paro",
    cta: {
      label: "Check room availability",
      preset: {
        mode: "plan",
        service: "hotel",
        destinations: ["bhutan"],
        message: "I'd like to know more about the Bhutan Hotel Special Offer and room availability.",
      },
    },
    content: [
      {
        type: "p",
        text: "Planning a memorable trip to Bhutan? Make your holiday more comfortable with SAARC Holiday's exclusive **Bhutan Hotel Special Offer**.",
      },
      {
        type: "p",
        text: "Whether you are travelling with your family, planning a romantic honeymoon or looking for a peaceful mountain getaway, our specially arranged hotel rates offer a comfortable stay with essential facilities and convenient meal options.",
      },
      { type: "h2", text: "Hotel facilities" },
      {
        type: "ul",
        items: [
          "Free Wi-Fi",
          "Room service",
          "Coffee maker & mineral water",
          "Hot & cold running water",
          "Restaurant & bar",
          "Free parking",
          "Laundry service (chargeable)",
        ],
      },
      { type: "h2", text: "Meal rates" },
      {
        type: "table",
        head: ["Meal", "Rate per person"],
        rows: [
          ["Breakfast", "Nu. 250"],
          ["Lunch", "Nu. 450"],
          ["Dinner", "Nu. 450"],
        ],
      },
      { type: "h2", text: "Terms & conditions" },
      {
        type: "ul",
        items: [
          "One child below 6 years can stay free without an extra bed.",
          "Extra bed: ₹500.",
          "Service animals only; no pets are allowed.",
          "Meal charges apply according to the rates above.",
          "Room availability is subject to confirmation at the time of booking.",
          "Terms and rates may change without prior notice.",
        ],
      },
      { type: "image", image: 6904727, caption: "Prayer flags flutter above the Paro valley." },
      { type: "h2", text: "Make your Bhutan trip more comfortable" },
      {
        type: "p",
        text: "Bhutan is a perfect destination for travellers seeking peaceful landscapes, beautiful mountain views, unique culture and a relaxing escape from busy city life. With SAARC Holiday, you can arrange your hotel accommodation in advance and enjoy a more convenient travel experience.",
      },
      { type: "p", text: "Book your Bhutan hotel today and get ready to experience the peaceful beauty of Bhutan." },
    ],
  },
  {
    slug: "visa-document-checklist-bangladeshi-passport",
    title: "Visa Document Checklist for Bangladeshi Passport Holders",
    excerpt:
      "Job holder, business owner or student? Here are the documents most embassies ask for — and the common mistakes that delay applications.",
    category: "Visa & Documents",
    date: "2026-10-12",
    cover: 33497885,
    tags: ["visa", "documents", "thailand", "malaysia", "singapore", "china"],
    cta: { label: "Get help with my visa", preset: { mode: "plan", service: "visa" } },
    content: [
      {
        type: "p",
        text: "Whether you're applying for Thailand, Malaysia, Singapore, China or beyond, most tourist visa applications from Bangladesh ask for a very similar set of documents. Getting them right the first time is the single best way to avoid delays.",
      },
      {
        type: "p",
        text: "Use this checklist as a starting point — exact requirements vary by embassy and can change, so always confirm the latest list with us before you apply.",
      },
      { type: "h2", text: "Documents everyone needs" },
      {
        type: "ul",
        items: [
          "**Passport** valid for at least 6 months from your travel date, with at least two blank pages",
          "**Old passports**, if you have travelled before — previous visas strengthen your application",
          "**Recent photographs** matching the embassy's size and background specifications",
          "**National ID card** (NID) or birth certificate copy",
          "**Bank statement** for the last 6 months, with a **solvency certificate**",
          "**Hotel booking** and a day-by-day **travel itinerary**",
          "**Return air ticket reservation**",
        ],
      },
      { type: "h2", text: "Additional documents by profession" },
      { type: "h3", text: "Job holders" },
      {
        type: "ul",
        items: [
          "No Objection Certificate (NOC) or leave approval letter from your employer",
          "Office ID card and visiting card",
          "Salary certificate or recent pay slips",
        ],
      },
      { type: "h3", text: "Business owners" },
      {
        type: "ul",
        items: [
          "Trade licence, with a notarised English translation if needed",
          "Company letterhead pad and visiting card",
          "TIN certificate and recent income tax return (where available)",
        ],
      },
      { type: "h3", text: "Students" },
      {
        type: "ul",
        items: [
          "Student ID card",
          "NOC or leave letter from your school, college or university",
          "Sponsor's documents — usually a parent's bank statement, NOC and proof of relationship",
        ],
      },
      { type: "h3", text: "Homemakers & retirees" },
      {
        type: "ul",
        items: [
          "Sponsor letter from a spouse or family member, with their supporting documents",
          "Marriage certificate (if sponsored by your spouse)",
          "Pension documents or other proof of income (retirees)",
        ],
      },
      {
        type: "tip",
        title: "Travelling with children?",
        text: "Bring each child's birth certificate and, if only one parent is travelling, a consent letter from the other parent.",
      },
      { type: "h2", text: "Common mistakes that cause delays" },
      {
        type: "ol",
        items: [
          "Photos in the wrong size or with a coloured background",
          "Bank statements without the bank's seal and signature",
          "A passport with less than 6 months' validity",
          "Names spelled differently across documents",
          "Last-minute applications during peak seasons such as Eid and the winter holidays",
        ],
      },
      { type: "h2", text: "How much bank balance do I need?" },
      {
        type: "p",
        text: "For most countries there is no single official figure. Embassies look for a stable balance and regular transactions that comfortably cover your trip costs. Sudden large deposits just before applying can raise questions — so plan ahead.",
      },
      {
        type: "p",
        text: "Not sure whether your documents are ready? Try the interactive checklist on our **Visa** page, or send us scans on WhatsApp and our visa desk will take a look.",
      },
    ],
  },
  {
    slug: "nepal-6-day-itinerary-kathmandu-pokhara",
    title: "Nepal in 6 Days: A Kathmandu & Pokhara Itinerary",
    excerpt:
      "Temples, stupas, lakes and Himalayan sunrises — a relaxed six-day plan for your first trip to Nepal, with budget tips along the way.",
    category: "Itineraries",
    date: "2026-10-05",
    cover: 15846574,
    tags: ["nepal", "itinerary", "budget"],
    relatedTour: "nepal-highlights-kathmandu-pokhara",
    cta: { label: "Plan my Nepal trip", preset: { mode: "plan", service: "tour", destinations: ["nepal"] } },
    content: [
      {
        type: "p",
        text: "Nepal is one of the best-value international trips you can take from Bangladesh. Flights are short, Bangladeshi citizens get a **free 30-day visa on arrival** for their first visit each calendar year, and both Kathmandu and Pokhara offer hotels and restaurants for every budget.",
      },
      { type: "p", text: "Here's our tried-and-tested six-day plan." },
      { type: "h2", text: "Day 1: Arrive in Kathmandu" },
      {
        type: "p",
        text: "Collect your free visa on arrival at Tribhuvan International Airport (keep a passport photo handy), check in to your hotel and spend the evening exploring Thamel — the lively hub full of cafés, gear shops and momo stalls.",
      },
      { type: "h2", text: "Day 2: Kathmandu's heritage sites" },
      {
        type: "p",
        text: "Start at **Swayambhunath**, the 'Monkey Temple', for sweeping views over the valley. Continue to **Kathmandu Durbar Square**, then **Pashupatinath**, Nepal's holiest Hindu temple on the Bagmati river. End the day at **Boudhanath**, one of the largest stupas in the world, as the butter lamps are lit.",
      },
      { type: "image", image: 11505263, caption: "Boudhanath Stupa, the heart of Tibetan Buddhist culture in Kathmandu." },
      { type: "h2", text: "Day 3: Kathmandu to Pokhara" },
      {
        type: "p",
        text: "The 200 km drive takes 6–8 hours along the Trishuli river, with plenty of roadside cafés for breaks. If time matters more than budget, the 25-minute flight is a great upgrade — sit on the right-hand side for mountain views.",
      },
      { type: "h2", text: "Day 4: Sunrise at Sarangkot & Pokhara sights" },
      {
        type: "p",
        text: "Set your alarm early for the drive up to **Sarangkot**, where the sun lights up Machhapuchhre (Fishtail) and the Annapurna range. Later visit **Davis Falls**, **Gupteshwor Cave** and the **World Peace Pagoda**, then hire a colourful boat on **Phewa Lake** to visit the island temple of Tal Barahi.",
      },
      {
        type: "tip",
        title: "Feeling adventurous?",
        text: "Pokhara is one of the world's top tandem-paragliding spots. A flight from Sarangkot over Phewa Lake is unforgettable — ask us to arrange a licensed operator.",
      },
      { type: "h2", text: "Day 5: Back to Kathmandu & Patan" },
      {
        type: "p",
        text: "Return to Kathmandu and spend the afternoon in **Patan Durbar Square**, famous for its exquisite Newari architecture and metalwork shops. Treat yourself to a farewell dinner with a traditional Nepali thali.",
      },
      { type: "h2", text: "Day 6: Fly home" },
      {
        type: "p",
        text: "Pick up last-minute souvenirs — pashmina shawls, singing bowls and Nepali tea make great gifts — before your flight home.",
      },
      { type: "h2", text: "Budget tips for Nepal" },
      {
        type: "ul",
        items: [
          "Carry US dollars and exchange them in Kathmandu — Bangladeshi Taka is hard to exchange.",
          "Eat where the locals eat: a plate of momos or dal bhat is filling and inexpensive.",
          "Buy a local SIM card at the airport for cheap mobile data.",
          "Travel in October–November or March–April for the best weather — and book early, as these are peak months.",
          "Bargain politely in markets; fixed-price shops are usually clearly marked.",
        ],
      },
      {
        type: "p",
        text: "Prefer not to plan it all yourself? Our **Nepal Highlights** package follows this exact route with private transport, hotels and a guide.",
      },
    ],
  },
  {
    slug: "best-time-to-visit-month-by-month-guide",
    title: "When to Go: A Season Guide to Our Top Destinations",
    excerpt:
      "Himalayan sunshine or tropical beaches? Here's when to visit Bhutan, Nepal, India, Thailand, Malaysia, Singapore, China and Mongolia for the best experience.",
    category: "Travel Tips",
    date: "2026-09-28",
    cover: 34775561,
    tags: ["planning", "bhutan", "nepal", "india", "thailand", "malaysia", "singapore", "china", "mongolia"],
    cta: { label: "Ask a travel expert", preset: { mode: "quick", topic: "General question" } },
    content: [
      {
        type: "p",
        text: "The right timing can make or break a holiday. Clear mountain views in the Himalaya, calm seas in Thailand and a green steppe in Mongolia all depend on the season. Here's a quick guide to help you plan.",
      },
      { type: "h2", text: "Best months at a glance" },
      {
        type: "table",
        head: ["Destination", "Best months", "Keep in mind"],
        rows: [
          ["Bhutan", "Mar–May, Sep–Nov", "Jun–Aug is monsoon; Dec–Feb is cold"],
          ["Nepal", "Oct–Nov, Mar–Apr", "Jun–Sep monsoon often hides the mountains"],
          ["India (Delhi, Agra, Jaipur)", "Oct–Mar", "Apr–Jun is very hot"],
          ["Kashmir", "Apr–Oct; Dec–Feb for snow", "Heavy snow can close roads in winter"],
          ["Thailand (Phuket, Krabi)", "Nov–Apr", "May–Oct brings rougher seas on the Andaman coast"],
          ["Malaysia (KL, Langkawi)", "Dec–Apr", "Short tropical showers year-round"],
          ["Singapore", "Year-round (Feb–Apr driest)", "Nov–Jan is the wettest period"],
          ["China (Beijing, Shanghai)", "Apr–May, Sep–Oct", "Early-October national holiday crowds"],
          ["Mongolia", "Jun–Sep", "Very cold from November to March"],
        ],
      },
      { type: "h2", text: "Peak travel times from Bangladesh" },
      {
        type: "p",
        text: "Demand from Bangladesh spikes during the **Eid holidays**, the **December school holidays** and the **Durga Puja** break. Flights and hotels fill up fast and prices rise, so book at least 6–8 weeks ahead for these periods.",
      },
      { type: "h2", text: "Shoulder seasons: the sweet spot" },
      {
        type: "p",
        text: "The weeks just before and after peak season often combine good weather with lower prices and fewer crowds — think early March in Bhutan, late November in Thailand or late September in Nepal as the monsoon fades.",
      },
      {
        type: "tip",
        title: "Festival bonus",
        text: "Time your trip with a festival for an unforgettable experience: Paro Tshechu (spring) or Thimphu Tshechu (autumn) in Bhutan, Dashain and Tihar in Nepal (Oct–Nov), Songkran in Thailand (mid-April) or Naadam in Mongolia (July).",
      },
      { type: "h2", text: "Not sure when to go?" },
      {
        type: "p",
        text: "Tell us your preferred dates and budget, and we'll suggest the destinations that will be at their best when you're free to travel.",
      },
    ],
  },
  {
    slug: "packing-tips-first-international-trip",
    title: "12 Smart Packing Tips for Your First International Trip",
    excerpt:
      "From documents and power adapters to medicines and money — a practical packing guide so you can travel light and stress-free.",
    category: "Travel Tips",
    date: "2026-09-18",
    cover: 4245905,
    tags: ["packing", "planning", "first-trip"],
    cta: { label: "Plan a trip with us", preset: { mode: "plan", service: "tour" } },
    content: [
      {
        type: "p",
        text: "Packing for your first trip abroad can feel overwhelming. Pack too much and you'll be dragging a heavy suitcase through airports; pack too little and you'll be shopping for basics on day one. These practical tips will get you there with exactly what you need.",
      },
      { type: "h2", text: "Documents & money" },
      {
        type: "ol",
        items: [
          "**Keep documents in one folder.** Passport, visa copies, air tickets, hotel vouchers, insurance and your itinerary — printed and saved on your phone.",
          "**Make copies.** Email yourself scans of your passport and visa, and keep a photocopy separate from the originals.",
          "**Carry some US dollars.** Clean, newer notes are the easiest currency to exchange almost everywhere in Asia.",
          "**Tell your bank you're travelling** and check that your card works for international payments.",
        ],
      },
      { type: "h2", text: "Clothes & luggage" },
      {
        type: "ol",
        start: 5,
        items: [
          "**Check the baggage allowance** on your ticket — both checked and cabin — before you pack.",
          "**Roll, don't fold.** Rolled clothes take less space and crease less; packing cubes keep everything organised.",
          "**Pack for the climate — and the culture.** Light cotton for Thailand and Singapore, warm layers for Bhutan, Nepal and Kashmir, and modest outfits for temples and mosques.",
          "**Wear your bulkiest items on the plane** — jackets and walking shoes take up a lot of suitcase space.",
        ],
      },
      { type: "image", image: 9186024, caption: "Packing cubes and rolled clothes save a surprising amount of space." },
      { type: "h2", text: "Health & gadgets" },
      {
        type: "ol",
        start: 9,
        items: [
          "**Bring your medicines** in their original packaging with a copy of the prescription, plus a small first-aid kit.",
          "**Pack a universal power adapter** and a power bank — power banks must go in your cabin baggage.",
          "**Keep liquids under 100 ml** in a clear bag in your hand luggage.",
          "**Leave space for souvenirs!** Pack a foldable bag for the way home.",
        ],
      },
      {
        type: "tip",
        title: "Our golden rule",
        text: "Lay out everything you plan to take, then put back a third of it. You almost certainly won't miss it.",
      },
      {
        type: "p",
        text: "Travelling with SAARC Holiday? Ask our team for destination-specific advice on weather, dress codes and essentials before you pack.",
      },
    ],
  },
  {
    slug: "honeymoon-destinations-from-bangladesh",
    title: "6 Romantic Honeymoon Destinations from Bangladesh",
    excerpt:
      "Mountain hideaways, tropical islands and dreamy lakes — our favourite honeymoon ideas, all within a few hours' flight of Dhaka.",
    category: "Inspiration",
    date: "2026-09-08",
    cover: 1024994,
    tags: ["honeymoon", "bhutan", "nepal", "thailand", "malaysia", "india", "singapore"],
    relatedTour: "thailand-islands-phuket-krabi",
    cta: {
      label: "Plan our honeymoon",
      preset: { mode: "plan", service: "tour", message: "We're planning our honeymoon. Please suggest some romantic packages." },
    },
    content: [
      {
        type: "p",
        text: "After the excitement of a Bangladeshi wedding, a peaceful honeymoon is exactly what you need. The good news: some of the world's most romantic places are just a few hours from Dhaka. Here are our favourites.",
      },
      { type: "h2", text: "1. Bhutan — peace and mountain magic" },
      {
        type: "p",
        text: "Quiet valleys, cosy hotels with mountain views and a hike to the Tiger's Nest together — Bhutan is perfect for couples who want something calm and meaningful. Don't miss a traditional hot-stone bath in Paro.",
      },
      { type: "h2", text: "2. Pokhara, Nepal — lakes and sunrises" },
      {
        type: "p",
        text: "Paddle across Phewa Lake, watch the sun rise over the Annapurnas from Sarangkot and try tandem paragliding together. Pokhara's lakeside cafés and boutique resorts make it effortlessly romantic.",
      },
      { type: "image", image: 37836764, caption: "Rowboats on a calm lake at sunset — Pokhara at its most romantic." },
      { type: "h2", text: "3. Phuket & Krabi, Thailand — island paradise" },
      {
        type: "p",
        text: "White-sand beaches, turquoise water and sunsets behind limestone cliffs. Island-hop to Phi Phi, book a candlelit dinner on the beach and choose a pool villa for extra privacy.",
      },
      { type: "h2", text: "4. Langkawi, Malaysia — tropical and relaxed" },
      {
        type: "p",
        text: "Langkawi combines quiet beaches, rainforest, mangrove cruises and duty-free shopping, with halal food everywhere — a great choice for Muslim couples.",
      },
      { type: "h2", text: "5. Kashmir, India — paradise on earth" },
      {
        type: "p",
        text: "A night on a carved-wood houseboat, shikara rides on Dal Lake and snowy meadows in Gulmarg — Kashmir is the classic honeymoon for good reason.",
      },
      { type: "h2", text: "6. Singapore — city romance" },
      {
        type: "p",
        text: "Rooftop views over Marina Bay, evening light shows at Gardens by the Bay and world-class dining. Combine it with Malaysia or Thailand for a two-centre honeymoon.",
      },
      {
        type: "tip",
        title: "Honeymoon perks",
        text: "Let us know you're on your honeymoon when you enquire — many hotels offer room upgrades, cakes or special decorations for newlyweds, subject to availability.",
      },
      {
        type: "p",
        text: "Every couple is different — tell us your dates, budget and dream experiences, and we'll design a honeymoon that's uniquely yours.",
      },
    ],
  },
];

export const POSTS: Post[] = [...UNSORTED].sort((a, b) => b.date.localeCompare(a.date));

export const getPost = (slug: string) => POSTS.find((p) => p.slug === slug);

const words = (s: string) => s.split(/\s+/).filter(Boolean).length;

export function readingTime(post: Post) {
  const total = post.content.reduce((n, b) => {
    if (b.type === "ul" || b.type === "ol") return n + words(b.items.join(" "));
    if (b.type === "table") return n + words(b.rows.flat().join(" "));
    if (b.type === "image") return n;
    if (b.type === "tip") return n + words(b.title) + words(b.text);
    return n + words(b.text);
  }, 0);
  return Math.max(2, Math.round(total / 200));
}
