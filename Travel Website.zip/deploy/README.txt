=====================================================================
 SAARC HOLIDAY WEBSITE  -  HOW TO UPLOAD
=====================================================================

WHAT IS IN THIS ZIP
-------------------
  index.html      The complete website - every page is inside this one file.
  saarc-logo.png  Your logo (used by Google and Facebook link previews).
  robots.txt      Tells Google it may list your website.
  htaccess.txt    Server settings. Use it ONLY when you go live (Part B).
  README.txt      This guide. You can delete it from the server afterwards.


BEFORE YOU START
----------------
  * This is NOT a WordPress theme or plugin.
    Do NOT upload it in WordPress > Plugins or Appearance > Themes.
    WordPress will reject it ("No valid plugins were found").

  * Upload it with your HOSTING control panel (cPanel > File Manager)
    or with an FTP program such as FileZilla.
    Your site runs on LiteSpeed hosting, which normally comes with cPanel.
    No cPanel login? Ask your hosting company, or Dhaka CentreNIC IT Ltd
    (who built your current website).

  * No database, PHP or special settings are needed.


PART A - TEST IT FIRST  (your current website is NOT changed)
-------------------------------------------------------------
  1. Log in to cPanel and open "File Manager".
  2. Open the "public_html" folder.
  3. Click "+ Folder" and create a folder named:   new
  4. Open the "new" folder, click "Upload" and choose
     saarc-holiday-website.zip
  5. Go back to the "new" folder, right-click the zip file >
     "Extract" > "Extract Files".
  6. Open   https://saarcholiday.com/new/   on your phone and computer
     and check every page.


PART B - GO LIVE  (the new website replaces WordPress)
------------------------------------------------------
  1. MAKE A BACKUP FIRST
     cPanel > "Backup" (or "Backup Wizard") > download a full backup.
     Quick alternative: in File Manager select everything in public_html >
     "Compress" > download the zip file it creates.

  2. In File Manager click "Settings" (top right), tick
     "Show Hidden Files (dotfiles)" and click Save.

  3. Open "public_html", click "Upload" and choose
     saarc-holiday-website.zip. Then right-click the zip >
     "Extract" > "Extract Files".
     The files must sit directly inside public_html (not in a sub-folder).
     If it asks to overwrite a file, choose Yes (your backup has the original).

  4. Right-click ".htaccess" > "Rename" to:    .htaccess-wordpress-backup

  5. Right-click "htaccess.txt" > "Rename" to:    .htaccess

  6. Open  https://saarcholiday.com  in a private / incognito window. Done!
     Still seeing the old site? Clear your browser cache. If you use a
     cache plugin or Cloudflare, purge its cache too.

  7. Delete the "new" test folder and the zip file from public_html.

  What changes after going live:
   * Your website always opens on the secure https:// address.
   * Old WordPress links redirect to the new pages automatically, e.g.
       saarcholiday.com/contact/                  ->  Contact page
       saarcholiday.com/bhutan-tour/              ->  Bhutan page
       saarcholiday.com/three-country-visa-offer/ ->  the offer article
   * The WordPress files and database stay on the server, unused,
     so you can switch back at any time (see UNDO below).

  Note for web developers: instead of steps 4-5 you can paste the contents
  of htaccess.txt at the very TOP of the existing .htaccess file.


UNDO - GO BACK TO THE OLD WORDPRESS SITE
----------------------------------------
  1. In public_html delete:   index.html   and   .htaccess
  2. Rename   .htaccess-wordpress-backup   back to   .htaccess


UPDATING THE WEBSITE LATER
--------------------------
  Prices, tours, blog posts and contact details are built into index.html.
  To change them, edit the project's source files (or ask your developer),
  build it again, then upload the new index.html to public_html and
  replace the old one. Nothing else needs to change, and visitors see
  the update straight away.


ENQUIRY FORM
------------
  Enquiries currently open WhatsApp (or the visitor's email app) with all
  the details filled in - this works on any hosting.
  To receive enquiries directly in your email inbox, create a free access
  key at https://web3forms.com, add it in src/config.ts
  (FORM.web3formsAccessKey), build again and upload the new index.html.
