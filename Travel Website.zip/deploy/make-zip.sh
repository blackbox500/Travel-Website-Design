#!/usr/bin/env bash
# ---------------------------------------------------------------------------
#  Builds the website and packs everything needed for upload into
#  deploy/saarc-holiday-website.zip
#
#  Usage (from the project folder):   bash deploy/make-zip.sh
# ---------------------------------------------------------------------------
set -euo pipefail
cd "$(dirname "$0")/.."

npm run build

PKG="deploy/package"
ZIP="deploy/saarc-holiday-website.zip"

rm -rf "$PKG" "$ZIP"
mkdir -p "$PKG"
cp dist/index.html dist/saarc-logo.png dist/robots.txt "$PKG"/
cp deploy/htaccess.txt deploy/README.txt "$PKG"/

# Files go in the root of the zip, so they extract straight into public_html
(cd "$PKG" && zip -X -q -9 "../$(basename "$ZIP")" index.html saarc-logo.png robots.txt htaccess.txt README.txt)
rm -rf "$PKG"

echo ""
echo "Created $ZIP"
unzip -l "$ZIP"
